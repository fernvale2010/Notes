# BLDC-Motor-Driver
https://www.youtube.com/watch?v=VjKhwe3weS0
