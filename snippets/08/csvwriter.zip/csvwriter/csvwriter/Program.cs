﻿/*
 * Created by SharpDevelop.
 * User: Toshiba17
 * Date: 26/1/2018
 * Time: 6:28 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace csvwriter
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			
			// TODO: Implement Functionality Here
			
			var firs = new List<TX_CSC_FINANCIAL>
			{
				new TX_CSC_FINANCIAL(),
				new TX_CSC_FINANCIAL()
			};
			
			// populate firs
			firs[0].CSC_APP_NO = 1000120011287873;
			firs[0].PURSE_TXN_CTR = 298;
			firs[0].MSG_TYPE_CD = 4102;
			firs[0].TXN_DATETIME = DateTime.Parse(@"2015-11-20 10:35:09 PM"); //"2/21/2009 10:35 PM"
			firs[0].PROCESSING_DATE = DateTime.Parse(@"2015-11-20");
			firs[0].BUSINESS_DATE = DateTime.Parse(@"2015-11-20");
			firs[0].TXN_TYPE_CD = 1;
			firs[0].TXN_AMT = 20;
			firs[0].PURSE_BAL_AMT = 33.30;
			firs[0].ACQ_ID = 14;
			firs[0].AGENT_ID = 301;
			
			firs[1].CSC_APP_NO = 1009710019530578;
			firs[1].PURSE_TXN_CTR = 28;
			firs[1].MSG_TYPE_CD = 4102;
			firs[1].TXN_DATETIME = DateTime.Parse(@"2015-11-20 04:18:09 PM");
			firs[1].PROCESSING_DATE = DateTime.Parse(@"2015-11-20");
			firs[1].BUSINESS_DATE = DateTime.Parse(@"2015-11-20");
			firs[1].TXN_TYPE_CD = 1;
			firs[1].TXN_AMT = 10;
			firs[1].PURSE_BAL_AMT = 13.30;
			firs[1].ACQ_ID = 14;
			firs[1].AGENT_ID = 301;
			
			var cw = new CsvWriter<TX_CSC_FINANCIAL>(',');
			cw.WriteFromEnumerable(firs, "example.csv");
			
			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}