﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csvwriter
{
    // CMCC
    public class TX_CSC_FINANCIAL_EXCP
    {
        public DateTime PROCESSING_DATE { get; set; }
        public long REC_SEQ_NO { get; set; }
        public long CSC_APP_NO { get; set; }
        public long PURSE_TXN_CTR { get; set; }
        public long MSG_TYPE_CD { get; set; }
        public DateTime TXN_DATETIME { get; set; }
        public DateTime BUSINESS_DATE { get; set; }
        public int PURSE_STATUS_CD { get; set; }
        public int TXN_TYPE_CD { get; set; }
        public double TXN_AMT { get; set; }
        public double PURSE_BAL_AMT { get; set; } 
        public long ACQ_ID { get; set; }
        public int AGENT_ID { get; set; }       
        public int UPDATE_CSC_IND { get; set; }        
        public string EXCP_REASON_LIST { get; set; }
        
    }
}
