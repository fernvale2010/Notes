﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csvwriter
{
    public class TRX2_DETAILS_SRC1
    {
        public DateTime TRX_DATE_TIME { get; set; }
        public long CAN_ID { get; set; }
        public long PTC { get; set; }
        public double AMOUNT { get; set; }
        public double ORIGINAL_AMOUNT { get; set; }
        public double FEE { get; set; }
        public string TXN_TYPE { get; set; }
        public string REFERENCE_1 { get; set; }
        public string REFERENCE_2 { get; set; }
        public string INDICATOR { get; set; }
        public DateTime REPORT_DATE { get; set; }
        public string REPORT_NAME { get; set; }
        public int AGENT_ID { get; set; }
        public long REPORT_ID { get; set; }        
    }
}
