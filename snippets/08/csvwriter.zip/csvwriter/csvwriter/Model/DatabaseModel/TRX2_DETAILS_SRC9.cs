﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csvwriter
{
    public class TRX2_DETAILS_SRC9
    {
        public DateTime Txn_Date_Time { get; set; }
        public long Merchant_ID { get; set; }
        public long Terminal { get; set; }
        public double EZ_Amt { get; set; }
        public long EZ_Card_No { get; set; }
        public long PTC { get; set; }
        public long CT_RRN_Number { get; set; }
        public long EZLink_REF_No { get; set; }
        public long Credit_Card_No { get; set; }
        public string Auth_Code { get; set; }
        public double Credit_Amt { get; set; }
        public double Different { get; set; }
        public long REPORT_ID { get; set; }
        public DateTime REPORT_DATE { get; set; }
        public string REPORT_NAME { get; set; }        
    }
}
