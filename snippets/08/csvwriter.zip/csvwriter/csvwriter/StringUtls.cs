using System.Linq;

namespace csvwriter
{
    public static class StringExtensionMethods
    {
        public static string ReplaceSpecialCharacters(this string input)
        {
            return input.Replace('i', 'i')
                .Replace('�', 'c')
                .Replace('�', 'o')
                .Replace('s', 's')
                .Replace('�', 'u')
                .Replace('g', 'g')
                .Replace('I', 'I')
                .Replace('�', 'C')
                .Replace('�', 'O')
                .Replace('S', 'S')
                .Replace('�', 'U')
                .Replace('G', 'G');
        }
        public static string RemovePath(this string input)
        {
            if (input.Contains("\\"))
            {
                var modifiedInput = input.SkipWhile(s => s != '\\').Skip(1);
                string output = string.Empty;
                var enumerable = modifiedInput as char[] ?? modifiedInput.ToArray();
                for (int i = 0; i < enumerable.Count(); i++)
                {
                    output += enumerable[i];
                }
                return RemovePath(output);
            }
            return input;
        }
    }
}
