﻿using EZReconApp.Model;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EZReconApp
{
    /// <summary>
    /// Class to handle the summary details of the recon process
    /// </summary>
    public class SummaryManager
    {
        public static Dictionary<string, List<ReconSummary>> reconSummaryDictionary = new Dictionary<string,List<ReconSummary>>();
        public static List<ReconSummary> listOfReconSummary = new List<ReconSummary>();
        private static DateTime summaryDate = DateTime.Now.AddDays(-1);
        static int AgentId = 0;
        static int Txn_type_cd = 0;
        
        /// <summary>
        /// Method to read the summary results and group based on channel and summary match type.
        /// </summary>       
        public static void ReadSummaryData(OracleDataReader reader, SummaryMatchType recordType)
        {
            //summaryDate = DateTime.Now.AddDays(-1);
            if (reader.HasRows)
            {
                ReconSummary reconSummary = null;
                while (reader.Read())
                {
                    reconSummary = new ReconSummary(reader, recordType);
                    if (recordType == SummaryMatchType.Matched)
                    {
                        listOfReconSummary.Add(reconSummary);
                    }
                    else
                    {
                        string channel = Constants.ChannelDictionary[reconSummary.AGENT_ID + "_" + reconSummary.TXN_TYPE];
                        if (reconSummaryDictionary.ContainsKey(channel))
                        {
                            List<ReconSummary> listOfSummaries = reconSummaryDictionary[channel];
                            if ((recordType == SummaryMatchType.AnoC) || (recordType == SummaryMatchType.CnoA) ||
                                (recordType == SummaryMatchType.B1noA) || (recordType == SummaryMatchType.B2noC) || 
                                (recordType == SummaryMatchType.RAVExceptions))
                            {
                                listOfSummaries.Add(reconSummary);
                            }
                            else if ((recordType == SummaryMatchType.AnoC_Today) || (recordType == SummaryMatchType.CnoA_Today) ||
                                     (recordType == SummaryMatchType.B1noA_Today) || (recordType == SummaryMatchType.B2noC_Today))
                            {                                
                                ReconSummary recentReconSummary = listOfSummaries.Find(x => x.ProcessingCMDate.Date == summaryDate.Date);
                                if (recentReconSummary != null)
                                {
                                    if (recordType == SummaryMatchType.AnoC_Today)
                                    {
                                        recentReconSummary.NumberOfAnoCRecords = reconSummary.NumberOfAnoCRecords;
                                        recentReconSummary.TotalValueOfAnoCRecords = reconSummary.TotalValueOfAnoCRecords;
                                    }
                                    else if (recordType == SummaryMatchType.CnoA_Today)
                                    {
                                        recentReconSummary.NumberOfCnoARecords = reconSummary.NumberOfCnoARecords;
                                        recentReconSummary.TotalValueOfCnoARecords = reconSummary.TotalValueOfCnoARecords;
                                    }
                                    else if (recordType == SummaryMatchType.B1noA_Today)
                                    {
                                        recentReconSummary.NumberOfB1noARecords = reconSummary.NumberOfB1noARecords;
                                        recentReconSummary.TotalValueOfB1noARecords = reconSummary.TotalValueOfB1noARecords;
                                    }
                                    else if (recordType == SummaryMatchType.B2noC_Today)
                                    {
                                        recentReconSummary.NumberOfB2noCRecords = reconSummary.NumberOfB2noCRecords;
                                        recentReconSummary.TotalValueOfB2noCRecords = reconSummary.TotalValueOfB2noCRecords;
                                    }                                    
                                }
                            }

                        }
                        else
                        {
                            reconSummaryDictionary.Add(channel, new List<ReconSummary>() { reconSummary });
                        }
                    }
                }
            }
            else
            {                
                if (recordType == SummaryMatchType.Matched)
                {
                    //need to set date to processing date instead of min value date
                    listOfReconSummary.Add(new ReconSummary(recordType,AgentId,Txn_type_cd,summaryDate));
                }
            }
        }

        /// <summary>
        /// Method to write summary details to the summary report.
        /// </summary>  
        public static void CreateReconSummaryReport(string fileNameDate)
        {
            string summaryReportPath = string.Format(Constants.SummaryReportPath, fileNameDate);
            //string summaryDateString = summaryDate.ToString("dd-MMM-yy");
            FileInfo fileInfo = new FileInfo(summaryReportPath);
            if (!fileInfo.Directory.Exists)
            {
                System.IO.Directory.CreateDirectory(fileInfo.DirectoryName);
            }
            StringBuilder sb = new StringBuilder();
            StreamWriter sw = new StreamWriter(summaryReportPath,true);
            if (fileInfo.Length == 0)
            {
                sb.AppendLine("Summary - matched / unmatched Report ");
                sb.AppendLine(Constants.SummaryLegendString);
            }
            List<string> keyList = new List<string>(reconSummaryDictionary.Keys);
            keyList.Sort();
            List<ReconSummary> listOfReconSummary = null;
            foreach (string key in keyList)
            {
                if((key == Constants.Online_Channel) || (key == Constants.OCBCMobile_Channel))
                {
                    continue;
                }
                sb.AppendLine();
                sb.AppendLine("Data based on " + key);
                sb.AppendLine("         ,           ,           ,            ,            ,            ,            ,Match + A-no-C,                  ,Match + C-no-A,                  ");
                sb.AppendLine("         ,Match count,Match value,A-no-C count,A-no-C value,C-no-A count,C-no-A value,BANK Count Total,BANK Value Total,CMCC Count Total,CMCC Value Total");
                listOfReconSummary = reconSummaryDictionary[key];
                listOfReconSummary = listOfReconSummary.OrderByDescending(x => x.ProcessingCMDate).ToList();

                List<ReconSummary> listOfRAVExceptions = listOfReconSummary.Where(x => x.NumberOfMatchedRAVRecords > 0).ToList(); 
                if (listOfRAVExceptions != null && listOfRAVExceptions.Count > 0)
                {
                    listOfReconSummary.RemoveAll(x => x.NumberOfMatchedRAVRecords > 0);
                    listOfReconSummary.AddRange(listOfRAVExceptions);
                }                
                if (listOfReconSummary != null && listOfReconSummary.Count > 0)
                {

                    IEnumerable<ReconSummary> currentDayRecords = listOfReconSummary.Where(x => x.ProcessingCMDate.Date == summaryDate.Date);
                    ReconSummary currentDayRecord = null;
                    if (currentDayRecords.Any())
                    {
                        currentDayRecord = currentDayRecords.FirstOrDefault();
                    }
                    bool ravRowShown = false;
                    
                    double bankTotalValue = 0;
                    long bankTotalCount = CalculateBankTotals(listOfReconSummary, out bankTotalValue, string.Empty);
                    double cmccTotalValue = 0;
                    long cmccTotalCount = CalculateCMCCTotals(listOfReconSummary, out cmccTotalValue, string.Empty);

                    foreach (ReconSummary reconSummary in listOfReconSummary)
                    {
                        if (summaryDate.Date == reconSummary.ProcessingCMDate.Date)
                        {
                            if (reconSummary.NumberOfMatchedRAVRecords == 0)
                            {
                                sb.AppendLine(reconSummary.ProcessingCMDate + "," + reconSummary.NumberOfMatchedRecords + "," + Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) +
                                    "," + reconSummary.NumberOfAnoCRecords + "," + Math.Round(reconSummary.TotalValueOfAnoCRecords, 2) +
                                    "," + reconSummary.NumberOfCnoARecords + "," + Math.Round(reconSummary.TotalValueOfCnoARecords, 2) +
                                    //"," + (reconSummary.NumberOfMatchedRecords + reconSummary.NumberOfAnoCRecords) +
                                    //"," + (Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) + Math.Round(reconSummary.TotalValueOfAnoCRecords, 2)) +
                                    "," + bankTotalCount +
                                    "," + bankTotalValue +
                                    "," + cmccTotalCount +
                                    "," + cmccTotalValue);
                            }
                        }
                        else if (reconSummary.ProcessingCMDate.Date == DateTime.MinValue.AddDays(2).Date)
                        {
                            int numberOfCnoARecords = reconSummary.NumberOfCnoARecords;
                            double totalValueOfCnoARecords = reconSummary.TotalValueOfCnoARecords;
                            #if (false) // Feedback by Rowena on Jan19 2018 to tally up..
                            if (currentDayRecord != null)
                            {
                                numberOfCnoARecords = numberOfCnoARecords - currentDayRecord.NumberOfCnoARecords;
                                totalValueOfCnoARecords = totalValueOfCnoARecords - currentDayRecord.TotalValueOfCnoARecords;
                            }
                            #endif
                            if (numberOfCnoARecords > 0)
                            {
                                sb.AppendLine("C-no-A cumulative" + "," + "-" + "," + "-" +
                                     "," + "-" + "," + "-" +
                                    "," + numberOfCnoARecords + "," + totalValueOfCnoARecords +
                                    "," + "-" + "," + "-" +
                                    "," + "-" + "," + "-");
                            }

                        }
                        else if (reconSummary.ProcessingCMDate.Date == DateTime.MinValue.AddDays(3).Date)
                        {
                            int numberOfAnoCRecords = reconSummary.NumberOfAnoCRecords;
                            double totalValueOfAnoCRecords = reconSummary.TotalValueOfAnoCRecords;
                            #if (false) // Feedback by Rowena on Jan19 2018 to tally up..
                            if (currentDayRecord != null)
                            {
                                numberOfAnoCRecords = numberOfAnoCRecords - currentDayRecord.NumberOfAnoCRecords;
                                totalValueOfAnoCRecords = totalValueOfAnoCRecords - currentDayRecord.TotalValueOfAnoCRecords;
                            }
                            #endif
                            if (numberOfAnoCRecords > 0)
                            {
                                sb.AppendLine("A-no-C cumulative" + "," + "-" + "," + "-" +
                                   "," + numberOfAnoCRecords + "," + totalValueOfAnoCRecords +
                                   "," + "-" + "," + "-" +
                                   "," + "-" + "," + "-" +
                                   "," + "-" + "," + "-");
                            }
                        }
                        else
                        {
                            if (reconSummary.NumberOfMatchedRecords > 0)
                            {
                                sb.AppendLine(reconSummary.ProcessingCMDate + "," + reconSummary.NumberOfMatchedRecords + "," + Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) +
                                    "," + "-" + "," + "-" +
                                    "," + "-" + "," + "-" +
                                    "," + "-" + "," + "-" +
                                    "," + "-" + "," + "-");
                            }
                        }
                        if (reconSummary.NumberOfMatchedRAVRecords > 0)
                        {
                            if (!ravRowShown)
                            {
                                sb.AppendLine("");
                                sb.AppendLine("RAV and Exceptions");
                                ravRowShown = true;
                            }
                            sb.AppendLine(reconSummary.ProcessingCMDate.ToString("MM/dd/yyyy") + "," + reconSummary.NumberOfMatchedRAVRecords + "," + Math.Round(reconSummary.TotalValueOfMatchedRAVRecords, 2));
                        }
                    }
                }
            }
            CreateOnlineOCBCSummaryReport(sb);
            sw.Write(sb.ToString());
            sw.Close();
        }

        private static long CalculateBankTotals(List<ReconSummary> listOfReconSummary, out double bankTotalValue, string channel)
        {
            long bankTotalCount = 0;
            bankTotalValue = 0;
            foreach (ReconSummary reconSummary in listOfReconSummary)
            {
                if (channel == Constants.Online_Channel)
                {
                    if (summaryDate.Date == reconSummary.ProcessingCMDate.Date)
                    {
                        bankTotalCount = bankTotalCount + reconSummary.NumberOfMatchedRecords + reconSummary.NumberOfAnoCRecords;
                        bankTotalValue = bankTotalValue + (Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) + Math.Round(reconSummary.TotalValueOfAnoCRecords, 2));
                    }
                    else if ((reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(2).Date) &&
                        (reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(3).Date) &&
                        (reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(1).Date) &&
                        (reconSummary.ProcessingCMDate.Date != DateTime.MinValue.Date))
                    {
                        bankTotalCount = bankTotalCount + reconSummary.NumberOfMatchedRecords;
                        bankTotalValue = bankTotalValue + Math.Round(reconSummary.TotalValueOfMatchedRecords, 2);
                    }
                }
                else
                {
                    if (summaryDate.Date == reconSummary.ProcessingCMDate.Date)
                    {
                        bankTotalCount = bankTotalCount + reconSummary.NumberOfMatchedRecords + reconSummary.NumberOfAnoCRecords;
                        bankTotalValue = bankTotalValue + (Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) + Math.Round(reconSummary.TotalValueOfAnoCRecords, 2));
                    }
                    else if ((reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(2).Date) &&
                        (reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(3).Date))
                    {
                        bankTotalCount = bankTotalCount + reconSummary.NumberOfMatchedRecords;
                        bankTotalValue = bankTotalValue + Math.Round(reconSummary.TotalValueOfMatchedRecords, 2);
                    }
                }
            }
            return bankTotalCount;
        }


        private static long CalculateCMCCTotals(List<ReconSummary> listOfReconSummary, out double cmccTotalValue, string channel)
        {
            long cmccTotalCount = 0;
            cmccTotalValue = 0;
            foreach (ReconSummary reconSummary in listOfReconSummary)
            {
                if (channel == Constants.Online_Channel)
                {
                    if (summaryDate.Date == reconSummary.ProcessingCMDate.Date)
                    {
                        cmccTotalCount = cmccTotalCount + reconSummary.NumberOfMatchedRecords + reconSummary.NumberOfCnoARecords + reconSummary.NumberOfMatchedRAVRecords;
                        cmccTotalValue = cmccTotalValue + (Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) + Math.Round(reconSummary.TotalValueOfCnoARecords, 2) + Math.Round(reconSummary.TotalValueOfMatchedRAVRecords, 2));
                    }
                    else if ((reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(2).Date) &&
                        (reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(3).Date) &&
                        (reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(1).Date) &&
                        (reconSummary.ProcessingCMDate.Date != DateTime.MinValue.Date))
                    {
                        if (reconSummary.NumberOfMatchedRAVRecords > 0)
                        {
                            cmccTotalCount = cmccTotalCount + reconSummary.NumberOfMatchedRAVRecords;
                            cmccTotalValue = cmccTotalValue + Math.Round(reconSummary.TotalValueOfMatchedRAVRecords, 2);
                        }
                    }
                }
                else
                {
                    if (summaryDate.Date == reconSummary.ProcessingCMDate.Date)
                    {
                        cmccTotalCount = cmccTotalCount + reconSummary.NumberOfMatchedRecords + reconSummary.NumberOfCnoARecords + reconSummary.NumberOfMatchedRAVRecords;
                        cmccTotalValue = cmccTotalValue + (Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) + Math.Round(reconSummary.TotalValueOfCnoARecords, 2) + Math.Round(reconSummary.TotalValueOfMatchedRAVRecords, 2));
                    }
                    else if ((reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(2).Date) &&
                        (reconSummary.ProcessingCMDate.Date != DateTime.MinValue.AddDays(3).Date))
                    {
                        if (reconSummary.NumberOfMatchedRAVRecords > 0)
                        {
                            cmccTotalCount = cmccTotalCount + reconSummary.NumberOfMatchedRAVRecords;
                            cmccTotalValue = cmccTotalValue + Math.Round(reconSummary.TotalValueOfMatchedRAVRecords, 2);
                        }
                    }
                }
            }
            return cmccTotalCount;
        }


        /// <summary>
        /// Method to group the summary data into dictionary based on the channel.
        /// </summary>  
        public static void ProcessSummaryResults()
        {
            if (listOfReconSummary != null && listOfReconSummary.Count > 0)
            {
                foreach (ReconSummary reconSummary in listOfReconSummary)
                {
                    string channel = Constants.ChannelDictionary[reconSummary.AGENT_ID + "_" + reconSummary.TXN_TYPE];

                    if (reconSummaryDictionary.ContainsKey(channel))
                    {
                        reconSummaryDictionary[channel].Add(reconSummary);
                    }
                    else
                    {
                        reconSummaryDictionary.Add(channel, new List<ReconSummary>() { reconSummary });
                    }
                }
            }
        }

        /// <summary>
        /// Method reads each summary result and processes summary details for every channel.
        /// </summary>  
        public static void ProcessSummary(DateTime processingDateTime, string fileNameDate, int agentId, int txn_type_cd, bool runForSpecificDateOnly = false)
        {
            OracleDataReader reader = null;
            reconSummaryDictionary = new Dictionary<string,List<ReconSummary>>();
            listOfReconSummary = new List<ReconSummary>();
            summaryDate = processingDateTime;
            AgentId = agentId;
            Txn_type_cd = txn_type_cd;
            string processingDateTimeString = processingDateTime.ToString(Constants.ProcessingDateFormat);
            try
            {
                using (OracleConnection connection = new OracleConnection())
                {
                    connection.ConnectionString = Constants.ConnectionString;
                    using (OracleCommand command = connection.CreateCommand())
                    {
                        connection.Open();
                        try
                        {
                            //Match Summary Details        
                            command.CommandText = 
                                string.Format("select TRUNC(PROCESSING_DATE_TIME) AS CMPRC_DATE_TIME,count(*) AS MATCHED_COUNT,sum(AMOUNT) AS MATCHED_SUM,AGENT_ID,TXN_TYPE " +
                              "FROM TRX2_MATCHSTATUS WHERE (TRUNC(MATCHED_ENTRY_DATE) = TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS'))) AND ((MATCHING_REMARK IS NULL) OR ((MATCHING_REMARK IS NOT NULL) AND ((MATCHING_REMARK LIKE '%/%')))) AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by TRUNC(PROCESSING_DATE_TIME), AGENT_ID,TXN_TYPE",
                              processingDateTimeString, agentId, txn_type_cd);
                            //TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS'))) AND
                            reader = command.ExecuteReader();                                
                            SummaryManager.ReadSummaryData(reader, SummaryMatchType.Matched);
                            SummaryManager.ProcessSummaryResults();

                            //AnoC UnMatch Today Summary Details
                            command.CommandText =
                                string.Format("select TRUNC(PROCESSING_DATE_TIME) AS CMPRC_DATE_TIME,count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                             "FROM TRX2_MATCHSTATUS WHERE (TRUNC(MATCHED_ENTRY_DATE) IS NULL AND UNMATCHED_TYPE = 'A-no-C' AND (TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS')))) AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by TRUNC(PROCESSING_DATE_TIME), AGENT_ID,TXN_TYPE",
                                processingDateTimeString, agentId, txn_type_cd);                            
                            reader = command.ExecuteReader();                            
                            SummaryManager.ReadSummaryData(reader, SummaryMatchType.AnoC_Today);
                            
                            //CnoA UnMatch Today Summary Details
                            
                            command.CommandText =
                            string.Format("select TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS')) AS CMPRC_DATE_TIME,count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                             "FROM TRX2_MATCHSTATUS WHERE ((((TRUNC(MATCHED_ENTRY_DATE) IS NULL AND UNMATCHED_TYPE = 'C-no-A' AND (TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS'))))))) " +        
                             "AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by AGENT_ID,TXN_TYPE",processingDateTimeString, agentId, txn_type_cd);

                            //" ((TRUNC(MATCHED_ENTRY_DATE) = TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS'))) AND (MATCHING_REMARK IS NOT NULL) AND (MATCHING_REMARK NOT LIKE '%/%'))) " +  
                            //(TRUNC(MATCHED_ENTRY_DATE) = TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS')) AND UNMATCHED_TYPE = 'MATCHED' AND (TRUNC(PROCESSING_DATE_TIME) < TRUNC(MATCHED_ENTRY_DATE))) OR 
                            /*command.CommandText =
                           string.Format("select TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS')) AS CMPRC_DATE_TIME,count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                            "FROM TRX2_MATCHSTATUS WHERE (TRUNC(MATCHED_ENTRY_DATE) IS NULL AND UNMATCHED_TYPE = 'C-no-A' AND (TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS')))) " +                            
                            "AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by AGENT_ID,TXN_TYPE", processingDateTimeString, agentId, txn_type_cd);                            
                           */
                            reader = command.ExecuteReader();   
                            SummaryManager.ReadSummaryData(reader, SummaryMatchType.CnoA_Today);
                            
                            //AnoC UnMatch Summary Details
                            command.CommandText =
                            string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                             "FROM TRX2_MATCHSTATUS WHERE (TRUNC(MATCHED_ENTRY_DATE) IS NULL AND UNMATCHED_TYPE = 'A-no-C')  AND AGENT_ID = '{0}' AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE", 
                             agentId, txn_type_cd);
                            if (runForSpecificDateOnly)
                            {
                                command.CommandText =                            
                                    string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +                             
                                    "FROM TRX2_MATCHSTATUS WHERE (TRUNC(MATCHED_ENTRY_DATE) IS NULL AND UNMATCHED_TYPE = 'A-no-C')  AND AGENT_ID = '{0}' AND (TRUNC(PROCESSING_DATE_TIME) <= TRUNC(to_date(('{2} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",                             
                                    agentId, txn_type_cd, processingDateTimeString);
                            }
                            reader = command.ExecuteReader(); 
                            SummaryManager.ReadSummaryData(reader, SummaryMatchType.AnoC);
                            
                            //CnoA UnMatch Summary Details
                            command.CommandText =
                            string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                             "FROM TRX2_MATCHSTATUS WHERE (TRUNC(MATCHED_ENTRY_DATE) IS NULL AND UNMATCHED_TYPE = 'C-no-A')  AND AGENT_ID = '{0}' AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                             agentId, txn_type_cd);
                            if (runForSpecificDateOnly)
                            {
                                command.CommandText =
                           string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                            "FROM TRX2_MATCHSTATUS WHERE (TRUNC(MATCHED_ENTRY_DATE) IS NULL AND UNMATCHED_TYPE = 'C-no-A')  AND AGENT_ID = '{0}' AND (TRUNC(PROCESSING_DATE_TIME) <= TRUNC(to_date(('{2} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                            agentId, txn_type_cd, processingDateTimeString);
                            }
                            reader = command.ExecuteReader(); 
                            SummaryManager.ReadSummaryData(reader, SummaryMatchType.CnoA);                                                     

                            if (agentId == Constants.CONST_AGENTID_ONLINE ||
                                agentId == Constants.CONST_AGENTID_OCBCMOBILE)
                            {

                                //AnoB1 UnMatch Summary Details
                                command.CommandText =
                                string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'A-no-B1') OR (UNMATCHED_TYPE = 'AB1-no-CB2')) AND AGENT_ID = '{0}' AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                                 agentId, txn_type_cd);
                                if (runForSpecificDateOnly)
                                {
                                    command.CommandText =
                                string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'A-no-B1') OR (UNMATCHED_TYPE = 'AB1-no-CB2')) AND AGENT_ID = '{0}' AND (TRUNC(PROCESSING_DATE_TIME) <= TRUNC(to_date(('{2} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                                 agentId, txn_type_cd,processingDateTimeString);

                                }
                                reader = command.ExecuteReader();
                                SummaryManager.ReadSummaryData(reader, SummaryMatchType.AnoC);

                                //CnoB2 UnMatch Summary Details
                                command.CommandText =
                                string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'C-no-B2') OR (UNMATCHED_TYPE = 'CB2-no-AB1')) AND AGENT_ID = '{0}' AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                                 agentId, txn_type_cd);
                                if (runForSpecificDateOnly)
                                {
                                    command.CommandText =
                                string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'C-no-B2') OR (UNMATCHED_TYPE = 'CB2-no-AB1')) AND AGENT_ID = '{0}' AND (TRUNC(PROCESSING_DATE_TIME) <= TRUNC(to_date(('{2} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                                 agentId, txn_type_cd, processingDateTimeString);
                                }
                                reader = command.ExecuteReader();
                                SummaryManager.ReadSummaryData(reader, SummaryMatchType.CnoA);

                                //B1noA UnMatch Summary Details
                                command.CommandText =
                                string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'B1-no-A')) AND AGENT_ID = '{0}' AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                                 agentId, txn_type_cd);
                                if (runForSpecificDateOnly)
                                {
                                    command.CommandText =
                                string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'B1-no-A')) AND AGENT_ID = '{0}' AND (TRUNC(PROCESSING_DATE_TIME) <= TRUNC(to_date(('{2} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                                 agentId, txn_type_cd, processingDateTimeString);
                                }
                                reader = command.ExecuteReader();
                                SummaryManager.ReadSummaryData(reader, SummaryMatchType.B1noA);

                                //B2noC UnMatch Summary Details    
                                command.CommandText =
                                string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'B2-no-C')) AND AGENT_ID = '{0}' AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                                 agentId, txn_type_cd);
                                if (runForSpecificDateOnly)
                                {
                                    command.CommandText =
                                string.Format("select  count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'B2-no-C')) AND AGENT_ID = '{0}' AND (TRUNC(PROCESSING_DATE_TIME) <= TRUNC(to_date(('{2} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND TXN_TYPE = '{1}' group by AGENT_ID,TXN_TYPE",
                                 agentId, txn_type_cd,processingDateTimeString);

                                }
                                reader = command.ExecuteReader();
                                SummaryManager.ReadSummaryData(reader, SummaryMatchType.B2noC);

                                //AnoB1 UnMatch Today Summary Details
                                command.CommandText =
                                string.Format("select  TRUNC(PROCESSING_DATE_TIME) AS CMPRC_DATE_TIME,count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'A-no-B1') OR (UNMATCHED_TYPE = 'AB1-no-CB2')) AND (TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS')))  AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by TRUNC(PROCESSING_DATE_TIME),AGENT_ID,TXN_TYPE",
                                 processingDateTimeString, agentId, txn_type_cd);                                
                                reader = command.ExecuteReader();
                                SummaryManager.ReadSummaryData(reader, SummaryMatchType.AnoC_Today);

                                //CnoB2 UnMatch Today Summary Details
                                command.CommandText =
                                 string.Format("select  TRUNC(PROCESSING_DATE_TIME) AS CMPRC_DATE_TIME,count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                  "FROM TRX2_MATCHSTATUS WHERE ((((TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'C-no-B2') OR (UNMATCHED_TYPE = 'CB2-no-AB1')) AND (TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS'))))))) " +                                                              
                                  "AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by TRUNC(PROCESSING_DATE_TIME),AGENT_ID,TXN_TYPE",
                                  processingDateTimeString, agentId, txn_type_cd);
                                //"((TRUNC(MATCHED_ENTRY_DATE) = TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS'))) AND (MATCHING_REMARK IS NOT NULL) AND (MATCHING_REMARK NOT LIKE '%/%'))) " + 
                                //(TRUNC(MATCHED_ENTRY_DATE) = TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS')) AND UNMATCHED_TYPE = 'MATCHED' AND (TRUNC(PROCESSING_DATE_TIME) < TRUNC(MATCHED_ENTRY_DATE))) OR 
                                reader = command.ExecuteReader();
                                SummaryManager.ReadSummaryData(reader, SummaryMatchType.CnoA_Today);

                                //B1noA UnMatch Today Summary Details
                                command.CommandText =
                                string.Format("select  TRUNC(PROCESSING_DATE_TIME) AS CMPRC_DATE_TIME,count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'B1-no-A')) AND (TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND (TRUNC(TRANSACTION_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by TRUNC(PROCESSING_DATE_TIME),AGENT_ID,TXN_TYPE",
                                 processingDateTimeString, agentId, txn_type_cd);                                
                                reader = command.ExecuteReader();
                                SummaryManager.ReadSummaryData(reader, SummaryMatchType.B1noA_Today);

                                //B2noC UnMatch Today Summary Details
                                command.CommandText =
                                string.Format("select  TRUNC(PROCESSING_DATE_TIME) AS CMPRC_DATE_TIME,count(*) AS UNMATCHED_COUNT,sum(AMOUNT) AS UNMATCHED_SUM,AGENT_ID,TXN_TYPE " +
                                 "FROM TRX2_MATCHSTATUS WHERE TRUNC(MATCHED_ENTRY_DATE) IS NULL AND ((UNMATCHED_TYPE = 'B2-no-C')) AND (TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND (TRUNC(TRANSACTION_DATE_TIME) = TRUNC(to_date(('{0} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by TRUNC(PROCESSING_DATE_TIME),AGENT_ID,TXN_TYPE",
                                 processingDateTimeString, agentId, txn_type_cd);                                
                                reader = command.ExecuteReader();
                                SummaryManager.ReadSummaryData(reader, SummaryMatchType.B2noC_Today);
                            }

                            //RAVException  Summary Details        
                            command.CommandText =
                                string.Format("select TRUNC(TRANSACTION_DATE_TIME) AS CMPRC_DATE_TIME,count(*) AS MATCHED_COUNT,sum(AMOUNT) AS MATCHED_SUM,AGENT_ID,TXN_TYPE " +
                              "FROM TRX2_MATCHSTATUS WHERE (TRUNC(MATCHED_ENTRY_DATE) = TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS'))) AND (MATCHING_REMARK IS NOT NULL) AND (MATCHING_REMARK NOT LIKE '%/%') AND AGENT_ID = '{1}' AND TXN_TYPE = '{2}' group by TRUNC(TRANSACTION_DATE_TIME), AGENT_ID,TXN_TYPE",
                              processingDateTimeString, agentId, txn_type_cd);
                            //TRUNC(PROCESSING_DATE_TIME) = TRUNC(to_date('{0} 00:00:00','dd-MM-yy HH24:mi:SS'))) AND
                            reader = command.ExecuteReader();
                            SummaryManager.ReadSummaryData(reader, SummaryMatchType.RAVExceptions);    

                            SummaryManager.CreateReconSummaryReport(fileNameDate);
                        }
                        catch (Exception exception)
                        {
                            Logger.DailyLog("Error : Exception caught in ProcessSummary " + exception.Message);
                            Logger.DailyLog("Error : Exception stack trace is " + exception.StackTrace);  
                            throw exception;
                        }
                    }
                } 
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : Exception caught in ProcessSummary " + exception.Message);
                Logger.DailyLog("Error : Exception stack trace is " + exception.StackTrace);  
                throw exception; 
            }
        } 

        /// <summary>
        /// Method to write Online and OCBCMobile summary to the summary report.
        /// </summary>        
        public static void CreateOnlineOCBCSummaryReport(StringBuilder sb)
        {
            List<string> keys = new List<string> { Constants.Online_Channel, Constants.OCBCMobile_Channel };
            List<ReconSummary> listOfReconSummary = null;
            foreach (string key in keys)
            {
                if (reconSummaryDictionary.Keys.Contains(key))
                {

                    sb.AppendLine();
                    sb.AppendLine("Data based on " + key);
                    sb.AppendLine("         ,           ,           ,           ,           ,           ,           ,            ,            ,            ,            ,Match + A-no-C,                  ,Match + C-no-A,                  ");
                    sb.AppendLine("         ,Match count,Match value,B1-no-A count,B1-no-A value,B2-no-C count,B2-no-C value,C-no-Match count,C-no-Match value,A-no-Match count,A-no-Match value,BANK Count Total,BANK Value Total,CMCC Count Total,CMCC Value Total");
                    listOfReconSummary = reconSummaryDictionary[key];
                    listOfReconSummary = listOfReconSummary.OrderByDescending(x => x.ProcessingCMDate).ToList();

                    List<ReconSummary> listOfRAVExceptions = listOfReconSummary.Where(x => x.NumberOfMatchedRAVRecords > 0).ToList();
                    if (listOfRAVExceptions != null && listOfRAVExceptions.Count > 0)
                    {
                        listOfReconSummary.RemoveAll(x => x.NumberOfMatchedRAVRecords > 0);
                        listOfReconSummary.AddRange(listOfRAVExceptions);
                    }    

                    if (listOfReconSummary != null && listOfReconSummary.Count > 0)
                    {
                        IEnumerable<ReconSummary> currentDayRecords = listOfReconSummary.Where(x => x.ProcessingCMDate.Date == summaryDate.Date);
                        ReconSummary currentDayRecord = null;
                        if(currentDayRecords.Any())
                        {
                            currentDayRecord = currentDayRecords.FirstOrDefault();
                        }

                        double bankTotalValue = 0;
                        long bankTotalCount = CalculateBankTotals(listOfReconSummary, out bankTotalValue, Constants.Online_Channel);
                        double cmccTotalValue = 0;
                        long cmccTotalCount = CalculateCMCCTotals(listOfReconSummary, out cmccTotalValue, Constants.Online_Channel);

                        bool ravRowShown = false;

                        foreach (ReconSummary reconSummary in listOfReconSummary)
                        {
                            if (summaryDate.Date == reconSummary.ProcessingCMDate.Date)
                            {
                                if (reconSummary.NumberOfMatchedRAVRecords == 0)
                                {
                                    sb.AppendLine(reconSummary.ProcessingCMDate + "," + reconSummary.NumberOfMatchedRecords + "," + Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) +
                                        "," + reconSummary.NumberOfB1noARecords + "," + Math.Round(reconSummary.TotalValueOfB1noARecords, 2) +
                                        "," + reconSummary.NumberOfB2noCRecords + "," + Math.Round(reconSummary.TotalValueOfB2noCRecords, 2) +
                                        "," + reconSummary.NumberOfCnoARecords + "," + Math.Round(reconSummary.TotalValueOfCnoARecords, 2) +
                                        "," + reconSummary.NumberOfAnoCRecords + "," + Math.Round(reconSummary.TotalValueOfAnoCRecords, 2) +
                                        //"," + (reconSummary.NumberOfMatchedRecords + reconSummary.NumberOfAnoCRecords) +
                                        //"," + (Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) + Math.Round(reconSummary.TotalValueOfAnoCRecords, 2)) +
                                        "," + bankTotalCount +
                                        "," + bankTotalValue +
                                        "," + cmccTotalCount +
                                        "," + cmccTotalValue);
                                }
                            }
                            else if (reconSummary.ProcessingCMDate.Date == DateTime.MinValue.Date)
                            {
                                int numberOfB2noCRecords = reconSummary.NumberOfB2noCRecords;
                                double totalValueOfB2noCRecords = reconSummary.TotalValueOfB2noCRecords;
                                #if (false) // Feedback by Rowena on Jan19 2018 to tally up..
                                if (currentDayRecord != null)
                                {
                                    numberOfB2noCRecords = numberOfB2noCRecords - currentDayRecord.NumberOfB2noCRecords;
                                    totalValueOfB2noCRecords = totalValueOfB2noCRecords - currentDayRecord.TotalValueOfB2noCRecords;
                                }
                                #endif
                                if (numberOfB2noCRecords > 0)
                                {
                                    sb.AppendLine("B2-no-C cumulative" + "," + "-" + "," + "-" +
                                         "," + "-" + "," + "-" +
                                        "," + numberOfB2noCRecords + "," + totalValueOfB2noCRecords +
                                        "," + "-" + "," + "-" +
                                        "," + "-" + "," + "-" +
                                        "," + "-" + "," + "-" +
                                        "," + "-" + "," + "-");
                                }

                            }
                            else if (reconSummary.ProcessingCMDate.Date == DateTime.MinValue.AddDays(1).Date)
                            {
                                int numberOfB1noARecords = reconSummary.NumberOfB1noARecords;
                                double totalValueOfB1noARecords = reconSummary.TotalValueOfB1noARecords;
                                #if (false) // Feedback by Rowena on Jan19 2018 to tally up..
                                if (currentDayRecord != null)
                                {
                                    numberOfB1noARecords = numberOfB1noARecords - currentDayRecord.NumberOfB1noARecords;
                                    totalValueOfB1noARecords = totalValueOfB1noARecords - currentDayRecord.TotalValueOfB1noARecords;
                                }
                                #endif
                                if (numberOfB1noARecords > 0)
                                {
                                    sb.AppendLine("B1-no-A cumulative" + "," + "-" + "," + "-" +
                                       "," + numberOfB1noARecords + "," + totalValueOfB1noARecords +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-");
                                }
                            }
                            else if (reconSummary.ProcessingCMDate.Date == DateTime.MinValue.AddDays(2).Date)
                            {
                                int numberOfCnoARecords = reconSummary.NumberOfCnoARecords;
                                double totalValueOfCnoARecords = reconSummary.TotalValueOfCnoARecords;
                                #if (false) // Feedback by Rowena on Jan19 2018 to tally up..
                                if (currentDayRecord != null)
                                {
                                    numberOfCnoARecords = numberOfCnoARecords - currentDayRecord.NumberOfCnoARecords;
                                    totalValueOfCnoARecords = totalValueOfCnoARecords - currentDayRecord.TotalValueOfCnoARecords;
                                }
                                #endif
                                if (numberOfCnoARecords > 0)
                                {
                                    sb.AppendLine("C-no-Match cumulative" + "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + numberOfCnoARecords + "," + totalValueOfCnoARecords +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-");
                                }
                            }
                            else if (reconSummary.ProcessingCMDate.Date == DateTime.MinValue.AddDays(3).Date)
                            {
                                int numberOfAnoCRecords = reconSummary.NumberOfAnoCRecords;
                                double totalValueOfAnoCRecords = reconSummary.TotalValueOfAnoCRecords;
                                #if (false) // Feedback by Rowena on Jan19 2018 to tally up..
                                if (currentDayRecord != null)
                                {
                                    numberOfAnoCRecords = numberOfAnoCRecords - currentDayRecord.NumberOfAnoCRecords;
                                    totalValueOfAnoCRecords = totalValueOfAnoCRecords - currentDayRecord.TotalValueOfAnoCRecords;
                                }
                                #endif
                                if (numberOfAnoCRecords > 0)
                                {
                                    sb.AppendLine("A-no-Match cumulative" + "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-" +
                                       "," + numberOfAnoCRecords + "," + totalValueOfAnoCRecords +
                                       "," + "-" + "," + "-" +
                                       "," + "-" + "," + "-");
                                }
                            }
                            else
                            {
                                if (reconSummary.NumberOfMatchedRecords > 0)
                                {
                                    sb.AppendLine(reconSummary.ProcessingCMDate + "," + reconSummary.NumberOfMatchedRecords + "," + Math.Round(reconSummary.TotalValueOfMatchedRecords, 2) +
                                        "," + "-" + "," + "-" +
                                        "," + "-" + "," + "-" +
                                        "," + "-" + "," + "-" +
                                        "," + "-" + "," + "-" +
                                        "," + "-" + "," + "-" +
                                        "," + "-" + "," + "-");
                                }
                            }
                            if (reconSummary.NumberOfMatchedRAVRecords > 0)
                            {
                                if (!ravRowShown)
                                {
                                    sb.AppendLine("");
                                    sb.AppendLine("RAV and Exceptions");
                                    ravRowShown = true;
                                }
                                sb.AppendLine(reconSummary.ProcessingCMDate.ToString("MM/dd/yyyy") + "," + reconSummary.NumberOfMatchedRAVRecords + "," + Math.Round(reconSummary.TotalValueOfMatchedRAVRecords, 2));
                            }
                        }
                    }
                }
            }
        }
    }

    public enum SummaryMatchType
    {
        Matched,
        AnoC_Today,
        CnoA_Today,
        AnoC,
        CnoA,
        B1noA_Today,
        B2noC_Today,
        B1noA,
        B2noC,
        RAVExceptions
    }
}
