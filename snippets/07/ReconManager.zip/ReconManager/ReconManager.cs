﻿using EZReconApp.Model;
using EZReconApp.Model.DatabaseModel;
using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;


namespace EZReconApp
{
    /// <summary>
    /// Manager class for Recon process
    /// </summary>
    public class ReconManager
    {
        private DateTime processingDateTime = DateTime.Now.AddDays(-1);//new DateTime(2016,10,08);
        private string fileNameDate = DateTime.Now.AddDays(-1).ToString(Constants.FileNameDateFormat);//"08_Oct_2016";
        private string processingDateTimeString = DateTime.Now.AddDays(-1).ToString(Constants.ProcessingDateFormat);//"08-10-16";
        bool runForSpecificDateOnly = false;
        /// <summary>
        /// Method to handle the recon process by calling the DAL methods.
        /// </summary>
        public void ProcessRecon(DateTime inputProcessDate)
        {
            try
            {
                runForSpecificDateOnly = false;
                if(inputProcessDate != DateTime.MinValue)
                {
                    Logger.DailyLog("Info : Argument passed to the application is " + inputProcessDate.ToString("dd-MM-yy"));                
                    runForSpecificDateOnly = true;
                    processingDateTime = inputProcessDate;
                    fileNameDate = inputProcessDate.ToString(Constants.FileNameDateFormat);
                    processingDateTimeString = inputProcessDate.ToString(Constants.ProcessingDateFormat);
                }
                Logger.DailyLog("Info : ReconManager.ProcessRecon method called");
                string summaryReportPath = string.Format(Constants.SummaryReportPath, fileNameDate);
                FileInfo fileInfo = new FileInfo(summaryReportPath);
                //if (!fileInfo.Directory.Exists)
                //{
                    int channelId = 0;
                    string channelName = string.Empty;
                    int txn_type_cd = Constants.CONST_TXN_TYPE_CD_TOPUP;
                    int txn_type = Constants.TXN_TYPE;
                    string tableName = Constants.TRX2_DETAILS_SRC1;
                    ReconDAL.PerformArchiveOfMatchedRecords(processingDateTimeString);
                    for (int i = 0; i < 5; i++)
                    {
                        if (i == 0)
                        {
                            channelId = Constants.CONST_AGENTID_AXS;
                            channelName = Constants.AXSChannel;
                        }
                        else if (i == 1)
                        {
                            channelId = Constants.CONST_AGENTID_DBSATM;
                            channelName = Constants.DBSATMChannel;
                        }
                        else if (i == 2)
                        {
                            channelId = Constants.CONST_AGENTID_OCBC;
                            channelName = Constants.OCBCTopUpChannel; 
                        }
                        else if (i == 3)
                        {
                            channelId = Constants.CONST_AGENTID_OCBC;
                            channelName = Constants.OCBCRefundChannel;
                            txn_type_cd = Constants.CONST_TXN_TYPE_CD_REFUND;
                            txn_type = 0;
                        }
                        else if (i == 4)
                        {
                            channelId = Constants.CONST_AGENTID_DBCC;
                            channelName = Constants.DBCCChannel;
                            tableName = Constants.TRX2_DETAILS_SRC9;
                            txn_type_cd = Constants.CONST_TXN_TYPE_CD_TOPUP;
                            txn_type = Constants.TXN_TYPE;
                        }
                        if (runForSpecificDateOnly)
                        {
                            if(processingDateTime < DateTime.Today.Date)
                            {
                                if (ReconDAL.CheckIfReconAlreadyRunForChannel(channelId, processingDateTime, txn_type) && 
                                    CheckIfInputImported(channelId, processingDateTime, txn_type))
                                {
                                    Logger.DailyLog("Info : Before calling PerformMatchingOfRecords for channel " + channelName);
                                    PerformMatchingOfRecords(channelId, channelName, txn_type_cd, txn_type, tableName);
                                    Logger.DailyLog("Info : Completed PerformMatchingOfRecords for channel " + channelName);
                                    ReconDAL.UpdateReconRunDetails(channelId, txn_type, processingDateTime);
                                    SummaryManager.ProcessSummary(processingDateTime, fileNameDate, channelId, txn_type_cd, runForSpecificDateOnly);
                                }
                            }
                        }
                        else
                        {
                            processingDateTime = PreCheckChannelReconDetails(channelId, txn_type);
                            processingDateTime = processingDateTime.AddDays(1).Date;
                            fileNameDate = processingDateTime.ToString(Constants.FileNameDateFormat);
                            processingDateTimeString = processingDateTime.ToString(Constants.ProcessingDateFormat);
                            while (processingDateTime < DateTime.Today.Date)
                            {
                                if (CheckIfInputImported(channelId, processingDateTime, txn_type))
                                {
                                    Logger.DailyLog("Info : Before calling PerformMatchingOfRecords for channel " + channelName);
                                    PerformMatchingOfRecords(channelId, channelName, txn_type_cd, txn_type, tableName);
                                    Logger.DailyLog("Info : Completed PerformMatchingOfRecords for channel " + channelName);
                                    ReconDAL.UpdateReconRunDetails(channelId, txn_type, processingDateTime);
                                    SummaryManager.ProcessSummary(processingDateTime, fileNameDate, channelId, txn_type_cd);
                                }
                                processingDateTime = processingDateTime.AddDays(1).Date;
                                fileNameDate = processingDateTime.ToString(Constants.FileNameDateFormat);
                                processingDateTimeString = processingDateTime.ToString(Constants.ProcessingDateFormat);
                            }
                        }
                    }
                
                    HandleReconForOnline(runForSpecificDateOnly);
                   
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : Exception caught in ProcessRecon " + exception.Message);
                Logger.DailyLog("Error : Exception stack trace is " + exception.StackTrace);                
            } 
        }

        private DateTime PreCheckChannelReconDetails(int agentId, int txn_type)
        {
            DateTime lastReconDate; // = ReconDAL.GetReconRunDetails(agentId, txn_type);

            if (DateTime.TryParseExact(Constants.RunDate, "dd-MMM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out lastReconDate) == false)
            {
                Console.WriteLine("Getting Run date from DB");
                lastReconDate = ReconDAL.GetReconRunDetails(agentId, txn_type);
            }
            Console.WriteLine("Run date is " + lastReconDate.ToString());
            if(lastReconDate == DateTime.MinValue)
            {
                lastReconDate = DateTime.Now.AddDays(-2).Date;
            }
            return lastReconDate;
        }

        private void HandleReconForOnline(bool runForSpecificDateOnly)
        {
            int channelId = Constants.CONST_AGENTID_ONLINE;
            int txn_type_cd = Constants.CONST_TXN_TYPE_CD_TOPUP;
            string channelName = Constants.Online_Channel;

            for (int i = 0; i < 2; i++)
            {

                if (i == 1)
                {
                    channelId = Constants.CONST_AGENTID_OCBCMOBILE;
                    txn_type_cd = Constants.CONST_TXN_TYPE_CD_TOPUP;
                    channelName = Constants.OCBCMobile_Channel;
                    ReconDAL.UpdateReferenceForOCBCMobile(channelId, processingDateTimeString);
                }

                if (runForSpecificDateOnly)
                {
                    if(processingDateTime < DateTime.Today.Date)
                    {
                        if (ReconDAL.CheckIfReconAlreadyRunForChannel(channelId, processingDateTime, Constants.TXN_TYPE))
                        {
                            ProcessComparisonForOnline(channelId, txn_type_cd, channelName);
                        }
                    }
                }
                else
                {
                    processingDateTime = PreCheckChannelReconDetails(channelId, Constants.TXN_TYPE);
                    processingDateTime = processingDateTime.AddDays(1).Date;
                    fileNameDate = processingDateTime.ToString(Constants.FileNameDateFormat);
                    processingDateTimeString = processingDateTime.ToString(Constants.ProcessingDateFormat);
                    while (processingDateTime < DateTime.Today.Date)
                    {
                        ProcessComparisonForOnline(channelId, txn_type_cd, channelName);
                        processingDateTime = processingDateTime.AddDays(1).Date;
                        fileNameDate = processingDateTime.ToString(Constants.FileNameDateFormat);
                        processingDateTimeString = processingDateTime.ToString(Constants.ProcessingDateFormat);
                    }
                }
            }
        }       

        private void ProcessComparisonForOnline(int channelId, int txn_type_cd, string channelName)
        {
            if (CheckIfInputImported(channelId, processingDateTime))
            {
                Logger.DailyLog("Info : Before calling HandleReconForOnline for channel " + channelName);
                IEnumerable<TX_CSC_FINANCIAL> CRecords = ReconDAL.GetCRecords(processingDateTimeString, channelId, txn_type_cd);
                List<TRX2_MATCHSTATUS> matchStatusRecords = CreateMatchStatusRecordsForAllCRecords(CRecords, channelName, txn_type_cd, "C-no-B2");
                IEnumerable<TX_CSC_FINANCIAL_EXCP> cExceptionRecords = ReconDAL.GetCExceptionRecords(processingDateTimeString, channelId, txn_type_cd);
                List<TRX2_MATCHSTATUS> cExcpMatchStatusRecords = CreateMatchStatusRecordsForAllCExceptionRecords(cExceptionRecords, channelName, txn_type_cd, "C-no-B2");
                if (cExcpMatchStatusRecords.Count > 0)
                {
                    matchStatusRecords.AddRange(cExcpMatchStatusRecords);
                }

                MatchRecordsCB2ForOnline(channelId, channelName, txn_type_cd, matchStatusRecords);


                List<TRX2_MATCHSTATUS> matchStatusAB1Records = MatchRecordsAB1ForOnline(channelId, channelName, txn_type_cd);

                IEnumerable<TRX2_MATCHSTATUS> cB2Records = matchStatusRecords.Where(cRecord => cRecord.UNMATCHED_TYPE == "CB2-no-AB1");
                foreach (TRX2_MATCHSTATUS cB2Record in cB2Records)
                {
                    IEnumerable<TRX2_MATCHSTATUS> aB1Records = matchStatusAB1Records.Where(aRecord => aRecord.UNMATCHED_TYPE == "AB1-no-CB2" && 
                        aRecord.CAN_ID == cB2Record.CAN_ID && aRecord.EXTERNAL_REFERENCE == cB2Record.EXTERNAL_REFERENCE);
                    if (aB1Records.Any())
                    {
                        TRX2_MATCHSTATUS aB1Record = aB1Records.FirstOrDefault();
                        aB1Record.UNMATCHED_TYPE = "MATCHED";
                        aB1Record.MATCHED_ENTRY_DATE = processingDateTime;
                        aB1Record.PTC = cB2Record.PTC;

                        cB2Record.UNMATCHED_TYPE = "MATCHED";
                        cB2Record.MATCHED_ENTRY_DATE = processingDateTime;
                        cB2Record.EXTERNAL_SOURCE = aB1Record.EXTERNAL_SOURCE;
                        matchStatusAB1Records.Remove(aB1Record);
                    }
                }
                matchStatusRecords.AddRange(matchStatusAB1Records);
                matchStatusRecords = ProcessOnlineUnmatchedRecords(matchStatusRecords, channelId);

                IEnumerable<TRX2_MATCHSTATUS> citRecords = matchStatusRecords.Where(cRecord => !string.IsNullOrEmpty(cRecord.EXTERNAL_SOURCE) && 
                    (cRecord.EXTERNAL_SOURCE.ToUpper() == "CSL_" || cRecord.EXTERNAL_SOURCE.ToUpper() == "CITIBANK"));
                if (citRecords.Any())
                {
                    citRecords.ToList().ForEach(c => { c.EXTERNAL_SOURCE = "Citibank"; });
                }
                IEnumerable<TRX2_MATCHSTATUS> amexRecords = matchStatusRecords.Where(cRecord => !string.IsNullOrEmpty(cRecord.EXTERNAL_SOURCE) && 
                    cRecord.EXTERNAL_SOURCE.ToUpper() == "AMEX");
                if (amexRecords.Any())
                {
                    amexRecords.ToList().ForEach(c => { c.EXTERNAL_SOURCE = "AMEX"; });
                }
                IEnumerable<TRX2_MATCHSTATUS> emptyRemarkRecords = matchStatusRecords.Where(cRecord => !string.IsNullOrEmpty(cRecord.EXTERNAL_SOURCE) && 
                    cRecord.EXTERNAL_SOURCE.ToUpper() != "CSL_" && cRecord.EXTERNAL_SOURCE.ToUpper() != "CITIBANK" && cRecord.EXTERNAL_SOURCE.ToUpper() != "AMEX");
                if (emptyRemarkRecords.Any())
                {
                    emptyRemarkRecords.ToList().ForEach(c => { c.EXTERNAL_SOURCE = ""; });
                }
                ReconDAL.InsertRecordsToMatchStatusTable(matchStatusRecords);
                ReconDAL.RemoveRepeatedRecords(processingDateTimeString, channelId);
                ProcessReconResults(matchStatusRecords, channelId, channelName, txn_type_cd);
                Logger.DailyLog("Info : Completed HandleReconForOnline for channel " + channelName);
                ReconDAL.UpdateReconRunDetails(channelId, Constants.TXN_TYPE, processingDateTime);
                if (runForSpecificDateOnly)
                {
                    SummaryManager.ProcessSummary(processingDateTime, fileNameDate, channelId, Constants.CONST_TXN_TYPE_CD_TOPUP,runForSpecificDateOnly);                
                }
                else
                {
                    SummaryManager.ProcessSummary(processingDateTime, fileNameDate, channelId, Constants.CONST_TXN_TYPE_CD_TOPUP);
                }
            }
        }

        private bool CheckIfInputImported(int channelId, DateTime processingDateTime, int txn_type = 0)
        {
            bool inputImported = false;
            List<string> reportNames = new List<string>();
            if(channelId == Constants.CONST_AGENTID_AXS)
            {
                reportNames.Add("AXS_Detail_Settlement_" + processingDateTime.ToString("yyMMdd"));
            }
            else if(channelId == Constants.CONST_AGENTID_DBSATM)
            {
                reportNames.Add("EZL.DTLSUCCCSV.TYPEB." + processingDateTime.ToString("yyyyMMdd"));
            }
            else if (channelId == Constants.CONST_AGENTID_OCBC &&  txn_type == 1)
            {
                reportNames.Add("2_OCBC_TOPUP_" + processingDateTime.ToString("yyMMdd") + "_Details");
            }
            else if (channelId == Constants.CONST_AGENTID_OCBC && txn_type == 0)
            {
                reportNames.Add("2_OCBC_REFUND_" + processingDateTime.ToString("yyMMdd") + "_Details");
            }
            else if (channelId == Constants.CONST_AGENTID_DBCC)
            {
                reportNames.Add("EZ_Credit_RECON_" + processingDateTime.ToString("yyyyMMdd"));
            }
            else if(channelId == Constants.CONST_AGENTID_ONLINE)
            {
                reportNames.Add("MTR242_" + processingDateTime.ToString("yyyyMMdd"));
                reportNames.Add("MTR220_" + processingDateTime.ToString("yyyyMMdd"));
                reportNames.Add("MTR247_" + processingDateTime.ToString("yyyyMMdd"));
                reportNames.Add("MTR246_" + processingDateTime.ToString("yyyyMMdd"));
                reportNames.Add("MTR142_" + processingDateTime.ToString("yyyyMMdd"));
                reportNames.Add("MTR120_" + processingDateTime.ToString("yyyyMMdd"));
                reportNames.Add("MTR147_" + processingDateTime.ToString("yyyyMMdd"));
                reportNames.Add("MTR146_" + processingDateTime.ToString("yyyyMMdd"));
            }
            else if(channelId == Constants.CONST_AGENTID_OCBCMOBILE)
            {
                reportNames.Add("MTR209_" + processingDateTime.ToString("yyyyMMdd"));
                reportNames.Add("MTR109_" + processingDateTime.ToString("yyyyMMdd"));
            }
            inputImported = ReconDAL.CheckIfInputImported(reportNames);
            Logger.DailyLog("Info : Import Status for " + processingDateTime.ToString("dd-MM-yy") + " for channel " + channelId + " is " + inputImported);
            return inputImported;
        }

        private List<TRX2_MATCHSTATUS> ProcessOnlineUnmatchedRecords(List<TRX2_MATCHSTATUS> matchStatusRecords, int agentId)
        {

            List<TRX2_MATCHSTATUS> unmatchedRecordsFromTable = ReconDAL.GetUnMatchedRecordsFromTable(agentId, 0);
            IEnumerable<TRX2_MATCHSTATUS> matchedRecords;
            bool recursiveMatchRequired = false;
            foreach(TRX2_MATCHSTATUS unmatchedRecord in unmatchedRecordsFromTable)
            {
                if(unmatchedRecord.UNMATCHED_TYPE == "A-no-B1")
                {
                    matchedRecords = matchStatusRecords.Where((aRecord => aRecord.CAN_ID == unmatchedRecord.CAN_ID && 
                        aRecord.OnlineOCBC_REFERENCE == unmatchedRecord.OnlineOCBC_REFERENCE && 
                        aRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecord.TRANSACTION_DATE_TIME.Date && 
                        aRecord.UNMATCHED_TYPE == "B1-no-A"));
                    if (matchedRecords.Any())
                    {
                        TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                        unmatchedRecord.EXTERNAL_REFERENCE = matchedRecord.EXTERNAL_REFERENCE;                        
                        ReconDAL.UpdateMatchStatusTableWithStatusForOnline(unmatchedRecord, "AB1-no-CB2");

                        
                        /*matchedRecord.UNMATCHED_TYPE = "AB1-no-CB2";
                        matchedRecord.EXTERNAL_SOURCE = unmatchedRecord.EXTERNAL_SOURCE;
                         */
                        matchStatusRecords.Remove(matchedRecord);
                        recursiveMatchRequired = true;
                    }
                    if(unmatchedRecord.EXTERNAL_SOURCE == "AMEX")
                    {
                        matchedRecords = matchStatusRecords.Where(aRecord => !string.IsNullOrEmpty(aRecord.OnlineOCBC_REFERENCE) && 
                            aRecord.OnlineOCBC_REFERENCE == unmatchedRecord.OnlineOCBC_REFERENCE && 
                            aRecord.AGENT_ID == unmatchedRecord.AGENT_ID && 
                            aRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecord.TRANSACTION_DATE_TIME.Date && 
                            aRecord.UNMATCHED_TYPE == "B1-no-A");
                        if (matchedRecords.Any())
                        {
                            TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                            unmatchedRecord.EXTERNAL_REFERENCE = matchedRecord.EXTERNAL_REFERENCE;                            
                            ReconDAL.UpdateMatchStatusTableWithStatusForOnline(unmatchedRecord, "AB1-no-CB2", matchedRecord.CAN_ID);
                            
                           /* matchedRecord.UNMATCHED_TYPE = "AB1-no-CB2";
                            matchedRecord.EXTERNAL_SOURCE = unmatchedRecord.EXTERNAL_SOURCE;
                            */
                            matchStatusRecords.Remove(matchedRecord);
                            recursiveMatchRequired = true;
                        }
                    }
                }
                else if(unmatchedRecord.UNMATCHED_TYPE == "B1-no-A")
                {
                    matchedRecords = matchStatusRecords.Where((aRecord => aRecord.CAN_ID == unmatchedRecord.CAN_ID && 
                        aRecord.OnlineOCBC_REFERENCE == unmatchedRecord.OnlineOCBC_REFERENCE && 
                        aRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecord.TRANSACTION_DATE_TIME.Date && 
                        aRecord.UNMATCHED_TYPE == "A-no-B1"));
                    if (matchedRecords.Any())
                    {
                        TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                        unmatchedRecord.EXTERNAL_SOURCE = matchedRecord.EXTERNAL_SOURCE;
                        //ReconDAL.UpdateMatchStatusTableWithStatusForOnline(unmatchedRecord, "AB1-no-CB2");
                        ReconDAL.DeleteMatchStatusTableWithStatusForOnline(unmatchedRecord, "AB1-no-CB2");

                        matchedRecord.EXTERNAL_REFERENCE = unmatchedRecord.EXTERNAL_REFERENCE;
                        matchedRecord.UNMATCHED_TYPE = "AB1-no-CB2"; 
                        
                        //matchStatusRecords.Remove(matchedRecord);
                        recursiveMatchRequired = true;
                    }
                    if(agentId == Constants.CONST_AGENTID_ONLINE)
                    {
                        matchedRecords = matchStatusRecords.Where((aRecord => aRecord.AMOUNT == unmatchedRecord.AMOUNT && 
                            aRecord.OnlineOCBC_REFERENCE == unmatchedRecord.OnlineOCBC_REFERENCE && 
                            aRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecord.TRANSACTION_DATE_TIME.Date && 
                            aRecord.UNMATCHED_TYPE == "A-no-B1" && !string.IsNullOrEmpty(aRecord.EXTERNAL_SOURCE) && 
                            aRecord.EXTERNAL_SOURCE.ToUpper() == "AMEX"));
                        if (matchedRecords.Any())
                        {
                            TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                            unmatchedRecord.EXTERNAL_SOURCE = matchedRecord.EXTERNAL_SOURCE;
                            //ReconDAL.UpdateMatchStatusTableWithStatusForOnline(unmatchedRecord, "AB1-no-CB2");
                            ReconDAL.DeleteMatchStatusTableWithStatusForOnline(unmatchedRecord, "AB1-no-CB2");

                            matchedRecord.EXTERNAL_REFERENCE = unmatchedRecord.EXTERNAL_REFERENCE;
                            matchedRecord.UNMATCHED_TYPE = "AB1-no-CB2";
                            matchedRecord.CAN_ID = unmatchedRecord.CAN_ID;
                            
                            //matchStatusRecords.Remove(matchedRecord);
                            recursiveMatchRequired = true;
                        }
                    }
                }
                else if (unmatchedRecord.UNMATCHED_TYPE == "C-no-B2")
                {
                    matchedRecords = matchStatusRecords.Where(cRecord => cRecord.CAN_ID == unmatchedRecord.CAN_ID && 
                        cRecord.AMOUNT == unmatchedRecord.AMOUNT && 
                        cRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecord.TRANSACTION_DATE_TIME.Date && 
                        cRecord.UNMATCHED_TYPE == "B2-no-C");
                    if (matchedRecords.Any())
                    {
                        TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                        unmatchedRecord.EXTERNAL_REFERENCE = matchedRecord.EXTERNAL_REFERENCE;
                        unmatchedRecord.OnlineOCBC_REFERENCE = matchedRecord.EXTERNAL_REFERENCE;
                        ReconDAL.UpdateMatchStatusTableWithStatusForOnline(unmatchedRecord, "CB2-no-AB1");

                        
                        /*matchedRecord.UNMATCHED_TYPE = "CB2-no-AB1";                        
                         */
                        matchStatusRecords.Remove(matchedRecord);
                        recursiveMatchRequired = true;
                    }

                }
                else if (unmatchedRecord.UNMATCHED_TYPE == "B2-no-C")
                {
                    matchedRecords = matchStatusRecords.Where(cRecord => cRecord.CAN_ID == unmatchedRecord.CAN_ID && 
                        cRecord.AMOUNT == unmatchedRecord.AMOUNT && 
                        cRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecord.TRANSACTION_DATE_TIME.Date && 
                        cRecord.UNMATCHED_TYPE == "C-no-B2");
                    if (matchedRecords.Any())
                    {
                        //ReconDAL.UpdateMatchStatusTableWithStatusForOnline(unmatchedRecord, "CB2-no-AB1");
                        ReconDAL.DeleteMatchStatusTableWithStatusForOnline(unmatchedRecord, "CB2-no-AB1");

                        TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                        matchedRecord.UNMATCHED_TYPE = "CB2-no-AB1";
                        matchedRecord.EXTERNAL_REFERENCE = unmatchedRecord.EXTERNAL_REFERENCE;
                        matchedRecord.OnlineOCBC_REFERENCE = unmatchedRecord.EXTERNAL_REFERENCE;
                        
                        //matchStatusRecords.Remove(matchedRecord);
                        
                        recursiveMatchRequired = true;
                    }
                }
                else if (unmatchedRecord.UNMATCHED_TYPE == "AB1-no-CB2")
                {
                    matchedRecords = matchStatusRecords.Where(aRecord => aRecord.UNMATCHED_TYPE == "CB2-no-AB1" && 
                        aRecord.CAN_ID == unmatchedRecord.CAN_ID && 
                        aRecord.EXTERNAL_REFERENCE == unmatchedRecord.EXTERNAL_REFERENCE);
                    if (matchedRecords.Any())
                    {
                        TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                        unmatchedRecord.PTC = matchedRecord.PTC;
                        unmatchedRecord.MATCHED_ENTRY_DATE = processingDateTime;
                        //ReconDAL.UpdateMatchStatusTableWithStatusForOnline(unmatchedRecord, "MATCHED");
                        ReconDAL.DeleteMatchStatusTableWithStatusForOnline(unmatchedRecord, "MATCHED");

                        matchedRecord.EXTERNAL_SOURCE = unmatchedRecord.EXTERNAL_SOURCE;
                        matchedRecord.UNMATCHED_TYPE = "MATCHED";
                        matchedRecord.MATCHED_ENTRY_DATE = processingDateTime;
                        matchedRecord.MATCHING_REMARK = "CMCC-OLDER-BANK";
                        
                        //matchStatusRecords.Remove(matchedRecord);
                    }
                }
                else if (unmatchedRecord.UNMATCHED_TYPE == "CB2-no-AB1")
                {
                    matchedRecords = matchStatusRecords.Where(aRecord => aRecord.UNMATCHED_TYPE == "AB1-no-CB2" && 
                        aRecord.CAN_ID == unmatchedRecord.CAN_ID && 
                        aRecord.EXTERNAL_REFERENCE == unmatchedRecord.EXTERNAL_REFERENCE);
                    if (matchedRecords.Any())
                    {
                        TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                        unmatchedRecord.EXTERNAL_SOURCE = matchedRecord.EXTERNAL_SOURCE;
                        unmatchedRecord.MATCHED_ENTRY_DATE = processingDateTime;
                        ReconDAL.UpdateMatchStatusTableWithStatusForOnline(unmatchedRecord, "MATCHED");

                        /*matchedRecord.PTC = unmatchedRecord.PTC;
                        matchedRecord.UNMATCHED_TYPE = "MATCHED";
                        matchedRecord.MATCHED_ENTRY_DATE = processingDateTime;
                         */
                        matchStatusRecords.Remove(matchedRecord);
                    }
                }
            }            
            if(recursiveMatchRequired)
            {
                return ProcessOnlineUnmatchedRecords(matchStatusRecords, agentId);
            }
            return matchStatusRecords;
        }


        private void PerformMatchingOfRecords(int channelId, string channelName, int txn_type_cd, int txn_type, string tableName)
        {
            int res;
            IEnumerable<TX_CSC_FINANCIAL> CRecords = ReconDAL.GetCRecords(processingDateTimeString, channelId,txn_type_cd);
            List<TRX2_MATCHSTATUS> matchStatusRecords = CreateMatchStatusRecordsForAllCRecords(CRecords, channelName, txn_type_cd, "C-no-A");
            if (tableName == Constants.TRX2_DETAILS_SRC1)
            {
                MatchRecordsForSrc1(channelId, channelName, txn_type_cd, txn_type, tableName, matchStatusRecords);
            }
            else
            {
                MatchRecordsForSrc9(channelId, channelName, txn_type_cd, txn_type, tableName, matchStatusRecords);
            }

            IEnumerable<TX_CSC_FINANCIAL_EXCP> cExceptionRecords = ReconDAL.GetCExceptionRecords(processingDateTimeString, channelId,txn_type_cd);
            List<TRX2_MATCHSTATUS> cExcpMatchStatusRecords = CreateMatchStatusRecordsForAllCExceptionRecords(cExceptionRecords, channelName, txn_type_cd, "C-no-A");
            List<TRX2_MATCHSTATUS> tempMatchedList = new List<TRX2_MATCHSTATUS>();
            foreach (var matchRecord in cExcpMatchStatusRecords) // C-no-A from tx_csc_finanical_excp
            {
                IEnumerable<TRX2_MATCHSTATUS> matchedExceptionRecords = matchStatusRecords.Where(aRecord => aRecord.CAN_ID == matchRecord.CAN_ID && 
                    aRecord.AGENT_ID == matchRecord.AGENT_ID && 
                    CheckTimeWithinTolerance(aRecord.TRANSACTION_DATE_TIME.Date, matchRecord.TRANSACTION_DATE_TIME.Date) &&
                    aRecord.UNMATCHED_TYPE == "A-no-C");
                if (matchedExceptionRecords.Any())
                {
                    TRX2_MATCHSTATUS matchedRecord = matchedExceptionRecords.FirstOrDefault(); // from tx_csc_finanical and trx2_details_src1/9
                    matchedRecord.UNMATCHED_TYPE = "MATCHED";
                    matchedRecord.MATCHED_ENTRY_DATE = processingDateTime;
                    matchedRecord.EXCEPTION_CODE = matchRecord.EXCEPTION_CODE;
                    matchRecord.UNMATCHED_TYPE = "MATCHED";  // from tx_csc_finanical_excp
                    matchRecord.EXTERNAL_REFERENCE = matchedRecord.EXTERNAL_REFERENCE;

                    if (matchRecord.MATCHING_REMARK == "50009")
                    {
                        matchRecord.MATCHING_REMARK = "RAV";
                        res = ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString); // to TRX2_MATCHSTATUS..
                        if (res > 1)
                        {
                            // Need to delete duplicates..
                        }
                    }
                    else if (matchRecord.MATCHING_REMARK == "50010")
                    {
                        matchRecord.MATCHING_REMARK = "RU";
                        res =ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString);
                        if (res > 1)
                        {
                            // Need to delete duplicates..
                        }
                    }
                    else
                    {
                        matchRecord.MATCHING_REMARK = "";
                    }
                }
                else if (matchRecord.MATCHING_REMARK == "50009" || (matchRecord.MATCHING_REMARK == "50010"))// C-no-A from tx_csc_finanical_excp
                {
                    bool found = false;
                    // No DIRECT match found in Merchant side, so use less constrained criteria..
                    // First: by CAN + PTC..
                    IEnumerable<TRX2_MATCHSTATUS> ASide =
                        matchStatusRecords.Where(aRecord => aRecord.CAN_ID == matchRecord.CAN_ID && 
                            aRecord.PTC == matchRecord.PTC && aRecord.AGENT_ID == matchRecord.AGENT_ID);

                    if (ASide.Any())
                    {
                        found = true;
                    }
                    else
                    {
                        // Next, try CAN + Transaction time..
                        IEnumerable<TRX2_MATCHSTATUS> ASide2 =
                            matchStatusRecords.Where(aRecord => aRecord.CAN_ID == matchRecord.CAN_ID &&
                                aRecord.AGENT_ID == matchRecord.AGENT_ID &&
                                CheckTimeWithinTolerance(aRecord.TRANSACTION_DATE_TIME, matchRecord.TRANSACTION_DATE_TIME));
                        if (ASide2.Any())
                        {
                            found = true;
                        }
                    }

                    if (found)
                    {
                        matchRecord.MATCHING_REMARK = matchRecord.MATCHING_REMARK == "50009" ? "RAV" : "RU";
                        matchRecord.UNMATCHED_TYPE = "MATCHED";
                        matchRecord.MATCHED_ENTRY_DATE = processingDateTime;
                        matchStatusRecords.Add(matchRecord);
                        // TBD To update or Delete???
                        // Here, the Transaction Date doesn't match
                        res = ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString);
                        if (res > 1)
                        {
                            // Need to remove duplicates
                        }
                        //matchStatusRecords.Remove(ASide.FirstOrDefault());
                    }
                }
                else
                {
                    matchRecord.MATCHING_REMARK = "";
                }
            }
            IEnumerable<TRX2_MATCHSTATUS> cExcpUmatchedRecords = cExcpMatchStatusRecords.Where(record => record.UNMATCHED_TYPE != "MATCHED");
            if (cExcpUmatchedRecords.Any())
            {
                matchStatusRecords.AddRange(cExcpMatchStatusRecords.ToList<TRX2_MATCHSTATUS>());
            }

            List<TRX2_MATCHSTATUS> unmatchedRecordsFromTable = ReconDAL.GetUnMatchedRecordsFromTable(channelId,txn_type_cd);
            ProcessUnmatchedRecords(unmatchedRecordsFromTable, matchStatusRecords);
            ReconDAL.InsertRecordsToMatchStatusTable(matchStatusRecords);

            if(channelId == Constants.CONST_AGENTID_DBCC)
            {
                ReconDAL.UpdateMatchingRemarkForDBCC(processingDateTimeString);
            }

            ReconDAL.RemoveRepeatedRecords(processingDateTimeString,channelId);

            ProcessReconResults(matchStatusRecords,channelId, channelName,txn_type_cd);


        }

        private List<TRX2_MATCHSTATUS> MatchRecordsAB1ForOnline(int channelId, string channelName, int txn_type_cd)
        {
            IEnumerable<TRX2_DETAILS_SRC3> CRecords = ReconDAL.GetOnlineCRecords(processingDateTimeString, channelId);
            List<TRX2_MATCHSTATUS> matchStatusRecords = CreateMatchStatusRecordsForOnlineCRecords(CRecords, channelName, "A-no-B1");
            if (channelId == Constants.CONST_AGENTID_ONLINE)
            {
                List<TRX2_MATCHSTATUS> listOfAmexRecords = IncludeAmexRecordsForProcessing();
                if(listOfAmexRecords.Count > 0)
                {
                    matchStatusRecords.AddRange(listOfAmexRecords);
                }
            }

            matchStatusRecords = MatchRecordsForSrc2(channelId, channelName, matchStatusRecords);



            return matchStatusRecords;

        }

        private List<TRX2_MATCHSTATUS> IncludeAmexRecordsForProcessing()
        {
            List<TRX2_DETAILS_SRC5> amexRecords = ReconDAL.GetSrc5Records(processingDateTimeString);
            foreach(TRX2_DETAILS_SRC5 amexRecord in amexRecords)
            {
                IEnumerable<TRX2_DETAILS_SRC5> matchingRecordWithReference2 = amexRecords.Where(aRecord => aRecord.AMOUNT == amexRecord.AMOUNT && 
                    !string.IsNullOrEmpty(aRecord.REFERENCE_2) && 
                    aRecord.TRX_DATE_TIME.Date == amexRecord.TRX_DATE_TIME.Date);
                string reference2Array = string.Empty;                
                if (matchingRecordWithReference2.Any())
                {
                    foreach (TRX2_DETAILS_SRC5 matchingRecord in matchingRecordWithReference2)
                    {
                        if (string.IsNullOrEmpty(reference2Array))
                        {
                            reference2Array = matchingRecord.REFERENCE_2;
                        }
                        else
                        {
                            reference2Array = reference2Array + "," + matchingRecord.REFERENCE_2;
                        }
                    }                    
                }
                if(string.IsNullOrEmpty(reference2Array))
                {
                    reference2Array = "-1";
                }
                TBL_OLRC_TXNMASTER olrcTxnMaster = ReconDAL.GetApprovalCode(amexRecord.TRX_DATE_TIME, amexRecord.AMOUNT, amexRecord.REFERENCE_1, reference2Array);

                if (olrcTxnMaster != null && !string.IsNullOrEmpty(olrcTxnMaster.APPR_CODE))
                {
                    ReconDAL.UpdateSrc5TableWithApprovalCode(olrcTxnMaster.APPR_CODE.Trim(), amexRecord.TRX_DATE_TIME, amexRecord.AMOUNT, amexRecord.REFERENCE_1);
                    amexRecord.REFERENCE_2 = olrcTxnMaster.APPR_CODE.Trim();
                    amexRecord.REFERENCE_1 = olrcTxnMaster.JOB_NUM;
                    amexRecord.CAN_ID = olrcTxnMaster.CAN_ID;
                }
            }
            //List<TRX2_DETAILS_SRC5> amexUpdatedRecords = ReconDAL.GetSrc5Records(processingDateTimeString);
            return CreateMatchStatusRecordsForAmexRecords(amexRecords);

        }

        private List<TRX2_MATCHSTATUS> MatchRecordsForSrc2(int channelId, string channelName, List<TRX2_MATCHSTATUS> matchStatusRecords)
        {
            List<TRX2_DETAILS_SRC2> ARecords = ReconDAL.GetSrc2ARecords(processingDateTimeString, channelId);
            foreach (var matchRecord in matchStatusRecords)
            {
                if (matchRecord.UNMATCHED_TYPE == "A-no-B1")
                {
                    IEnumerable<TRX2_DETAILS_SRC2> matchedRecordASide = ARecords.Where(aRecord => aRecord.CAN_ID == matchRecord.CAN_ID && 
                        !string.IsNullOrEmpty(aRecord.REFERENCE_2) && 
                        aRecord.REFERENCE_2.Trim() == matchRecord.OnlineOCBC_REFERENCE && 
                        aRecord.AGENT_ID == matchRecord.AGENT_ID && 
                        aRecord.TRX_DATE_TIME.Date == matchRecord.TRANSACTION_DATE_TIME.Date);
                    if (matchedRecordASide.Any())
                    {
                        TRX2_DETAILS_SRC2 firstRecord = matchedRecordASide.FirstOrDefault();
                        matchRecord.UNMATCHED_TYPE = "AB1-no-CB2";
                        matchRecord.EXTERNAL_REFERENCE = firstRecord.REFERENCE_1;
                        ARecords.Remove(firstRecord);
                    }
                    if (matchRecord.EXTERNAL_SOURCE == "AMEX")
                    {
                        matchedRecordASide = ARecords.Where(aRecord => !string.IsNullOrEmpty(aRecord.REFERENCE_2) && 
                            aRecord.REFERENCE_2.Trim() == matchRecord.OnlineOCBC_REFERENCE && 
                            aRecord.AGENT_ID == matchRecord.AGENT_ID && 
                            aRecord.TRX_DATE_TIME.Date == matchRecord.TRANSACTION_DATE_TIME.Date);
                        if (matchedRecordASide.Any())
                        {
                            TRX2_DETAILS_SRC2 firstRecord = matchedRecordASide.FirstOrDefault();
                            matchRecord.UNMATCHED_TYPE = "AB1-no-CB2";
                            matchRecord.EXTERNAL_REFERENCE = firstRecord.REFERENCE_1;
                            matchRecord.CAN_ID = firstRecord.CAN_ID;                            
                            ARecords.Remove(firstRecord);
                        }
                    }
                }
            }
            if (ARecords.Count > 0)
            {
                TRX2_MATCHSTATUS matchStatusRecord = null;
                foreach (TRX2_DETAILS_SRC2 aRecord in ARecords)
                {
                    matchStatusRecord = new TRX2_MATCHSTATUS();
                    matchStatusRecord.CAN_ID = aRecord.CAN_ID;
                    matchStatusRecord.PROCESSING_DATE_TIME = aRecord.REPORT_DATE;
                    matchStatusRecord.PTC = aRecord.PTC;
                    matchStatusRecord.TRANSACTION_DATE_TIME = aRecord.TRX_DATE_TIME;
                    matchStatusRecord.AMOUNT = Math.Truncate(aRecord.AMOUNT);
                    matchStatusRecord.AGENT_ID = aRecord.AGENT_ID;
                    matchStatusRecord.AGENT_NAME = channelName;
                    matchStatusRecord.UNMATCHED_TYPE = "B1-no-A";
                    matchStatusRecord.MATCHED_ENTRY_DATE = null;
                    matchStatusRecord.TXN_TYPE = Constants.CONST_TXN_TYPE_CD_TOPUP;
                    matchStatusRecord.LAST_MODIFIED_DATE = DateTime.Now;
                    matchStatusRecord.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                    if (aRecord.REFERENCE_2 != null)
                    {
                        matchStatusRecord.OnlineOCBC_REFERENCE = aRecord.REFERENCE_2.Trim();
                    }
                    else
                    {
                        matchStatusRecord.OnlineOCBC_REFERENCE = aRecord.REFERENCE_2;
                    }
                    matchStatusRecord.EXTERNAL_REFERENCE = aRecord.REFERENCE_1;
                    matchStatusRecord.EXCEPTION_CODE = aRecord.INDICATOR;
                    if (matchStatusRecord.EXCEPTION_CODE == "N" || matchStatusRecord.EXCEPTION_CODE == "R")
                    {
                        matchStatusRecord.EXCEPTION_CODE = string.Empty;
                    }
                    matchStatusRecords.Add(matchStatusRecord);
                }
            }

            IEnumerable<TRX2_MATCHSTATUS> b1NoARecords = matchStatusRecords.Where(cRecord => cRecord.UNMATCHED_TYPE == "B1-no-A");
            foreach (var b1NoARecord in b1NoARecords)
            {
                IEnumerable<TRX2_MATCHSTATUS> matchedRecords = matchStatusRecords.Where(cRecord => cRecord.CAN_ID == b1NoARecord.CAN_ID && 
                    cRecord.OnlineOCBC_REFERENCE == b1NoARecord.OnlineOCBC_REFERENCE && 
                    cRecord.TRANSACTION_DATE_TIME.Date == b1NoARecord.TRANSACTION_DATE_TIME.Date && 
                    cRecord.UNMATCHED_TYPE == "A-no-B1");
                if (matchedRecords.Any())
                {
                    TRX2_MATCHSTATUS firstRecordMatched = matchedRecords.FirstOrDefault();
                    firstRecordMatched.UNMATCHED_TYPE = "AB1-no-CB2";
                    b1NoARecord.UNMATCHED_TYPE = "AB1-no-CB2";
                    firstRecordMatched.EXTERNAL_REFERENCE = b1NoARecord.EXTERNAL_REFERENCE;
                    b1NoARecord.EXTERNAL_SOURCE = firstRecordMatched.EXTERNAL_SOURCE;
                    
                    matchStatusRecords.Remove(firstRecordMatched);
                }
            }
 
            if(channelId == Constants.CONST_AGENTID_ONLINE)
            {
                foreach (var b1NoARecord in b1NoARecords)
                {
                    IEnumerable<TRX2_MATCHSTATUS> matchedRecords = matchStatusRecords.Where(cRecord => cRecord.AMOUNT == b1NoARecord.AMOUNT && 
                        cRecord.OnlineOCBC_REFERENCE == b1NoARecord.OnlineOCBC_REFERENCE && 
                        cRecord.TRANSACTION_DATE_TIME.Date == b1NoARecord.TRANSACTION_DATE_TIME.Date && 
                        cRecord.UNMATCHED_TYPE == "A-no-B1" && !string.IsNullOrEmpty(cRecord.EXTERNAL_SOURCE) && 
                        cRecord.EXTERNAL_SOURCE.ToUpper() == "AMEX");
                    if (matchedRecords.Any())
                    {
                        TRX2_MATCHSTATUS firstRecordMatched = matchedRecords.FirstOrDefault();
                        firstRecordMatched.UNMATCHED_TYPE = "AB1-no-CB2";
                        firstRecordMatched.CAN_ID = b1NoARecord.CAN_ID;
                        firstRecordMatched.EXTERNAL_REFERENCE = b1NoARecord.EXTERNAL_REFERENCE;

                        b1NoARecord.UNMATCHED_TYPE = "AB1-no-CB2";
                        b1NoARecord.EXTERNAL_SOURCE = firstRecordMatched.EXTERNAL_SOURCE;

                        matchStatusRecords.Remove(firstRecordMatched);
                    }
                }

            }
            return matchStatusRecords;
        }

        private void MatchRecordsCB2ForOnline(int channelId, string channelName, int txn_type_cd, List<TRX2_MATCHSTATUS> matchStatusRecords)
        {
            IEnumerable<TRX2_MATCHSTATUS> matchedRAVRURecord = matchStatusRecords.Where(cRecord => cRecord.MATCHING_REMARK == "50009");
            if (matchedRAVRURecord.Any())
            {
                ReconDAL.UpdateRAVRUMatchingRecords(matchedRAVRURecord, processingDateTimeString);
                matchedRAVRURecord.ToList().ForEach(c => { c.UNMATCHED_TYPE = "MATCHED"; c.MATCHING_REMARK = "RAV"; c.MATCHED_ENTRY_DATE = processingDateTime; });                         
            }
            matchedRAVRURecord = matchStatusRecords.Where(cRecord => cRecord.MATCHING_REMARK == "50010");
            if (matchedRAVRURecord.Any())
            {
                ReconDAL.UpdateRAVRUMatchingRecords(matchedRAVRURecord, processingDateTimeString);          
                matchedRAVRURecord.ToList().ForEach(c => { c.UNMATCHED_TYPE = "MATCHED"; c.MATCHING_REMARK = "RU"; c.MATCHED_ENTRY_DATE = processingDateTime; });
            }
            matchedRAVRURecord = matchStatusRecords.Where(cRecord => cRecord.MATCHING_REMARK != "RAV" && cRecord.MATCHING_REMARK != "RU");
            if (matchedRAVRURecord.Any())
            {
                matchedRAVRURecord.ToList().ForEach(c => c.MATCHING_REMARK = "");
            }
                
            List<TRX2_DETAILS_SRC1> ARecords = ReconDAL.GetOnlineARecords(processingDateTimeString, channelId);
            List<TRX2_DETAILS_SRC1> UnmatchedARecords = new List<TRX2_DETAILS_SRC1>();
            foreach (var aRecord in ARecords)
            {
                IEnumerable<TRX2_MATCHSTATUS> matchedCRecord = matchStatusRecords.Where(cRecord => cRecord.CAN_ID == aRecord.CAN_ID && 
                    cRecord.AMOUNT == aRecord.AMOUNT && cRecord.AGENT_ID == aRecord.AGENT_ID && 
                    cRecord.TRANSACTION_DATE_TIME.Date == aRecord.TRX_DATE_TIME.Date && 
                    cRecord.UNMATCHED_TYPE == "C-no-B2");
                if (matchedCRecord.Any())
                {
                    TRX2_MATCHSTATUS firstMatchRecord = matchedCRecord.FirstOrDefault();
                    firstMatchRecord.UNMATCHED_TYPE = "CB2-no-AB1";                    
                    firstMatchRecord.OnlineOCBC_REFERENCE = aRecord.REFERENCE_1;
                    firstMatchRecord.EXTERNAL_REFERENCE = aRecord.REFERENCE_1;                    
                }
                else
                {
                    UnmatchedARecords.Add(aRecord);
                }
            }            
            if (UnmatchedARecords.Count > 0)
            {
                TRX2_MATCHSTATUS matchStatusRecord = null;
                foreach (TRX2_DETAILS_SRC1 aRecord in UnmatchedARecords)
                {
                    matchStatusRecord = new TRX2_MATCHSTATUS();
                    matchStatusRecord.CAN_ID = aRecord.CAN_ID;
                    matchStatusRecord.PROCESSING_DATE_TIME = aRecord.REPORT_DATE;
                    matchStatusRecord.PTC = 0;
                    matchStatusRecord.TRANSACTION_DATE_TIME = aRecord.TRX_DATE_TIME;
                    matchStatusRecord.AMOUNT = aRecord.AMOUNT;
                    matchStatusRecord.AGENT_ID = aRecord.AGENT_ID;
                    matchStatusRecord.AGENT_NAME = channelName;
                    matchStatusRecord.UNMATCHED_TYPE = "B2-no-C";
                    matchStatusRecord.MATCHED_ENTRY_DATE = null;
                    matchStatusRecord.TXN_TYPE = txn_type_cd;
                    matchStatusRecord.LAST_MODIFIED_DATE = DateTime.Now;
                    matchStatusRecord.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                    matchStatusRecord.EXTERNAL_REFERENCE = aRecord.REFERENCE_1;
                    matchStatusRecord.EXCEPTION_CODE = aRecord.INDICATOR;
                    matchStatusRecord.OnlineOCBC_REFERENCE = aRecord.REFERENCE_1;
                    matchStatusRecords.Add(matchStatusRecord);
                }
            }
            IEnumerable<TRX2_MATCHSTATUS> b2NoCRecords = matchStatusRecords.Where(cRecord => cRecord.UNMATCHED_TYPE == "B2-no-C");
            foreach (var b2NoCRecord in b2NoCRecords)
            {
                IEnumerable<TRX2_MATCHSTATUS> matchedRecords = matchStatusRecords.Where(cRecord => cRecord.CAN_ID == b2NoCRecord.CAN_ID && 
                    cRecord.AMOUNT == b2NoCRecord.AMOUNT && 
                    cRecord.TRANSACTION_DATE_TIME.Date == b2NoCRecord.TRANSACTION_DATE_TIME.Date && 
                    cRecord.UNMATCHED_TYPE == "C-no-B2");
                if (matchedRecords.Any())
                {
                    TRX2_MATCHSTATUS firstRecordMatched = matchedRecords.FirstOrDefault();
                    firstRecordMatched.UNMATCHED_TYPE = "CB2-no-AB1";                    
                    firstRecordMatched.OnlineOCBC_REFERENCE = b2NoCRecord.OnlineOCBC_REFERENCE;
                    firstRecordMatched.EXTERNAL_REFERENCE = b2NoCRecord.EXTERNAL_REFERENCE;

                    b2NoCRecord.UNMATCHED_TYPE = "CB2-no-AB1";                    
                    b2NoCRecord.PTC = firstRecordMatched.PTC;

                    matchStatusRecords.Remove(firstRecordMatched);
                }
            } 
        }

        // Returns true if dt1, dt2 is within some tolerance..
        private bool CheckTimeWithinTolerance(DateTime dt1, DateTime dt2)
        {
            bool res = false;
            res = ((dt1 == dt2) || (Math.Abs((dt1 - dt2).TotalSeconds) < 20));
            return res;
        }

        private void MatchRecordsForSrc1(int channelId, string channelName, int txn_type_cd, int txn_type, string tableName, List<TRX2_MATCHSTATUS> matchStatusRecords)
        {
            int res = 0;
            List<TRX2_DETAILS_SRC1> ARecords = ReconDAL.GetSrc1ARecords(processingDateTimeString, channelId, txn_type);
            foreach (var matchRecord in matchStatusRecords)  // C-no-A
            {
                // Naga matches only Date portion, ignoring Time part.
                //IEnumerable<TRX2_DETAILS_SRC1> matchedRecordASide = ARecords.Where(aRecord => aRecord.CAN_ID == matchRecord.CAN_ID && aRecord.PTC == matchRecord.PTC && aRecord.AGENT_ID == matchRecord.AGENT_ID && aRecord.TRX_DATE_TIME.Date == matchRecord.TRANSACTION_DATE_TIME.Date);
                // I will match date and time..
                // A-no-C's time can be earlier or same as C-no-A's time..
                IEnumerable<TRX2_DETAILS_SRC1> matchedRecordASide = 
                    ARecords.Where(aRecord => aRecord.CAN_ID == matchRecord.CAN_ID && 
                        aRecord.PTC == matchRecord.PTC && aRecord.AGENT_ID == matchRecord.AGENT_ID && 
                        CheckTimeWithinTolerance(aRecord.TRX_DATE_TIME, matchRecord.TRANSACTION_DATE_TIME));
                if (matchedRecordASide.Any()) // A-no-C
                {
                    // Here is "exact" match with CAN, PTC, Transaction Date/Time portion only..
                    matchRecord.UNMATCHED_TYPE = "MATCHED";
                    matchRecord.MATCHED_ENTRY_DATE = processingDateTime;
                    matchRecord.EXTERNAL_REFERENCE = matchedRecordASide.FirstOrDefault().REFERENCE_2;
                    ARecords.Remove(matchedRecordASide.FirstOrDefault());

                    // For Jan 19 issue.. There are possibilities where:
                    // MatchedReport_DBSATM_26_Dec_2017  - 1000148001367475, where merchant PTC=3 and RAV PTC=3048. (transaction time matches)
                    // MatchedReport_DBSATM_03_Jan_2018  - 1000150020274894, where merchant PTC=0, RAV PTC=484. (transaction time matches)
                    // MatchedReport_AXS_31_Dec_2017     - 1000160003197002, where PTC matches (85) while transaction time differs: RAV=26/12/2017 8:09:56 AM, Merchant=26/12/2017 8:09:47 AM.
                    //
                    // So, rule:
                    // If RAV record, 
                    //     first try to match by CAN + PTC, if both matches ==> MATCHED.
                    //     If no match found, then try CAN + transaction date/time. (based on data, likely PTC different).
                    //
                    // In this case, a match is already found, so if CMCC has a 50009 or 50010, then just go ahead and mark
                    // as matched, and RAV or RU..
                    // NOTE: At this point the CAN/PTC/Transaction Date all matches, so just update..
                    if (matchRecord.MATCHING_REMARK == "50009")
                    {
                        matchRecord.MATCHING_REMARK = "RAV";
                        res = ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString);
                        if (res > 1)
                        {
                            // Need to delete duplicates..
                        }
                    }
                    else if (matchRecord.MATCHING_REMARK == "50010")
                    {
                        matchRecord.MATCHING_REMARK = "RU";
                        res =ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString);
                        if (res > 1)
                        {
                            // Need to delete duplicates..
                        }
                    }
                    else
                    {
                        matchRecord.MATCHING_REMARK = "";
                    }
                }
                else if (matchRecord.MATCHING_REMARK == "50009" || (matchRecord.MATCHING_REMARK == "50010"))
                {
                    bool found = false;
                    // No DIRECT match found in Merchant side, so use less constrained criteria..
                    // First: by CAN + PTC..
                    IEnumerable<TRX2_DETAILS_SRC1> ASide = 
                        ARecords.Where(aRecord => aRecord.CAN_ID == matchRecord.CAN_ID && 
                            aRecord.PTC == matchRecord.PTC && aRecord.AGENT_ID == matchRecord.AGENT_ID);

                    if (ASide.Any())
                    {
                        found = true;
                    }
                    else
                    {
                        // Next, try CAN + Transaction time..
                        IEnumerable<TRX2_DETAILS_SRC1> ASide2 =
                            ARecords.Where(aRecord => aRecord.CAN_ID == matchRecord.CAN_ID &&
                                aRecord.AGENT_ID == matchRecord.AGENT_ID &&
                                CheckTimeWithinTolerance(aRecord.TRX_DATE_TIME, matchRecord.TRANSACTION_DATE_TIME));
                        if (ASide2.Any())
                        {
                            found = true;
                        }
                    }

                    if (found)
                    {
                        matchRecord.MATCHING_REMARK = matchRecord.MATCHING_REMARK == "50009" ? "RAV" : "RU";
                        matchRecord.UNMATCHED_TYPE = "MATCHED";
                        matchRecord.MATCHED_ENTRY_DATE = processingDateTime;
                        // TBD To update or Delete???
                        // Here, the Transaction Date doesn't match
                        res = ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString);
                        if (res > 1)
                        {
                            // Need to remove duplicates
                        }
                        ARecords.Remove(ASide.FirstOrDefault());
                    }
                }
                else
                {
                    matchRecord.MATCHING_REMARK = "";
                }
            }
            if (ARecords.Count > 0)
            {
                TRX2_MATCHSTATUS matchStatusRecord = null;
                foreach (TRX2_DETAILS_SRC1 aRecord in ARecords)
                {
                    matchStatusRecord = new TRX2_MATCHSTATUS();
                    matchStatusRecord.CAN_ID = aRecord.CAN_ID;
                    matchStatusRecord.PROCESSING_DATE_TIME = aRecord.REPORT_DATE;
                    matchStatusRecord.PTC = aRecord.PTC;
                    matchStatusRecord.TRANSACTION_DATE_TIME = aRecord.TRX_DATE_TIME;
                    matchStatusRecord.AMOUNT = aRecord.AMOUNT;
                    matchStatusRecord.AGENT_ID = aRecord.AGENT_ID;
                    matchStatusRecord.AGENT_NAME = channelName;
                    matchStatusRecord.UNMATCHED_TYPE = "A-no-C";
                    matchStatusRecord.MATCHED_ENTRY_DATE = null;
                    matchStatusRecord.TXN_TYPE = txn_type_cd;
                    matchStatusRecord.LAST_MODIFIED_DATE = DateTime.Now;
                    matchStatusRecord.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                    matchStatusRecord.EXTERNAL_REFERENCE = aRecord.REFERENCE_2;
                    matchStatusRecord.EXCEPTION_CODE = aRecord.INDICATOR;
                    if (matchStatusRecord.EXCEPTION_CODE == "N" || matchStatusRecord.EXCEPTION_CODE == "R")
                    {
                        matchStatusRecord.EXCEPTION_CODE = string.Empty;
                    }
                    matchStatusRecords.Add(matchStatusRecord);
                }
            }
        }

        private void MatchRecordsForSrc9(int channelId, string channelName, int txn_type_cd, int txn_type, string tableName, List<TRX2_MATCHSTATUS> matchStatusRecords)
        {
            int res = 0;
            List<TRX2_DETAILS_SRC9> ARecords = ReconDAL.GetSrc9ARecords(processingDateTimeString, channelId, txn_type);
            foreach (var matchRecord in matchStatusRecords)
            {
                //IEnumerable<TRX2_DETAILS_SRC9> matchedRecordASide = ARecords.Where(aRecord => aRecord.EZ_Card_No == matchRecord.CAN_ID && aRecord.PTC == matchRecord.PTC && aRecord.Txn_Date_Time.Date == matchRecord.TRANSACTION_DATE_TIME.Date);
                IEnumerable<TRX2_DETAILS_SRC9> matchedRecordASide = 
                    ARecords.Where(aRecord => aRecord.EZ_Card_No == matchRecord.CAN_ID && 
                        aRecord.PTC == matchRecord.PTC &&
                        CheckTimeWithinTolerance(aRecord.Txn_Date_Time, matchRecord.TRANSACTION_DATE_TIME));
                if (matchedRecordASide.Any())
                {
                    matchRecord.UNMATCHED_TYPE = "MATCHED";
                    matchRecord.MATCHED_ENTRY_DATE = processingDateTime;
                    matchRecord.EXTERNAL_REFERENCE = matchedRecordASide.FirstOrDefault().Auth_Code;
                    matchRecord.OnlineOCBC_REFERENCE = matchedRecordASide.FirstOrDefault().Credit_Card_No + "/" + matchedRecordASide.FirstOrDefault().Auth_Code;
                    ARecords.Remove(matchedRecordASide.FirstOrDefault());

                    if (matchRecord.MATCHING_REMARK == "50009")
                    {
                        matchRecord.MATCHING_REMARK = "RAV";
                        res = ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString);
                        if (res > 1)
                        {
                            // Need to delete duplicates..
                        }
                    }
                    else if (matchRecord.MATCHING_REMARK == "50010")
                    {
                        matchRecord.MATCHING_REMARK = "RU";
                        res = ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString);
                        if (res > 1)
                        {
                            // Need to delete duplicates..
                        }
                    }
                    else
                    {
                        matchRecord.MATCHING_REMARK = "";
                    }
                }
                else if (matchRecord.MATCHING_REMARK == "50009" || (matchRecord.MATCHING_REMARK == "50010"))
                {
                    bool found = false;
                    // No DIRECT match found in Merchant side, so use less constrained criteria..
                    // First: by CAN + PTC..
                    IEnumerable<TRX2_DETAILS_SRC9> ASide =
                        ARecords.Where(aRecord => aRecord.EZ_Card_No == matchRecord.CAN_ID &&
                            aRecord.PTC == matchRecord.PTC);

                    if (ASide.Any())
                    {
                        found = true;
                    }
                    else
                    {
                        // Next, try CAN + Transaction time..
                        IEnumerable<TRX2_DETAILS_SRC9> ASide2 =
                            ARecords.Where(aRecord => aRecord.EZ_Card_No == matchRecord.CAN_ID &&
                                CheckTimeWithinTolerance(aRecord.Txn_Date_Time, matchRecord.TRANSACTION_DATE_TIME));
                        if (ASide2.Any())
                        {
                            found = true;
                        }
                    }

                    if (found)
                    {
                        matchRecord.MATCHING_REMARK = matchRecord.MATCHING_REMARK == "50009" ? "RAV" : "RU";
                        matchRecord.UNMATCHED_TYPE = "MATCHED";
                        matchRecord.MATCHED_ENTRY_DATE = processingDateTime;
                        // TBD To update or Delete???
                        // Here, the Transaction Date doesn't match
                        res = ReconDAL.UpdateRAVRUMatchingRecord(matchRecord, processingDateTimeString);
                        if (res > 1)
                        {
                            // Need to remove duplicates
                        }
                        ARecords.Remove(ASide.FirstOrDefault());
                    }
                }
                else
                {
                    matchRecord.MATCHING_REMARK = "";
                }
            }
            if (ARecords.Count > 0)
            {
                TRX2_MATCHSTATUS matchStatusRecord = null;
                foreach (TRX2_DETAILS_SRC9 aRecord in ARecords)
                {
                    matchStatusRecord = new TRX2_MATCHSTATUS();
                    matchStatusRecord.CAN_ID = aRecord.EZ_Card_No;
                    matchStatusRecord.PROCESSING_DATE_TIME = aRecord.REPORT_DATE;
                    matchStatusRecord.PTC = aRecord.PTC;
                    matchStatusRecord.TRANSACTION_DATE_TIME = aRecord.Txn_Date_Time;
                    matchStatusRecord.AMOUNT = aRecord.EZ_Amt;
                    matchStatusRecord.AGENT_ID = channelId;
                    matchStatusRecord.AGENT_NAME = channelName;
                    matchStatusRecord.UNMATCHED_TYPE = "A-no-C";
                    matchStatusRecord.MATCHED_ENTRY_DATE = null;
                    matchStatusRecord.TXN_TYPE = txn_type_cd;
                    matchStatusRecord.LAST_MODIFIED_DATE = DateTime.Now;
                    matchStatusRecord.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                    matchStatusRecord.EXTERNAL_REFERENCE = aRecord.Auth_Code;
                    matchStatusRecord.OnlineOCBC_REFERENCE = aRecord.Credit_Card_No + "/" + aRecord.Auth_Code;                    
                    matchStatusRecords.Add(matchStatusRecord);
                }
            }
        }

        private void ProcessUnmatchedRecords(List<TRX2_MATCHSTATUS> unmatchedRecordsFromTable, List<TRX2_MATCHSTATUS> matchStatusRecords)
        {
            IEnumerable<TRX2_MATCHSTATUS> matchedRecords;
            foreach(TRX2_MATCHSTATUS unmatchedRecordInTable in unmatchedRecordsFromTable)
            {

                if (unmatchedRecordInTable.UNMATCHED_TYPE == "A-no-C")
                {
                    matchedRecords = matchStatusRecords.Where(aRecord => aRecord.CAN_ID == unmatchedRecordInTable.CAN_ID && 
                        aRecord.PTC == unmatchedRecordInTable.PTC && 
                        aRecord.AGENT_ID == unmatchedRecordInTable.AGENT_ID && 
                        aRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecordInTable.TRANSACTION_DATE_TIME.Date && 
                        aRecord.UNMATCHED_TYPE == "C-no-A");
                    if (matchedRecords.Any())
                    {
                        unmatchedRecordInTable.MATCHED_ENTRY_DATE = processingDateTime;
                        //ReconDAL.UpdateMatchStatusTableWithStatus(unmatchedRecordInTable);
                        ReconDAL.DeleteMatchStatusTableRecord(unmatchedRecordInTable);

                        TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();
                        
                        matchedRecord.UNMATCHED_TYPE = "MATCHED";
                        matchedRecord.MATCHED_ENTRY_DATE = processingDateTime;
                        matchedRecord.MATCHING_REMARK = "CMCC-OLDER-BANK";

                        //matchStatusRecords.Remove(matchedRecord);


                    }
                }
                else
                {
                    matchedRecords = matchStatusRecords.Where(aRecord => aRecord.CAN_ID == unmatchedRecordInTable.CAN_ID && 
                        aRecord.PTC == unmatchedRecordInTable.PTC && 
                        aRecord.AGENT_ID == unmatchedRecordInTable.AGENT_ID && 
                        aRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecordInTable.TRANSACTION_DATE_TIME.Date && 
                        aRecord.UNMATCHED_TYPE == "A-no-C");
                    //if it is from FIRS exception table do not compare using PTC.
                    if ((!matchedRecords.Any()) && (!string.IsNullOrEmpty(unmatchedRecordInTable.EXCEPTION_CODE)))
                    {
                        matchedRecords = matchStatusRecords.Where(aRecord => aRecord.CAN_ID == unmatchedRecordInTable.CAN_ID && 
                            aRecord.AGENT_ID == unmatchedRecordInTable.AGENT_ID && 
                            aRecord.TRANSACTION_DATE_TIME.Date == unmatchedRecordInTable.TRANSACTION_DATE_TIME.Date && 
                            aRecord.UNMATCHED_TYPE == "A-no-C");
                    }
                    if (matchedRecords.Any())
                    {
                        unmatchedRecordInTable.MATCHED_ENTRY_DATE = processingDateTime;

                        //sg: copy External Reference..
                        unmatchedRecordInTable.EXTERNAL_REFERENCE = matchedRecords.FirstOrDefault().EXTERNAL_REFERENCE;

                        ReconDAL.UpdateMatchStatusTableWithStatus(unmatchedRecordInTable);
                        //ReconDAL.DeleteMatchStatusTableRecord(unmatchedRecordInTable);

                        TRX2_MATCHSTATUS matchedRecord = matchedRecords.FirstOrDefault();                        
                        /*matchedRecord.UNMATCHED_TYPE = "MATCHED";
                        matchedRecord.MATCHED_ENTRY_DATE = processingDateTime; 
                         */
                        matchStatusRecords.Remove(matchedRecord);


                    }

                }                
            }
        }

        private List<TRX2_MATCHSTATUS> CreateMatchStatusRecordsForAllCRecords(IEnumerable<TX_CSC_FINANCIAL> cRecords, string channelName, int txn_type_cd, string unmatchType)
        {
            List<TRX2_MATCHSTATUS> matchStatusRecords = new List<TRX2_MATCHSTATUS>();
            TRX2_MATCHSTATUS matchStatusRecord = null;
            foreach(TX_CSC_FINANCIAL cRecord in cRecords)
            {
                matchStatusRecord = new TRX2_MATCHSTATUS();
                matchStatusRecord.CAN_ID = cRecord.CSC_APP_NO;
                matchStatusRecord.PROCESSING_DATE_TIME = cRecord.PROCESSING_DATE;
                matchStatusRecord.PTC = cRecord.PURSE_TXN_CTR;
                matchStatusRecord.TRANSACTION_DATE_TIME = cRecord.TXN_DATETIME;
                matchStatusRecord.AMOUNT = cRecord.TXN_AMT;
                matchStatusRecord.AGENT_ID = cRecord.AGENT_ID;
                matchStatusRecord.AGENT_NAME = channelName;
                matchStatusRecord.UNMATCHED_TYPE = unmatchType;
                matchStatusRecord.MATCHED_ENTRY_DATE = null;
                matchStatusRecord.TXN_TYPE = txn_type_cd;
                matchStatusRecord.LAST_MODIFIED_DATE = DateTime.Now;
                matchStatusRecord.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                matchStatusRecord.MATCHING_REMARK = cRecord.MSG_TYPE_CD.ToString();
                matchStatusRecords.Add(matchStatusRecord);
            }
            /*IEnumerable<TRX2_MATCHSTATUS> listOfMatchStatus = matchStatusRecords as IEnumerable<TRX2_MATCHSTATUS>;*/
            return matchStatusRecords;
        }

        private List<TRX2_MATCHSTATUS> CreateMatchStatusRecordsForOnlineCRecords(IEnumerable<TRX2_DETAILS_SRC3> cRecords, string channelName, string unmatchType)
        {
            List<TRX2_MATCHSTATUS> matchStatusRecords = new List<TRX2_MATCHSTATUS>();
            TRX2_MATCHSTATUS matchStatusRecord = null;
            foreach (TRX2_DETAILS_SRC3 cRecord in cRecords)
            {
                matchStatusRecord = new TRX2_MATCHSTATUS();
                matchStatusRecord.CAN_ID = cRecord.CAN_ID;
                matchStatusRecord.PROCESSING_DATE_TIME = cRecord.REPORT_DATE;
                matchStatusRecord.PTC = cRecord.PTC;
                matchStatusRecord.TRANSACTION_DATE_TIME = cRecord.TRX_DATE_TIME;
                matchStatusRecord.AMOUNT = Math.Truncate(cRecord.AMOUNT);
                matchStatusRecord.AGENT_ID = cRecord.AGENT_ID;
                matchStatusRecord.AGENT_NAME = channelName;
                matchStatusRecord.UNMATCHED_TYPE = unmatchType;
                matchStatusRecord.MATCHED_ENTRY_DATE = null;
                matchStatusRecord.OnlineOCBC_REFERENCE = cRecord.REFERENCE_2;
                matchStatusRecord.EXTERNAL_SOURCE = cRecord.REPORT_NAME.Substring(8, 4);
                matchStatusRecord.EXCEPTION_CODE = cRecord.INDICATOR;
                matchStatusRecord.TXN_TYPE = Constants.CONST_TXN_TYPE_CD_TOPUP;
                matchStatusRecord.EXTERNAL_REFERENCE = cRecord.REFERENCE_2;
                matchStatusRecord.LAST_MODIFIED_DATE = DateTime.Now;
                matchStatusRecord.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                matchStatusRecords.Add(matchStatusRecord);
            }            
            return matchStatusRecords;
        }

        private List<TRX2_MATCHSTATUS> CreateMatchStatusRecordsForAllCExceptionRecords(IEnumerable<TX_CSC_FINANCIAL_EXCP> cRecords, string channelName, int txn_type_cd, string unmatchType)
        {
            List<TRX2_MATCHSTATUS> matchStatusRecords = new List<TRX2_MATCHSTATUS>();
            TRX2_MATCHSTATUS matchStatusRecord = null;
            foreach (TX_CSC_FINANCIAL_EXCP cRecord in cRecords)
            {
                matchStatusRecord = new TRX2_MATCHSTATUS();
                matchStatusRecord.CAN_ID = cRecord.CSC_APP_NO;
                matchStatusRecord.PROCESSING_DATE_TIME = cRecord.PROCESSING_DATE;
                matchStatusRecord.PTC = cRecord.PURSE_TXN_CTR;
                matchStatusRecord.TRANSACTION_DATE_TIME = cRecord.TXN_DATETIME;
                matchStatusRecord.AMOUNT = cRecord.TXN_AMT;
                matchStatusRecord.AGENT_ID = cRecord.AGENT_ID;
                matchStatusRecord.AGENT_NAME = channelName;
                matchStatusRecord.UNMATCHED_TYPE = unmatchType;
                matchStatusRecord.MATCHED_ENTRY_DATE = null;
                matchStatusRecord.TXN_TYPE = txn_type_cd;
                matchStatusRecord.LAST_MODIFIED_DATE = DateTime.Now;
                matchStatusRecord.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                matchStatusRecord.MATCHING_REMARK = cRecord.MSG_TYPE_CD.ToString();
                matchStatusRecord.EXCEPTION_CODE = cRecord.EXCP_REASON_LIST;
                if (cRecord.UPDATE_CSC_IND != 0)
                {
                    matchStatusRecords.Add(matchStatusRecord);
                }
            }
            /*IEnumerable<TRX2_MATCHSTATUS> listOfMatchStatus = matchStatusRecords as IEnumerable<TRX2_MATCHSTATUS>;*/
            return matchStatusRecords;
        }


        private void ProcessReconResults(List<TRX2_MATCHSTATUS> matchStatusRecords, int channelId, string channelName, int txn_type_cd)
        {
            //AXS Unmatched
            ReadData(matchStatusRecords, channelId, string.Format(Constants.UnmatchedReportPath, channelName, fileNameDate), channelName, EnumRecordType.Unmatched, txn_type_cd);
            //AXS Matched           
            ReadData(matchStatusRecords, channelId, string.Format(Constants.MatchedReportPath, channelName, fileNameDate), channelName, EnumRecordType.Matched, txn_type_cd);            
        }

        private void ReadData(List<TRX2_MATCHSTATUS> listOfMatches, int channelId, string fileName, string channel, EnumRecordType recordType, int txn_type_cd)
        {
            try
            {                
                FileInfo fileInfo = new FileInfo(fileName);
                if (!fileInfo.Directory.Exists)
                {
                    System.IO.Directory.CreateDirectory(fileInfo.DirectoryName);
                }              
                StringBuilder sb = new StringBuilder();
                using (StreamWriter sw = new StreamWriter(fileName, true))
                {
                    IncludeHeaderAndLegend(sb, channel, recordType);
                    List<string> columnNames = new List<string>{
                    "TRANSACTION_DATE_TIME",
                    "PROCESSING_DATE_TIME",
                    "CAN_ID",
                    "PTC",
                    "AGENT_ID",
                    "AGENT_NAME",
                    "EXTERNAL_REFERENCE",
                    "AMOUNT",
                    "TXN_TYPE",
                    "EXCEPTION_CODE",
                    "EXTERNAL_SOURCE",
                    "UNMATCHED_TYPE",
                    "MATCHING_REMARK",
                    "MATCHED_ENTRY_DATE",
                    "REFUND_METHOD",
                    "REFERENCE",
                    "LAST_MODIFIED_DATE",
                    "LAST_MODIFIED_USER"};
                    sb.Append(string.Join(",", ProcessColumnNames(columnNames)));
                    sb.AppendLine();
                    sw.Write(sb.ToString());
                    sb.Clear();
                    IEnumerable<TRX2_MATCHSTATUS> recordsToSearialize;
                    if (recordType == EnumRecordType.Matched)
                    {
                        recordsToSearialize = ReconDAL.GetMatchedRecordsFromTable(channelId, txn_type_cd, processingDateTimeString);
                    }
                    else
                    {
                        recordsToSearialize = ReconDAL.GetUnMatchedRecordsFromTable(channelId, txn_type_cd);
                    }
                    foreach (TRX2_MATCHSTATUS record in recordsToSearialize)
                    {
                        string value = string.Empty;
                        value = record.TRANSACTION_DATE_TIME.ToString();
                        AppendToStringBuilder(sb, value);
                        value = record.PROCESSING_DATE_TIME.ToString();
                        AppendToStringBuilder(sb, value);
                        value = record.CAN_ID.ToString();
                        value = "=\"" + value + "\"";
                        AppendToStringBuilder(sb, value);
                        value = record.PTC.ToString();
                        AppendToStringBuilder(sb, value);
                        value = record.AGENT_ID.ToString();
                        AppendToStringBuilder(sb, value);
                        value = record.AGENT_NAME;
                        AppendToStringBuilder(sb, value);
                        value = record.EXTERNAL_REFERENCE;
                        AppendToStringBuilder(sb, value);
                        value = record.AMOUNT.ToString();
                        AppendToStringBuilder(sb, value);
                        value = record.TXN_TYPE.ToString();
                        AppendToStringBuilder(sb, value);
                        value = record.EXCEPTION_CODE;
                        AppendToStringBuilder(sb, value);
                        value = record.EXTERNAL_SOURCE;
                        AppendToStringBuilder(sb, value);
                        value = record.UNMATCHED_TYPE;
                        AppendToStringBuilder(sb, value);
                        value = record.MATCHING_REMARK;
                        AppendToStringBuilder(sb, value);
                        value = record.MATCHED_ENTRY_DATE != null ? record.MATCHED_ENTRY_DATE.ToString() : string.Empty;
                        AppendToStringBuilder(sb, value);
                        value = record.REFUND_METHOD;
                        AppendToStringBuilder(sb, value);
                        value = record.REFERENCE;
                        AppendToStringBuilder(sb, value);
                        value = record.LAST_MODIFIED_DATE != null ? record.LAST_MODIFIED_DATE.ToString() : string.Empty;
                        AppendToStringBuilder(sb, value);
                        value = record.LAST_MODIFIED_USER != null ? record.LAST_MODIFIED_USER.ToString() : string.Empty;
                        AppendToStringBuilder(sb, value);
                        sb.Length--;
                        sb.AppendLine();
                        sw.Write(sb.ToString());
                        sb.Clear();
                    }
                }
            }
            catch
            {

            } 
        } 

        private List<string> ProcessColumnNames(List<string> columnNames)
        {
            List<string> processedColumnName = new List<string>();
            foreach (string columnName in columnNames)
            {
                switch (columnName.ToUpper())
                {
                    case "TRANSACTION_DATE_TIME":
                    case "PROCESSING_DATE_TIME":
                    case "CAN_ID":
                    case "PTC":
                    case "AGENT_ID":
                    case "AMOUNT":
                    case "EXCEPTION_CODE":
                        processedColumnName.Add(columnName + " (A/C)");
                        break;
                    case "AGENT_NAME":
                    case "UNMATCHED_TYPE":
                    case "MATCHED_ENTRY_DATE":
                    case "REFUND_METHOD":
                    case "REFERENCE":
                    case "LAST_MODIFIED_DATE":
                    case "LAST_MODIFIED_USER":
                        processedColumnName.Add(columnName + " (R)");
                        break;
                    case "EXTERNAL_REFERENCE":
                        processedColumnName.Add(columnName + " (A)");
                        break;
                    case "TXN_TYPE":
                    case "EXTERNAL_SOURCE":
                    case "MATCHING_REMARK":
                        processedColumnName.Add(columnName + " (C)");
                        break;
                }
            }
            return processedColumnName;
        }

        private void AppendToStringBuilder(StringBuilder sb, string value)
        {
            if (value == null)
            {
                value = string.Empty;
            }
            if (value.Contains(","))
            {
                value = "\"" + value + "\"";
            }
            sb.Append(value.Replace(Environment.NewLine, " ") + ",");            
        }

        private void IncludeHeaderAndLegend(StringBuilder sb, string channel, EnumRecordType recordType)
        {
            if (recordType == EnumRecordType.Matched)
            {
                sb.AppendLine(string.Format(Constants.HeaderStringMatchReport, fileNameDate, Environment.NewLine));
            }
            else
            {
                sb.AppendLine(string.Format(Constants.HeaderStringUnMatchReport, fileNameDate, Environment.NewLine));
            }
            sb.AppendLine(Constants.LegendString);
        } 

        private List<TRX2_MATCHSTATUS> CreateMatchStatusRecordsForAmexRecords(List<TRX2_DETAILS_SRC5> amexRecords)
        {
            List<TRX2_MATCHSTATUS> matchStatusRecords = new List<TRX2_MATCHSTATUS>();
            TRX2_MATCHSTATUS matchStatusRecord = null;
            foreach (TRX2_DETAILS_SRC5 amexRecord in amexRecords)
            {
                matchStatusRecord = new TRX2_MATCHSTATUS();               
                matchStatusRecord.PROCESSING_DATE_TIME = amexRecord.REPORT_DATE;                
                matchStatusRecord.TRANSACTION_DATE_TIME = amexRecord.TRX_DATE_TIME;
                matchStatusRecord.AMOUNT = Math.Truncate(amexRecord.AMOUNT);
                matchStatusRecord.AGENT_ID = amexRecord.MERCHANT_ID;
                matchStatusRecord.AGENT_NAME = Constants.Online_Channel;
                matchStatusRecord.UNMATCHED_TYPE = "A-no-B1";
                matchStatusRecord.MATCHED_ENTRY_DATE = null;
                matchStatusRecord.OnlineOCBC_REFERENCE = amexRecord.REFERENCE_2;
                matchStatusRecord.EXTERNAL_SOURCE = amexRecord.REPORT_NAME.Substring(8, 4);                
                matchStatusRecord.TXN_TYPE = Constants.CONST_TXN_TYPE_CD_TOPUP;
                matchStatusRecord.EXTERNAL_REFERENCE = amexRecord.REFERENCE_1;
                matchStatusRecord.LAST_MODIFIED_DATE = DateTime.Now;
                matchStatusRecord.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                matchStatusRecord.CAN_ID = amexRecord.CAN_ID;
                matchStatusRecords.Add(matchStatusRecord);
            }
            return matchStatusRecords;
        }
    }
}
