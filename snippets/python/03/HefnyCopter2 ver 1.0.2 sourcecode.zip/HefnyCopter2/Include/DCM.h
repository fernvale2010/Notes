///*
 //* DCM.h
 //*
 //* Created: 13-Jan-13 12:27:27 AM
 //*  Author: M.Hefny
 //*/ 
//
//
//#ifndef DCM_H_
//#define DCM_H_
//
//
//void imu_DCM_init();
//void imu_DCM_update();
//
//
//#endif /* DCM_H_ */