/*
 * Motor.h
 *
 * Created: 8/13/2012 8:46:07 PM
 *  Author: hefny
 */ 


#ifndef MOTOR_H_
#define MOTOR_H_




	void Motor_GenerateOutputSignal ();
	


#endif /* MOTOR_H_ */