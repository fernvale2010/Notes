/*
 * Misc.h
 *
 * Created: 8/14/2012 1:04:38 AM
 *  Author: hefny
 */ 


#ifndef MISC_H_
#define MISC_H_

#include <inttypes.h>

	    /* time delay for us */
		void delay_us(uint16_t time);
		void delay_ms(uint16_t time);



#endif /* MISC_H_ */