/*
 * Timer.c
 *
 * Created: 8/18/2012 6:56:45 AM
 *  Author: hefny
 */ 


#ifndef TIMER_H_
#define TIMER_H_
 

volatile uint16_t TCNT1_X;				
volatile uint16_t TCNT2_X;				



void Timer_Init(void);


#endif