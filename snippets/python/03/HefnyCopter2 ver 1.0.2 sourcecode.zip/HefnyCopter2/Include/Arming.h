/*
 * SticksHandling.h
 *
 * Created: 18-Sep-12 6:17:09 AM
 *  Author: M.Hefny
 */ 


#ifndef STICKSHANDLING_H_
#define STICKSHANDLING_H_





void Arm (void);

void Disarm (void);

#endif /* STICKSHANDLING_H_ */