#ifndef __USER_CONFIG_H__
#define __USER_CONFIG_H__

#define WIFI_APSSID	"ESP_HOST"
#define WIFI_APPASSWORD	"00000000"
#define WIFI_APWPA	true
#define TCPSERVERIP	"10.10.10.10"
#define TCPSERVERPORT	3333
#define PLATFORM_DEBUG	true
#define BTNGPIO		0

#endif
