/******************************************************************************
 *
 * Programm:	Catamaran
 *
 * Author:		Walter Trojan
 *
 * Start:		May 2017
 *
 * Target:		Remote Control for Hover-Catamaran
 * 				Dedicated Access Point with TCP server
 *
 *
 ******************************************************************************/


#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"
#include "user_interface.h"
#include "driver/uart.h"
#include "driver/pwm.h"
#include "espconn.h"
#include "mem.h"
#include "gpio.h"
#include "user_config.h"
#include <stdio.h>
#include <math.h>

#define	Mli	12
#define Mre 13

void 	Docmd(void);
void 	Doread(void);

extern int ets_uart_printf(const char *fmt, ...);
static  ETSTimer Wloop;
static  ETSTimer PWMprd;
static  ETSTimer Tmli;
static  ETSTimer Tmre;
struct  espconn *pespconn;
struct ip_info ipinfo;
struct ip_addr ip;

sint8_t Espret;

uint32_t Systic;
bool	 AP_rdy   = false;
bool     Done_rdy = false;
bool 	 Host_rdy = false;
bool	 Conn_rdy = false;
bool     On_rdy	  = false;
bool	 Cmdok    = false;
bool	 Txok	  = false;
bool     Toggle   = false;

char	 Txbu[32];
char	 *pTxbu;
char	 Rxbu[16];
char	 Flbu[16];
char	 *pFlbu;
char     Ipdval[4];
int32_t  S1bin;
int32_t  S2bin;
int32_t  S1binalt;
int32_t  S2binalt;
int32_t  Motli;
int32_t	 Motre;
int8_t   PWMli;
int8_t   PWMre;
uint32_t Gaugval = 0;
uint32_t Buttval = 0;
float 	 Buttflo;
uint32_t I;


uint32_t Paycnt = 0;
uint8_t  cpuspeed;
uint8_t  flashsize;
char 	 Payload[128];

uint16_t GPIO_Time_Active = 0;

uint32_t A1tim = 0;
uint32_t Vmtim = 0;
uint16_t Adcval= 0;

enum DoApp1 { A1init=1, A1wait1, A1startHost, A1wait2, A1waitconnect, A1stop, A1Error, A1Ende } A1stat;

/*******************************************************************************
 * Callback routines of TCP server
 ******************************************************************************/

static void ICACHE_FLASH_ATTR
at_tcpclient_sent_cb(void *arg) {
	ets_uart_printf("Send callback\r\n");
	struct espconn *pespconn = (struct espconn *)arg;
}

static void ICACHE_FLASH_ATTR
at_tcpclient_recv_cb(void *arg, char *pursdata, unsigned short length) {
	if(length > 12)
		length = 12;
	strncpy(Rxbu,pursdata,length);
	ets_uart_printf("Receive callback: %s\r\n", Rxbu);
	Docmd();
	struct espconn *pespconn = (struct espconn *)arg;
	espconn_sent(pespconn, Txbu, strlen(Txbu));
	ets_uart_printf("\r\n Sendback: %s", Txbu);
}

static void ICACHE_FLASH_ATTR
at_tcpclient_discon_cb(void *arg) {
	struct espconn *pespconn = (struct espconn *)arg;
	os_free(pespconn->proto.tcp);
	os_free(pespconn);
	Conn_rdy = false;
	ets_uart_printf("Disconnect callback\r\n");
}

static void ICACHE_FLASH_ATTR
at_tcpclient_connect_cb(void *arg)
{
	pespconn = (struct espconn *)arg;
	ets_uart_printf("TCP client connect\r\n");
	espconn_regist_recvcb(pespconn, at_tcpclient_recv_cb);
	espconn_regist_sentcb(pespconn, at_tcpclient_sent_cb);
	espconn_regist_disconcb(pespconn, at_tcpclient_discon_cb);
	Conn_rdy = true;
}


/*******************************************************************************
 * SetupTCPServ: Starts TCP server
 ******************************************************************************/
static void ICACHE_FLASH_ATTR
SetupTCPServ()
{
	LOCAL struct  espconn esp_conn;
	LOCAL esp_tcp esptcp;
	uint32_t port;

	port = 3333;
	esp_conn.type = ESPCONN_TCP;
	esp_conn.state = ESPCONN_NONE;
	esp_conn.proto.tcp = &esptcp;
	esp_conn.proto.tcp->local_port = port;
	espconn_regist_connectcb(&esp_conn, at_tcpclient_connect_cb);

	Espret = espconn_accept(&esp_conn);
	espconn_regist_time(&esp_conn, 0, 0);
	ets_uart_printf(" Espret= %d\r\n", Espret);

	if(Espret == 0)
		Host_rdy = true;
	else
		Host_rdy = false;
}


/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : SDK just reversed 4 sectors, used for rf init data and paramters.
 *                We add this function to force users to set rf cal sector, since
 *                we don't know which sector is free in user's application.
 *                sector map for last several sectors : ABBBCDDD
 *                A : rf cal
 *                B : at parameters
 *                C : rf init data
 *                D : sdk parameters
 * Parameters   : none
 * Returns      : rf cal sector
*******************************************************************************/
uint32 ICACHE_FLASH_ATTR user_rf_cal_sector_set(void)
{
    enum flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 8;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            break;

        default:
            rf_cal_sec = 0;
            break;
    }

    return rf_cal_sec;
}

void ICACHE_FLASH_ATTR user_rf_pre_init(void)
{
}


/*******************************************************************************
 * SetupSoftAP: Starts SoftAP
 ******************************************************************************/
void ICACHE_FLASH_ATTR
SetupSoftAP2()
{

   struct softap_config apConfig;
   char ssid[33];
   char password[33];
   char macaddress[17];
   char info[150];

   wifi_softap_dhcps_stop();

   if( wifi_get_phy_mode() != PHY_MODE_11N )
   {
	  ets_uart_printf("*** Setting PHY_MODE ...\r\n");
      wifi_set_phy_mode( PHY_MODE_11N );
   }

   if(wifi_get_opmode() != SOFTAP_MODE)
   {
      ets_uart_printf("ESP8266 not in SOFTAP mode, restarting in SOFTAP mode...\r\n");
      wifi_set_opmode(SOFTAP_MODE);

   }

   wifi_set_phy_mode( PHY_MODE_11N );
   wifi_set_opmode(SOFTAP_MODE);

   IP4_ADDR(&ipinfo.ip, 10, 10, 10, 1);
   IP4_ADDR(&ipinfo.gw, 10, 10, 10, 1);
   IP4_ADDR(&ipinfo.netmask, 255, 255, 255, 0);

   wifi_set_ip_info(SOFTAP_IF, &ipinfo);

   wifi_softap_get_config(&apConfig);

   os_memset(apConfig.ssid, 0, sizeof(apConfig.ssid));

   os_sprintf(ssid, "%s", WIFI_APSSID);

   os_memcpy(apConfig.ssid, ssid, os_strlen(ssid));

   if (wifi_get_opmode() == SOFTAP_MODE)
   {
      apConfig.authmode = AUTH_OPEN;
      apConfig.channel = 11;
      apConfig.max_connection = 4;
      apConfig.ssid_hidden = 0;

      apConfig.ssid_len = 0;
      apConfig.beacon_interval = 100;

      wifi_softap_set_config(&apConfig);

      ets_uart_printf(" wifi_softap_set_config %s %s!\r\n",apConfig.ssid, apConfig.password);
      AP_rdy = true;
   }

   struct dhcps_lease dhcp_lease;
   IP4_ADDR(&dhcp_lease.start_ip, 10,10,10,11);
   IP4_ADDR(&dhcp_lease.end_ip, 10,10,10,14);
   wifi_softap_set_dhcps_lease(&dhcp_lease);

   wifi_softap_dhcps_start();

   ets_uart_printf(" SoftAP started!\r\n");

}


/*******************************************************************************
 * power, ftoa: Routines to convert floating to ascii
 ******************************************************************************/

int power(int base, int exp){
    int result = 1;
    while(exp) { result *= base; exp--; }
    return result;
}

static char* ftoa(float num, uint8_t decimals) {
  // float to string; no float support in esp8266 sdk printf
  // warning: limited to 15 chars & non-reentrant
  // e.g., dont use more than once per os_printf call
  static char* buf[16];
  int whole = num;
  int decimal = (num - whole) * power(10, decimals);
  if (decimal < 0) {
    // get rid of sign on decimal portion
    decimal -= 2 * decimal;
  }
  char* pattern[10]; // setup printf pattern for decimal portion
  os_sprintf(pattern, "%%d.%%0%dd", decimals);
  os_sprintf(buf, pattern, whole, decimal);
  return (char *)buf;
}


/*******************************************************************************
* Doread: Performs client commands
*
* Commands:
* 		getgaug	= Request Gauge
* 		getbutt = Request Textbox
*
*
********************************************************************************/
void Doread(void)
{
	if(Gaugval >=1000)
	{
		Gaugval = 0;
		Buttval = 0;
	}
	Gaugval = Gaugval+20;
	Buttval = Buttval+20;

	Cmdok = false;
	os_sprintf(Txbu,"ack\r\n");
	if(strstr(Rxbu,"getgaug")!= NULL)
	{
		Cmdok = true;
		os_sprintf(Txbu,"%d\r\n",Gaugval);
		return;
	}
	if(strstr(Rxbu,"getbutt")!= NULL)
	{
		Cmdok = true;
		Buttflo = (float)Buttval * 0.01;
		pFlbu = ftoa(Buttflo,2);
		ets_uart_printf("\r\n Vm-Bat: %s\r\n",pFlbu);
		os_sprintf(Txbu,"Ubat= %s V\r\n",pFlbu);
		return;
	}
	return;
}


/*******************************************************************************
* Docmd: Performs client commands
*
* Kommandos:
* 		SW:on	= Einschalten
* 		SW:of	= Ausschalten
* 		S1:xxx	= Speed
* 		S2:xxx	= Richtung
*
********************************************************************************/
void Docmd(void)
{
	Cmdok = false;
	os_sprintf(Txbu,"ack\r\n");				// Default response
	if(strstr(Rxbu,"SW:")!= NULL)
	{
		Motli = 0;
		Motre = 0;
		if(Rxbu[4] == 'n')					// Switch = On
			On_rdy = true;
		else
			On_rdy = false;					// Switch = off
		return;
	}

	if(strstr(Rxbu,"S1:")!= NULL)
	{
		Ipdval[0] = Rxbu[3];
		Ipdval[1] = '\0';
		if((Rxbu[4] >= '0') && (Rxbu[4] <= '9'))
		{
			Ipdval[1] = Rxbu[4];
			Ipdval[2] = '\0';
		}
		if((Rxbu[5] >= '0') && (Rxbu[5] <= '9'))
		{
			Ipdval[2] = Rxbu[5];
			Ipdval[3] = '\0';
		}
		S1bin = atoi(Ipdval);
		Cmdok = true;
		return;
	}

	if(strstr(Rxbu,"S2:")!= NULL)
	{
		Ipdval[0] = Rxbu[3];
		Ipdval[1] = '\0';
		if((Rxbu[4] >= '0') && (Rxbu[4] <= '9'))
		{
			Ipdval[1] = Rxbu[4];
			Ipdval[2] = '\0';
		}
		if((Rxbu[5] >= '0') && (Rxbu[5] <= '9'))
		{
			Ipdval[2] = Rxbu[5];
			Ipdval[3] = '\0';
		}
		S2bin = atoi(Ipdval);
		Cmdok = true;
		return;
	}

	if(strstr(Rxbu,"getgaug")!= NULL)
	{
		Gaugval = system_adc_read();
		if(On_rdy)
			os_sprintf(Txbu,"%d\r\n",Gaugval);
		else
			os_sprintf(Txbu,"%d\r\n",0);
		return;
	}

	if(strstr(Rxbu,"getbutt")!= NULL)
	{
		Buttval = system_adc_read();
		if(On_rdy)
		{
			Buttflo = (float)Buttval * 0.01;
			pFlbu = ftoa(Buttflo,2);
			ets_uart_printf("\r\n Vm-Bat: %s\r\n",pFlbu);
			os_sprintf(Txbu,"Ubat= %s V\r\n",pFlbu);
		}
		else
			strcpy(Txbu,"Ubat= AUS\r\n");
		return;
	}

	if(strstr(Rxbu,"getsped")!= NULL)
	{
		os_sprintf(Txbu,"%d\r\n",0);
		return;
	}
}


/*******************************************************************************
 * DoApp1: Called from workloop every 10 mS, state machine
 ******************************************************************************/

LOCAL void ICACHE_FLASH_ATTR DoApp1()
{

	switch(A1stat)
	{
		case A1init:						// Init
		{
			A1tim = 0;
			S1bin = 0;
			S2bin = 0;
			S1binalt = 0;
			S2binalt = 0;
			PWMli = 0;
			PWMre = 0;
			On_rdy = false;

			if(Done_rdy)
			{								// Init is ready
				SetupSoftAP2();
				ets_uart_printf("\r\n SetupSoftAP ready DoApp1\r\n");
				if(AP_rdy)
					A1stat = A1wait1;	   // SoftAP is ready
				else
					A1stat = A1Error;
			}
			break;
		}
		case A1wait1:						// wait a little bit
		{
			if(A1tim >= 100)
			{								// Wait 1 Sec.
				A1tim  = 0;
				A1stat = A1startHost;
			}
			break;
		}
		case A1startHost:					// Start TCP server
		{
			A1tim = 0;
			ets_uart_printf("\r\n TCP-Host started DoApp1\r\n");
			SetupTCPServ();
			ets_uart_printf("\r\n TCP-Host ready DoApp1\r\n");
			if(Host_rdy)
				A1stat = A1waitconnect;
			else
				A1stat = A1Error;
			break;
		}
		case A1waitconnect:					// Wait for client connect
		{
			if(Cmdok)
			{
				Cmdok = false;
				if(On_rdy && ((S1bin != S1binalt) || (S2bin != S2binalt)))
				{
					S1binalt = S1bin;
					S2binalt = S2bin;
					if(S2bin == 100)
					{
						Motli = S1bin;
						Motre = S1bin;
					}
					if(S2bin < 100)
					{
						Motli = S1bin;
						Motre = (S2bin * S1bin) / 100;
					}
					if(S2bin > 100)
					{
						Motre = S1bin;
						Motli = ((200 - S2bin) * S1bin) / 100;
					}
				}
				ets_uart_printf("\r\n Motre = %d\r\n", Motre);
				ets_uart_printf("\r\n Motli = %d\r\n", Motli);
				PWMli = Motli;
				PWMre = Motre;
			}

			break;
		}
		case A1stop:
		{									// Disconnect from Host
			Conn_rdy = false;
			espconn_disconnect(pespconn);
			ets_uart_printf("\r\n Stop DoApp1\r\n");
			A1stat = A1Ende;
			break;
		}
		case A1Error:						// In case of error
		{
			ets_uart_printf("\r\nERROR in DoApp1\r\n");
			A1stat = A1Ende;
			break;
		}
		case A1Ende:
		{

			break;
		}
	}


}

/*******************************************************************************
 * init_done_cb: Called after init is ready
 ******************************************************************************/

static void ICACHE_FLASH_ATTR init_done_cb(void)
{
	Done_rdy = true;
	ets_uart_printf("\r\n Init done.\r\n");

}


/*******************************************************************************
 * eventHandler: Called after some events
 ******************************************************************************/
static void ICACHE_FLASH_ATTR eventHandler(System_Event_t *event) {
	switch(event->event) {
		case EVENT_STAMODE_CONNECTED:
		{
			ets_uart_printf("\r\n Event: EVENT_STAMODE_CONNECTED\r\n");
			break;
		}
		case EVENT_STAMODE_DISCONNECTED:
		{
			ets_uart_printf("\r\n Event: EVENT_STAMODE_DISCONNECTED\r\n");
			break;
		}
		case EVENT_STAMODE_AUTHMODE_CHANGE:
		{
			ets_uart_printf("\r\n Event: EVENT_STAMODE_AUTHMODE_CHANGE\r\n");
			break;
		}
		case EVENT_STAMODE_GOT_IP:
		{
			ets_uart_printf("\r\n Event: EVENT_STAMODE_GOT_IP\r\n");
			break;
		}
		case EVENT_SOFTAPMODE_STACONNECTED:
		{
			Host_rdy = true;
			ets_uart_printf("\r\n Event: EVENT_SOFTAPMODE_STACONNECTED\r\n");
			break;
		}
		case EVENT_SOFTAPMODE_STADISCONNECTED:
		{
			Host_rdy = false;
			ets_uart_printf("\r\n Event: EVENT_SOFTAPMODE_STADISCONNECTED");
			break;
		}
		default:
		{
			//ets_uart_printf("\r\n Unexpected event: %d\r\n", event->event);
			break;
		}
	}
}



/*******************************************************************************
 * tmli: Will be called by pwmprd
 ******************************************************************************/

LOCAL void ICACHE_FLASH_ATTR tmli(void *arg)
{
	GPIO_OUTPUT_SET(Mli,0);
}


/*******************************************************************************
 * tmre: Will be called by pwmprd
 ******************************************************************************/

LOCAL void ICACHE_FLASH_ATTR tmre(void *arg)
{
	GPIO_OUTPUT_SET(Mre,0);
}


/*******************************************************************************
 * pwmprd: Will be called cyclic by RTOS, depending on timer Systi (every 1000 ms)
 ******************************************************************************/

LOCAL void ICACHE_FLASH_ATTR pwmprd(void *arg)
{
	if(Motli == 0)
		GPIO_OUTPUT_SET(Mli,0);

	if(Motli == 255)
		GPIO_OUTPUT_SET(Mli,1);

	if((Motli > 0) && (Motli < 255))
	{
		GPIO_OUTPUT_SET(Mli,1);
		os_timer_disarm(&Tmli);
		os_timer_setfn(&Tmli, (os_timer_func_t *)tmli, NULL);
		os_timer_arm(&Tmli, 4*Motli, 0);		// once
	}

	if(Motre == 0)
		GPIO_OUTPUT_SET(Mre,0);

	if(Motre == 255)
		GPIO_OUTPUT_SET(Mre,1);

	if((Motre > 0) && (Motre < 255))
	{
		GPIO_OUTPUT_SET(Mre,1);
		os_timer_disarm(&Tmre);
		os_timer_setfn(&Tmre, (os_timer_func_t *)tmre, NULL);
		os_timer_arm(&Tmre, 4*Motre, 0);		// once
	}
}



/*******************************************************************************
 * workloop: Called by RTOS, depending on timer Wloop, calling itself, if ready
 ******************************************************************************/

LOCAL void ICACHE_FLASH_ATTR workloop(void *arg)
{
	os_timer_disarm(&Wloop);
	Systic++;
	A1tim++;
	Vmtim++;

	DoApp1();

	os_timer_setfn(&Wloop, (os_timer_func_t *)workloop, NULL);
	os_timer_arm(&Wloop, 10, 0);		// 10 mS once
}


/*******************************************************************************
 * user_init: Called from RTOS at the beginning
 ******************************************************************************/

void ICACHE_FLASH_ATTR user_init(void)
{
	uint32_t i;

	ets_uart_printf("\r\n");
	ets_uart_printf("\r\n\n\n");

	uart_init(BIT_RATE_115200, BIT_RATE_115200);
	os_delay_us(1000);

	cpuspeed = system_get_cpu_freq();
	flashsize = system_get_flash_size_map();
	ets_uart_printf("\r\n\n ESP8266 platform starting...!\r\n");
	ets_uart_printf("\r\n SDK version:%s\n", system_get_sdk_version());
	ets_uart_printf("\r\n CPU-Freq: %d\r\n",cpuspeed);
	ets_uart_printf("\r\n Flash_Size: %d\r\n",flashsize);

	wifi_station_set_auto_connect(0);	// no auto connection
	system_init_done_cb(init_done_cb);	// register init_done_cb
	wifi_set_event_handler_cb(eventHandler);
    
	PIN_FUNC_SELECT(PWM_0_OUT_IO_MUX, PWM_0_OUT_IO_FUNC); // LED_BL
	PIN_FUNC_SELECT(PWM_2_OUT_IO_MUX, PWM_2_OUT_IO_FUNC); // LED_WS

	Systic = 0;
	A1tim  = 0;
	Vmtim  = 0;
	Adcval = 0;
	A1stat = A1init;

	Buttval= 0;
	pFlbu  = &Flbu[0];


	ets_uart_printf("\r\nESP8266 platform started!\r\n");

	os_timer_disarm(&Wloop);
	os_timer_setfn(&Wloop, (os_timer_func_t *)workloop, NULL);
	os_timer_arm(&Wloop, 10, 0);		// 10 mS once

	os_timer_disarm(&PWMprd);
	os_timer_setfn(&PWMprd, (os_timer_func_t *)pwmprd, NULL);
	os_timer_arm(&PWMprd, 1000, 1);		// 1 Sec repeat
}


