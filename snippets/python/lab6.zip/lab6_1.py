# template file for Lab #6, Task #1
import numpy
import matplotlib.pyplot as p
import channel
import lab6
reload(lab6)
import lab2_2 
reload(lab2_2)

p.ion()

# Return two numpy arrays, one containing frequencies, one containing
# magnitudes of frequency responses.
def freq_res_usr(usr, num_freqs=1001):
    pass  # your code here
    
if __name__ == '__main__':
    # Create the channels (noise free with no random delays
    # or padding)
    channel0 = channel.channel(channelid='0')
    channel1 = channel.channel(channelid='1')
    channel2 = channel.channel(channelid='2')

    for mychannel in [channel0, channel1, channel2]:
        usr = lab2_2.unit_sample_response(mychannel) # Get channel's u.s.r.
        omega_1, mag_hejw_chan1 = freq_res_usr(usr)
        lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1,
                               usr, mychannel.id)

    # when ready for checkoff, enable the following line
    #lab6.checkoff(freq_res_usr,'L6_1')

