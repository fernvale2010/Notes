# template file for Lab #6, Task #3
import numpy
import matplotlib.pyplot as p
import channel
import lab6
reload(lab6)
import lab6_1
reload(lab6_1)
import lab6_2
reload(lab6_2)

p.ion()

# Return a numpy array containing the usr for a high-pass filter.
def hpf(omega_stop, omega_pass):
    pass  # your code here

if __name__ == '__main__':

    # A high pass filter with a reasonably wide transition
    pi = numpy.pi
    omega_stop = 0.25*pi
    omega_pass = 0.45*pi

    hpf_usr = hpf(omega_stop, omega_pass)

    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr(hpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, hpf_usr, 'hpf')

    # A high pass filter with a narrow transition region
    pi = numpy.pi
    omega_stop = 0.44*pi
    omega_pass = 0.45*pi

    hpf_usr = hpf(omega_stop, omega_pass)

    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr(hpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, hpf_usr, 'hpf')


    # when ready for checkoff, enable the following line
    #lab6.checkoff(hpf,'L6_3')
