# template file for Lab #6, Task #5
import numpy
import matplotlib.pyplot as p
import channel
import lab6
reload(lab6)
import lab6_1
reload(lab6_1)
import lab6_3
reload(lab6_3)

p.ion()

# Return a numpy array containing the usr for a band-pass filter.
def bandpass(omega_lo, omega_high, delta):
    pass   # your code here

if __name__ == '__main__':

    # Create a testing filter
    pi = numpy.pi
    omega_lo = 0.6*pi
    omega_high = 0.8*pi

    bpf_usr = bandpass(omega_lo, omega_high, 0.2)
    
    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr(bpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, bpf_usr, 'bpf')    

    # Create a second testing filter
    omega_lo = 0.4*pi
    omega_high = 0.5*pi

    bpf_usr = bandpass(omega_lo, omega_high, 0.05)
    
    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr(bpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, bpf_usr, 'bpf')    

    # when ready for checkoff, enable the following line
    #lab6.checkoff(bandpass,'L6_5')
