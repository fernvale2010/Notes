# template file for Lab #6, Task #4
import numpy
import matplotlib.pyplot as p
import lab6
reload(lab6)
import lab6_1
reload(lab6_1)
import lab6_3
reload(lab6_3)

# Use a high-pass filter to eliminate the hum. Return a numpy array
# containing usr for hum eliminating filter.
def eliminate_hum(omega):
    pass  # your code here

if __name__ == '__main__':

    pi = numpy.pi

    # Read in the good sound and play
    without_hum,sample_rate = lab6.read_sound('testsound.wav')
    # feel free to comment out the following line after you've
    # heard the sound without hum
    lab6.play_sound(without_hum,sample_rate)
    
    # Read in the corrupted sound and play
    with_hum,sample_rate = lab6.read_sound('hum_testsound.wav')
    p.figure()
    p.plot(with_hum[0:1000])
    # feel free to comment out the following line after you've
    # heard the sound with hum
    lab6.play_sound(with_hum, sample_rate)

    #YOUR VALUE HERE!!!
    omega_hum = 0
                   
    # Determine the filter
    hpf_usr = eliminate_hum(omega_hum)
    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr(hpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, hpf_usr, 'hpf')

    # Apply the filter and play
    hum_removed = numpy.convolve(with_hum, hpf_usr)
    p.figure()
    p.plot(hum_removed[0:1000])
    lab6.play_sound(hum_removed,sample_rate)

    # when ready for checkoff, enable the following line
    #lab6.checkoff(eliminate_hum,'L6_4')

