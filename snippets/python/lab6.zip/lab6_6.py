# template file for Lab #6, Task #6
import numpy
import matplotlib.pyplot as p
import lab6
reload(lab6)
import lab6_1
reload(lab6_1)
import lab6_5
reload(lab6_5)

# Given a frequency omega, return a numpy array that contains the
# unit sample response of a notch filter that will eliminate the hum.
def eliminate_hum_notch(omega):
    pass  # your code here    

if __name__ == '__main__':

    pi = numpy.pi

    # Read in the good sound and play
    # remove the comment from the two lines below if you want to hear
    # hear the sound without hum
    #without_hum,sample_rate = lab6.read_sound('testsound.wav')
    #lab6.play_sound(without_hum,sample_rate)
    
    # Read in the corrupted sound and play
    with_hum,sample_rate = lab6.read_sound('hum_testsound.wav')
    p.figure()
    p.plot(with_hum[0:1000])
    # remove the comment from the line below if you want to hear
    # to hear the sound with hum
    #lab6.play_sound(with_hum, sample_rate)

    #YOUR VALUE HERE!!!
    omega_hum = 0
                   
    # Determine the filter
    notch_usr = eliminate_hum_notch(omega_hum)
    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr(notch_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, notch_usr, 'notch')

    # Apply the filter and play
    hum_removed = numpy.convolve(with_hum, notch_usr)
    p.figure()
    p.plot(hum_removed[0:1000])
    lab6.play_sound(hum_removed,sample_rate)

    # when ready for checkoff, enable the following line
    #lab6.checkoff(eliminate_hum_notch,'L6_6')
