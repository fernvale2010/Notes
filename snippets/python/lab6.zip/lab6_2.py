# template file for Lab #6, Task #2
import numpy
import matplotlib.pyplot as p
import channel
import lab6
reload(lab6)
import lab6_1
reload(lab6_1)

p.ion()

def apply_test_sin(omega_test, filter_usr, n_samples):
    # Create a number of samples equal to twice the length
    # of the filter usr
    n_list = numpy.array(range(n_samples))

    # Create a sinusoidal input at the test frequency
    sine_in = numpy.cos(omega_test*n_list)
    
    # Apply the filter 
    sine_out = numpy.convolve(sine_in, filter_usr)

    # Make input and output same length
    return sine_in, sine_out[0:len(sine_in)]  

# Uses apply_test_sin to determine the frequency response of a filter 
# specified by the numpy array containing the usr.
# Return two numpy arrays, one containing frequencies, one containing
# magnitudes of frequency responses.
def freq_res_usr_direct(usr, num_freqs=200):
    pass  # your code here

# Returns an estimate of the delay of a filter specified by the numpy
# array containing its usr.
def estimate_delay(usr):
    pass  # your code here

if __name__ == '__main__':

    # A low pass filter with a reasonably wide transition
    pi = numpy.pi
    omega_pass = 0.25*pi
    omega_stop = 0.45*pi

    lpf_usr = lab6.lpf(omega_pass, omega_stop)

    print "delay for wide transition filter is",\
          estimate_delay(lpf_usr)

    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr(lpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, lpf_usr, 'lpf')

    omega_1, mag_hejw_chan1 = freq_res_usr_direct(lpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, lpf_usr, 'lpf')

    # A low pass filter with a narrow transition region
    pi = numpy.pi
    omega_pass = 0.44*pi
    omega_stop = 0.45*pi

    lpf_usr = lab6.lpf(omega_pass, omega_stop)

    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr(lpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, lpf_usr, 'lpf')

    omega_1, mag_hejw_chan1 = lab6_1.freq_res_usr_direct(lpf_usr)
    lab6.plot_freq_res_usr(omega_1, mag_hejw_chan1, lpf_usr, 'lpf')

    print "delay for narrow transition filter is",\
          estimate_delay(lpf_usr)

    # when ready for checkoff, enable the following line
    #lab6.checkoff(estimate_delay,'L6_2')

