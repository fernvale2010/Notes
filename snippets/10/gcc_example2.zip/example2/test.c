#include <windows.h> 
#include <stdio.h>
#include <conio.h>
#include "pt.h"
#include "timer.h"

typedef unsigned char u8_t;
typedef unsigned int  u32_t;


static struct 
{
    u8_t idx;
    u8_t done;
    u8_t buffer[100];
}
command;

static u8_t quit = 0;

static unsigned int msec_cnt = 0;

void msec_counter(void)
{
    msec_cnt++;
}


int time_elapsed(unsigned int start, unsigned int duration)
{
    unsigned int ts = msec_cnt;
    if (start + duration <= start) // overflowed
    {
        if (ts >= start)
        {
            if (ts + duration > start + duration)
                return 1;
        }
        return 0;
    }
    else
    {
        if (ts >= start + duration)
            return 1;
        else
            return 0;
    }
}


unsigned int input(){
    unsigned int input_data;
    if (_kbhit()){
        input_data = (unsigned int)_getch();
    }
    else{
        input_data = 0;
    }
    return input_data;
}


PT_THREAD(somethread(struct pt *pt))
{
    static unsigned start;
    
    PT_BEGIN(pt); // switch start
    printf("somethread started\n");

    while(1)
    {
        printf("Waiting for quit\r\n");
        PT_WAIT_UNTIL(pt, (quit > 0));
        printf("Quiting\n");
        break;
    }

    printf("somethread ends\n");
    PT_EXIT(pt);
    PT_END(pt); // switch end
}



PT_THREAD(cmdhandler(struct pt *pt))
{
    static unsigned start;
    
    PT_BEGIN(pt); // switch start
    printf("cmdhandler started\n");

    printf("Handled command: %s\r\n", command.buffer);
    command.done = 0;

    printf("cmdhandler ends\n");
    PT_EXIT(pt);
    PT_END(pt); // switch end
}


PT_THREAD(cmdinput(struct pt *pt))
{
    static unsigned start;
    static struct pt cmdhandler_pt;
    u32_t in;
    
    PT_BEGIN(pt); // switch start
    printf("cmdinput started\n");

    while(1) 
    {
        PT_WAIT_UNTIL(pt, (in = input()) > 0);
        if (in == '\r' || in == '\n')
        {
            // flush buffer
            input();
            command.buffer[command.idx++] = 0; // null terminate
            command.done = 1;
            printf("%s\n", command.buffer);
            command.idx = 0;
            if (strcmp(command.buffer, "quit") == 0)
            {
                quit = 1;
                break;   
            }

            PT_INIT(&cmdhandler_pt);
            PT_SPAWN(pt, &cmdhandler_pt, cmdhandler(&cmdhandler_pt));
        }
        else
        {
            command.buffer[command.idx++] = in;
            if (command.idx >= 100)
                command.idx = 0;
        }
        
    }  

    printf("cmdinput ends\n");
    PT_EXIT(pt);
    PT_END(pt); // switch end
}




void main(void)
{
    struct pt driver_pt;
    struct pt st_pt;
    int k = 0;
    
    //u8_t quit = 0;

    start_timer(10, msec_counter);

    PT_INIT(&driver_pt);
    PT_INIT(&st_pt);

    memset(&command, 0, sizeof(command));
    while(!quit)
    {
        cmdinput(&driver_pt);
        somethread(&st_pt);
    }

    stop_timer();
    printf("main ends\r\n");
}



/*
func()
{
    //PT_BEGIN
    {
        char PT_YIELD_FLAG = 1; 
        switch(s) 
        { case 0:

        //PT_WAIT_UNTIL(pt, condition)
        do {
            s = __LINE__; 
            case __LINE__:;
            if(!(condition)) {
                return PT_WAITING;
            }
        } while(0)         


        //PT_YIELD(pt)
        do {
            PT_YIELD_FLAG = 0;
            s = __LINE__; 
            case __LINE__:;
            if(PT_YIELD_FLAG == 0) {  //PT_YIELD_FLAG is local and always set to 1 upon entry of function.
                return PT_YIELDED;
            }
        } while(0) 

    //PT_END
        }
        PT_YIELD_FLAG = 0;
        PT_INIT(pt); 
        return PT_ENDED; 
    } 
}
*/


