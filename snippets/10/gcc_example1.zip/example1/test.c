
#include <windows.h> 
#include <stdio.h>
#include <conio.h>
#include "pt.h"
#include "timer.h"


static unsigned int msec_cnt = 0;

void msec_counter(void)
{
	msec_cnt++;
}


int time_elapsed(unsigned int start, unsigned int duration)
{
	unsigned int ts = msec_cnt;
	if (start + duration <= start) // overflowed
	{
		if (ts >= start)
		{
			if (ts + duration > start + duration)
				return 1;
		}
		return 0;
	}
	else
	{
		if (ts >= start + duration)
			return 1;
		else
			return 0;
	}
}


#if 0
#define STDIN_FILENO	0

int kbhit()
{
    struct timeval tv;
    fd_set fds;
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds); //STDIN_FILENO is 0
    select(STDIN_FILENO+1, &fds, NULL, NULL, &tv);
    return FD_ISSET(STDIN_FILENO, &fds);
}



#define LC_INIT(s) s = 0;

#define LC_RESUME(s) switch(s) { case 0:

#define LC_SET(s) s = __LINE__; case __LINE__:

#define LC_END(s) } 

#endif

unsigned int input(){
    unsigned int input_data;
    if (_kbhit()){
        input_data = (unsigned int)_getch();
    }
    else{
        input_data = 0;
    }
    return input_data;
}



PT_THREAD(thread1(struct pt *pt))
{
	static int count;
	static unsigned start;
	
	PT_BEGIN(pt); // switch start
	printf("thread1 started\n");

	for(count=0; count<10; count++) 
	{
		printf("%s%d\n", "count = ", count);
		start = msec_cnt;
		PT_WAIT_UNTIL(pt, time_elapsed(start, 100) > 0); // set case
		printf("Elapsed\r\n");
	}

	printf("thread1 ends\n");
	PT_EXIT(pt);
	PT_END(pt); // switch end
}



PT_THREAD(thread2(struct pt *pt))
{
	static unsigned start;
	
	PT_BEGIN(pt); // switch start
	printf("thread2 started\n");

	PT_WAIT_UNTIL(pt, input() == 'q'); // set case

	printf("thread2 ends\n");
	PT_EXIT(pt);
	PT_END(pt); // switch end
}



PT_THREAD(driver_thread(struct pt *pt))
{
	static struct pt pt1, pt2;
    static int state1, state2;

    // { char PT_YIELD_FLAG = 1; LC_RESUME((pt)->lc), PT_YIELD_FLAG is local variable, always set to 1 when function is called again.
	PT_BEGIN(pt); 

	PT_INIT(&pt1);
	PT_INIT(&pt2);

    state1 = 0;
    state2 = 0;

	//PT_WAIT_THREAD(pt, thread1(&pt1) & thread2(&pt2));
    do
    {
        if (!state1)
        {
            state1 = (thread1(&pt1) == PT_EXITED) ? 1 : state1;
        }
        
        if (!state2)
        {
            state2 = (thread2(&pt2) == PT_EXITED) ? 1 : state2;
        }

        // Checks PT_YIELD_FLAG, if 0, return, otherwise go to next line..
        PT_YIELD(pt);
    }
    while(!state1 || !state2);

    PT_EXIT(pt);
	PT_END(pt);
} 


void main(void)
{
	struct pt driver_pt;
	int k = 0;

	start_timer(10, msec_counter);


	PT_INIT(&driver_pt);

	while(PT_SCHEDULE(driver_thread(&driver_pt))) // while(driver_thread() < PT_EXITED);
    {

    }  

	stop_timer();
}




/*
func()
{
    //PT_BEGIN
    {
        char PT_YIELD_FLAG = 1; 
        switch(s) 
        { case 0:

        //PT_WAIT_UNTIL(pt, condition)
        do {
            s = __LINE__; 
            case __LINE__:;
            if(!(condition)) {
                return PT_WAITING;
            }
        } while(0)         


        //PT_YIELD(pt)
        do {
            PT_YIELD_FLAG = 0;
            s = __LINE__; 
            case __LINE__:;
            if(PT_YIELD_FLAG == 0) {  //PT_YIELD_FLAG is local and always set to 1 upon entry of function.
                return PT_YIELDED;
            }
        } while(0) 

    //PT_END
        }
        PT_YIELD_FLAG = 0;
        PT_INIT(pt); 
        return PT_ENDED; 
    } 
}
*/

