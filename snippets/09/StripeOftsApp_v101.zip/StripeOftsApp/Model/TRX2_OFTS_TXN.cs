﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeOftsApp
{
    // OFTS:TBLONLINEFINANCIALTRANSACTION
    public class TRX2_OFTS_TXN
    {
        public long ID { get; set;}                         // 6975
        public DateTime SYSCREATETRNDATETIME { get; set;}   // 12/12/17 16:42:24
        public int REQID { get; set;}                       // 1012
        public string REQNAME { get; set;}                  // BFF
        public string REQREF { get; set;}                   // ch_1BY9LGGIu8nFXSFk4U2FSItI
        public long CAN { get; set;}                        // 1000160008241543
        public string TRNSTATUS { get; set;}                // S/R/N  <== Need to check meaning
        public int TRNTYPE { get; set;}                     // 1
        public string EZLREF { get; set;}                   // 1012AV-171212-164224-6980
        public double TRNAMOUNTSGD { get; set;}             // 1000
        public double TRNAMOUNT { get; set;}                // 1000
        public long TRNTIME { get; set;}                    // 20171212084222000
        public int PRETRNINFO2 { get; set;}                 // 9 (PTC before)
        public int TRNINFO2 { get; set;}                    // 10 (PTC after)
        public DateTime SYSLOCKTRNTIMESTAMP { get; set;}    // 12/12/17 16:44:58
        public DateTime SYSSTATUSUPDATETIMESTAMP { get; set;} // 12/12/17 16:45:06
        public DateTime LASTTRNUPDATETIMESTAMP { get; set;} // 12/12/17 16:45:06
            
    }
}


