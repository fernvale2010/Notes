﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using Encryption;

namespace StripeOftsApp
{
    /// <summary>
    /// Class contains the constants used in the service.
    /// </summary>
    public static class Constants
    {
        public static string ReportPath = AppDomain.CurrentDomain.BaseDirectory + ConfigurationManager.AppSettings["ReportsPath"];
        
        public static string EzlAPIKey = ConfigurationManager.AppSettings["ezlKey"];
        
        public static string HttpTimeout = ConfigurationManager.AppSettings["httpTimeout"];
        
        public static string ForceAutoRefund = ConfigurationManager.AppSettings["forceAutoRefund"];
        
        public static string checkInterval = ConfigurationManager.AppSettings["checkInterval"];
        
        public static string DownloadInterval = ConfigurationManager.AppSettings["DownloadInterval"];
        
        public static int MinHttpTimeout = 20; // Seconds, minium that can be set
        
        public static int MincheckInterval = 10; // minutes, minium that can be set
        
        public static int MinDownloadInterval = 60; // minutes, minium that can be set
        
        public static string LastProcessedDateKey = "lastProcessedDate";
        
        //public static string ConnectionString = DataEncryption.DecryptData(ConfigurationManager.ConnectionStrings["dbConnection"].ConnectionString, ReadKey(AppDomain.CurrentDomain.BaseDirectory + "\\Privatekey.xml"));
        public static string ConnectionString = ConfigurationManager.ConnectionStrings["dbConnection"].ConnectionString;
        
        public static string TBLTrx2OftsTxnName = "TBLONLINEFINANCIALTRANSACTION";


        private static string ReadKey(string fileName)
        {
            StreamReader stream = new StreamReader(fileName);
            string key = stream.ReadToEnd();
            stream.Close();
            return key;
        }
        
#if (true)
        public static int __LINE__([System.Runtime.CompilerServices.CallerLineNumber] int lineNumber = 0)
        {
            return lineNumber;
        }
        public static string __FILE__([System.Runtime.CompilerServices.CallerFilePath] string fileName = "")
        {
            return fileName;
        }
#endif        
    }
}
