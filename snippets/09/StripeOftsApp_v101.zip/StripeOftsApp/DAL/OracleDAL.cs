﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using Oracle.DataAccess.Client;
using Dapper;
using System.Text.RegularExpressions;

namespace StripeOftsApp
{
    public static class OracleDAL
    {
        public static IEnumerable<TRX2_OFTS_TXN> GetTBLTrx2OftsTxnRecords(string startDateString, string endDateString)
        {
            var sqlQuery = "None";
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();
                    
                    sqlQuery = string.Format("SELECT * FROM {0} WHERE" +
                                             " (SYSCREATETRNDATETIME BETWEEN to_date(('{1}'),'dd-MM-yy HH24:mi:SS')" +
                                             " AND to_date(('{2}'),'dd-MM-yy HH24:mi:SS')) "
                                             , Constants.TBLTrx2OftsTxnName, startDateString, endDateString);
                    
                    Logger.DailyLog("Info : " + sqlQuery);
                    return connection.Query<TRX2_OFTS_TXN>(sqlQuery);
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + sqlQuery);
                Logger.DailyLog("Error : " + exception);
            }
            return null;
        }
    }
}


