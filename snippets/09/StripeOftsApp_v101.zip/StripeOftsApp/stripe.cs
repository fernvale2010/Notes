﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Stripe;

namespace StripeOftsApp
{
    public static class StripeOps
    {
        private static void StripeExceptionHandler(StripeException e)
        {
            // Log the error
            Logger.DailyLog("Error : ********************* Exception *******************************");
            Logger.DailyLog(String.Format("Error : {0}, {1} - Exception={2}, code={3}",
                                          Constants.__FILE__(), Constants.__LINE__(), e, e.StripeError.ErrorType));
            switch (e.StripeError.ErrorType)
            {
                case "card_error":
                    break;
                case "api_connection_error":
                    // Network problem, retry
                    throw e;
                    //break;
                case "api_error":
                    break;
                case "authentication_error":
                    break;
                case "invalid_request_error":
                    // This error occurs if API key is wrong, in this case, we are not throwing
                    // the exception, but let the method call ends..
                    //throw;
                    break;
                case "idempotency_error":
                    break;
                case "rate_limit_error":
                    // retry
                    throw e;
                    //break;
                case "validation_error":
                    break;
                default:
                    // Unknown Error Type
                    break;
            }
        }

        // Get charge objects starting from fd to td (both inclusive, in UTC)
        // Returns List of StripeCharge
        public static List<StripeCharge> GetStripeChargeList(DateTime fd, DateTime td)
        {
            List<StripeCharge> chargeItems = new List<StripeCharge>();
            var chargeService = new StripeChargeService();
            bool noErr = true;

            // get some filtering
            var opt = new StripeChargeListOptions();
            opt.Limit = 100;
            //opt.IncludeTotalCount = true;
            opt.Created = new StripeDateFilter()
            {
                GreaterThanOrEqual = fd,
                LessThanOrEqual = td
            };

            while (noErr)
            {
                StripeList<StripeCharge> s = null;
                try
                {
                    s = chargeService.List(opt);
                    chargeItems.AddRange(s.Data);
                    if (s.HasMore)
                    {
                        // get the object id of last item, so that next loop will fetch
                        // from that id onwards, until limit..
                        // int count = s.Data.Count;
                        // opt.StartingAfter = s.Data[count - 1].Id;
                        opt.StartingAfter = s.LastOrDefault().Id;
                    }
                    else
                    {
                        noErr = false;
                        break;
                    }
                }
                catch (StripeException e)
                {
                    StripeExceptionHandler(e);
                    noErr = false;
                }
                catch (AggregateException ae)
                {
                    // ExceptionDispatchInfo.Capture(ex.InnerException).Throw();

                    if (ae.InnerException is TaskCanceledException)
                    {
                        Logger.DailyLog("Error : ********************* Exception *******************************");
                        Logger.DailyLog(String.Format("Error : {0}, {1} - Exception {2}",
                                                      Constants.__FILE__(), Constants.__LINE__(), ae));
                        throw; // will cause a retry
                    }
                    noErr = false;
                }
                catch (Exception exp)
                {
                    Logger.DailyLog("Error : ********************* Exception *******************************");
                    Logger.DailyLog(String.Format("Error : {0}, {1} - Exception {2}",
                                                  Constants.__FILE__(), Constants.__LINE__(), exp));
                    //Console.WriteLine(exp);
                    noErr = false;
                }
            }

            return chargeItems;
        }
        
        
        // Refund a stripe charge
        public static StripeRefund RefundStripeCharge(StripeCharge sc)
        {
            var refundOptions = new StripeRefundCreateOptions()
            {
                Amount = sc.Amount,
                Reason = StripeRefundReasons.Unknown
            };
            
            var refundService = new StripeRefundService();
            try
            {
                StripeRefund refund = refundService.Create(sc.Id, refundOptions);
                return refund;
            }
            catch (StripeException e)
            {
                StripeExceptionHandler(e);
            }
            catch (AggregateException ae)
            {
                if (ae.InnerException is TaskCanceledException)
                {
                    Logger.DailyLog("Error : ********************* Exception *******************************");
                    Logger.DailyLog(String.Format("Error : {0}, {1} - Exception {2}",
                                                  Constants.__FILE__(), Constants.__LINE__(), ae));
                    throw; // will cause a retry
                }
            }
            catch (Exception exp)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog(String.Format("Error : {0}, {1} - Exception {2}",
                                              Constants.__FILE__(), Constants.__LINE__(), exp));
                //Console.WriteLine(exp);
            }
            
            return null;
        }
        


        // https://alastaircrabtree.com/implementing-a-simple-retry-pattern-in-c/
        // How to use:
        // var maxRetryAttempts = 3;
        // var pauseBetweenFailures = TimeSpan.FromSeconds(2);
        // RetryOnException(maxRetryAttempts, pauseBetweenFailures, () => {
        //    product = httpClient.Get("https://example.com/api/products/1");
        // });
        public static void RetryOnException(int times, TimeSpan delay,  Action operation)
        {
            var attempts = 0;
            do
            {
                try
                {
                    attempts++;
                    operation();
                    break; // Success! Lets exit the loop!
                }
                catch (Exception ex)
                {
                    Logger.DailyLog("Error : ********************* Exception *******************************");
                    if (attempts == times)
                    {
                        //Console.WriteLine("No more retries - " + ex);
                        Logger.DailyLog("Error: No more retries - " + ex.Message);
                        throw;
                    }
                    
                    // Log the error.
                    string s = String.Format("Error : {0}, {1} - Exception caught on attempt {2} - will retry after delay {3}",
                                             Constants.__FILE__(), Constants.__LINE__(), attempts, delay);
                    Logger.DailyLog(s);
                    //Console.WriteLine("***** Retry: " + attempts);
                    Task.Delay(delay).Wait();
                }
            } while (true);
        }

    } // end class
}
