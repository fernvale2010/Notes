﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Stripe;
using System.Globalization;
using System.Reflection;

namespace StripeOftsApp
{
    class Program
    {
        public static void Main(string[] args)
        {
            bool forceAutoRefund = false;
            int timeout = 60;
            int checkInterval = 0;
            int downloadInterval = 0;
            string canValue = "";
            
            string version = Assembly.GetEntryAssembly().GetName().Version.ToString();
            
            //Console.WriteLine("App starts!");
            Logger.DailyLog("Info: Run starts! - Ver: " + version);

            // Do this only once..
            StripeConfiguration.SetApiKey(Constants.EzlAPIKey);
            
            // set the http timeout, default to 60 sec if unable to parse config setting
            Int32.TryParse(Constants.HttpTimeout, out timeout);
            timeout = (timeout < Constants.MinHttpTimeout) ? Constants.MinHttpTimeout : timeout;
            StripeConfiguration.HttpTimeSpan = TimeSpan.FromSeconds(timeout);
            
            Int32.TryParse(Constants.checkInterval, out checkInterval);
            Int32.TryParse(Constants.DownloadInterval, out downloadInterval);
            checkInterval = (checkInterval < Constants.MincheckInterval) ? Constants.MincheckInterval : checkInterval;  // in minutes
            downloadInterval = (downloadInterval < Constants.MinDownloadInterval) ? Constants.MinDownloadInterval : downloadInterval; // in minutes
            
            forceAutoRefund = (Constants.ForceAutoRefund == "true");
            
            DateTime td = DateTime.UtcNow.AddMinutes(-checkInterval); //
            //DateTime td = DateTime.ParseExact("14-03-2018 16:00:00 UTC", "dd-MM-yyyy HH:mm:ss UTC", CultureInfo.InvariantCulture);
            DateTime fd = td.AddMinutes(-downloadInterval);
            if(args != null)
            {
                if (args.Count() == 0)
                {
                    fd = td.AddMinutes(-Constants.MinDownloadInterval);
                }
                else if (args.Count() == 1)
                {
                    bool res = DateTime.TryParseExact(args[0], "dd-MM-yy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out fd);
                    if (res)
                    {
                        fd = fd.ToUniversalTime(); // convert to UTC
                    }
                }
                else
                {
                    Logger.DailyLog("Error : Application takes either no aruguments or only one date argument in \"dd-MM-yy HH:mm:ss\" format");
                    Logger.DailyLog("Info : Default to fetching records from 1 hour prior");
                }
            }
            td = td.AddSeconds(-1);
            
            Logger.DailyLog(String.Format("Info: Fetch Stripe records from {0} to {1}", fd.ToString("yyyy-MM-dd HH:mm:ss"), td.ToString("yyyy-MM-dd HH:mm:ss")));
            
            List<StripeCharge> ListStripe = new List<StripeCharge>();
            List<StripeCharge> ListUnmatched = new List<StripeCharge>();
            try
            {
                StripeOps.RetryOnException(3, TimeSpan.FromSeconds(2),
                                           () => {
                                               ListStripe = StripeOps.GetStripeChargeList(fd, td);
                                           });
                
                if (ListStripe.Count > 0)
                {
                    Logger.DailyLog(String.Format("Info: Records downloaded: {0}", ListStripe.Count));
                    
                    //debugging
                    /*foreach (StripeCharge sc in ListStripe)
                    {
                        if (sc.Metadata.Count > 0)
                        {
                            if (sc.Metadata.TryGetValue("CAN", out canValue))
                            {
                            }
                        }
                        
                        DateTime utc = sc.Created.ToLocalTime();
                        
                        Console.WriteLine(sc.Id + ", " + canValue + ", " + utc + ", " + sc.Status );
                    }*/
                    // debugging
                    
                    // Check with OFTS that all stripe records are present/accounted for..
                    string tdstr = td.AddMinutes(10).ToLocalTime().ToString("dd-MM-yy HH:mm:ss");
                    string fdstr = fd.ToLocalTime().ToString("dd-MM-yy HH:mm:ss");
                    IEnumerable<TRX2_OFTS_TXN> ofts = OracleDAL.GetTBLTrx2OftsTxnRecords(fdstr, tdstr);
                    string scheme = "none";
                    bool captured = false;
                    if (ofts.IsAny())
                    {
                        foreach (StripeCharge sc in ListStripe)
                        {
                            if (sc.Metadata.Count > 0)
                            {
                                if (sc.Metadata.TryGetValue("Scheme", out scheme))
                                {
                                }
                                else
                                {
                                    scheme = "none";
                                }
                            }
                            
                            //Console.WriteLine(sc.Id + ", " + sc.Created + ", " + sc.Status);
                            // check only if not refunded, is captured and is EZ-MOBILE or NFC..
                            if (sc.Captured.HasValue)
                                captured = sc.Captured.Value;
                            else
                                captured = false;
                            if (sc.Refunded == false && captured == true &&
                                (String.Equals(scheme, "EZ-MOBILE", StringComparison.InvariantCultureIgnoreCase) || String.Equals(scheme, "NFC", StringComparison.InvariantCultureIgnoreCase)))
                            {
                                //if (ofts.Any(x => x.REQREF == sc.Id)) // look for a stripeId match in OFTS..
                                if (ofts.Any(x => String.Equals(x.REQREF, sc.Id, StringComparison.InvariantCultureIgnoreCase)))
                                {
                                    continue;
                                }
                                else
                                {
                                    ListUnmatched.Add(sc);
                                }
                            }
                            else
                            {
                                Console.WriteLine(sc.Id + ", " + sc.Created + ", " + sc.Status + ", " + captured  + ", " + scheme);
                            }
                        }
                    }
                    else
                    {
                        Func<Dictionary<string,string>,bool> meta = x => {
                            if (x.Count > 0)
                            {
                                string scheme1;
                                if (x.TryGetValue("Scheme", out scheme1))
                                {
                                    if (String.Equals(scheme1, "EZ-MOBILE", StringComparison.InvariantCultureIgnoreCase) ||
                                        String.Equals(scheme1, "NFC", StringComparison.InvariantCultureIgnoreCase))
                                    {
                                        return true;
                                    }
                                }
                            }
                            return false;
                        };
                        
                        List<StripeCharge> tempList = ListStripe.Where(x => x.Refunded == false && (x.Captured.HasValue && x.Captured.Value == true) &&
                                                                       meta(x.Metadata)).ToList();
                        
                        //Console.WriteLine("Count = " + tempList.Count);
                        ListUnmatched.AddRange(tempList);
                        
                        // DEBUGGING USE
                        /*
                        foreach(StripeCharge sc in ListStripe)
                        {
                            if (sc.Metadata.Count > 0)
                            {
                                if (sc.Metadata.TryGetValue("Scheme", out scheme))
                                {
                                }
                                else
                                {
                                    scheme = "none";
                                }
                            }
                            Console.WriteLine(sc.Id + ", " + sc.Created + ", " + sc.Status + ", " + sc.Captured  + ", " + sc.Refunded + ", " + scheme);
                        }
                        */
                    }
                    
                    if (ListUnmatched.Count > 0)
                    {
                        Logger.DailyLog(String.Format("Info: Records Unmatched: {0}", ListUnmatched.Count));
                        
                        if (forceAutoRefund)
                        {
                            StripeRefund re = null;
                            
                            // Process Unmatched Stripe records..
                            foreach(StripeCharge sc in ListUnmatched)
                            {
                                //Console.WriteLine("Refunding... " + sc.Id);
                                Logger.DailyLog("Info: Refunding... " + sc.Id);
                                StripeOps.RetryOnException(3, TimeSpan.FromSeconds(2),
                                                           () => {
                                                               re = StripeOps.RefundStripeCharge(sc);
                                                           });
                                if (re != null)
                                {
                                    if (re.Status == "succeeded")
                                    {
                                        //Console.WriteLine("Refund succeeded: " + re.ChargeId);
                                        Logger.DailyLog("Info: Refund succeeded: " + re.ChargeId);
                                    }
                                    else
                                    {
                                        //Console.WriteLine("Refund failed: " + re.Status + ", " + re.ChargeId);
                                        Logger.DailyLog("Info: Refund failed: " + re.Status + ", " + re.ChargeId);
                                    }
                                }
                                else
                                {
                                    //Console.WriteLine("Refund failed: re is null " + sc.Id);
                                    Logger.DailyLog("Info: Refund failed: re is null " + sc.Id);
                                }

                            }
                        }
                        else
                        {
                            string fileStr = Constants.ReportPath + "\\" + DateTime.Now.Date.ToString("dd-MM-yyyy") + "\\" + "Stripe_" + DateTime.Now.ToString("HH_mm_ss") + ".csv";
                            //Utilities.WriteDelimitedFile<StripeCharge>(ListUnmatched, new FileInfo(fileStr), ",");
                            Utilities.GenerateCSVForRefund(ListUnmatched, new FileInfo(fileStr));
                        }
                    }
                    else
                    {
                        Logger.DailyLog("Info: No unmatched Stripe records");
                    }
                }
                else
                {
                    Logger.DailyLog("Info: Nothing downloaded from Stripe");
                }
            }
            catch (Exception e)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog(String.Format("Error: {0}, {1} - Exception caught:  {2}",
                                              Constants.__FILE__(), Constants.__LINE__(), e));
                //Console.WriteLine("main - Exception caught: " + e.Message);
            }
            
            Logger.DailyLog("Info: ********** Run ends! **********");
            
            //Console.Write("Press any key to continue . . . ");
            //Console.ReadKey(true);
        }
    }
}

