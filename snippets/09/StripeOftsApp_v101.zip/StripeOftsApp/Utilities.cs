﻿
using System;
using System.Configuration;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Text;
using System.Diagnostics;
using Stripe;

namespace StripeOftsApp
{
    /// <summary>
    /// Description of Utilities.
    /// </summary>
    public static class Utilities
    {
        private static Configuration configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
        
        // https://stackoverflow.com/questions/4758598/write-values-in-app-config-file
        public static void SaveConfig(string key, string value)
        {
            var entry = configFile.AppSettings.Settings[key];
            if (entry == null)
                configFile.AppSettings.Settings.Add(key, value);
            else
                configFile.AppSettings.Settings[key].Value = value;

            configFile.Save(ConfigurationSaveMode.Modified);
        }
        
        public static DateTime GetLastProcessedDate()
        {
            DateTime d;
            var entry = configFile.AppSettings.Settings[Constants.LastProcessedDateKey];
            
            if (entry != null)
            {
                d = DateTime.ParseExact(entry.Value, "yyyy-MM-dd", CultureInfo.InvariantCulture);
            }
            else
            {
                d = DateTime.UtcNow.AddDays(-1).Date;  // start from yesterday
            }
            return d;
        }
        
        public static void SaveLastProcessedDate(DateTime d)
        {
            SaveConfig(Constants.LastProcessedDateKey, d.Date.ToString("yyyy-MM-dd"));
        }
        
        
        public static bool IsAny<T>(this IEnumerable<T> data)
        {
            return data != null && data.Any();
        }
        
        
        ///
        /// Method to write a delimited file, given a generic enumerable.
        ///
        /// The type T
        /// an enumerable of type T
        /// The destination file info
        /// The delimiter ("," for example)
        public static void WriteDelimitedFile<T>(IEnumerable<T> list, FileInfo saveFile, string delimiter)
        {
            if (list == null) return;
            string tmpDelimiter = delimiter + "\t";

            if (!saveFile.Directory.Exists)
            {
                System.IO.Directory.CreateDirectory(saveFile.DirectoryName);
            }
            try
            {
                using (StreamWriter sw = saveFile.CreateText())
                {
                    PropertyInfo[] props = typeof(T).GetProperties();
                    var headerNames = props.Select(x => x.Name);
                    sw.WriteLine(string.Join(delimiter, headerNames.ToArray()));
                    foreach (T item in list)
                    {
                        T item1 = item; // to prevent access to modified closure
                        var values = props
                            .Select(x => x.GetValue(item1, null) ?? "") // the null coalescing operator, replace null with ""
                            .Select(x => x.ToString())
                            .Select(x => x.Contains(delimiter) ? "\"" + x + "\"" : x); // if a value contains the delimiter, surround with quotes
                        sw.WriteLine(string.Join(tmpDelimiter, values.ToArray()));
                    }
                    sw.Close();
                }
            }
            catch (Exception e)
            {
                Logger.DailyLog("Error : Exception in WriteDelimitedFile " + e);
                throw;
            }

        }
        
        public static void GenerateCSVForRefund(List<StripeCharge> list, FileInfo saveFile)
        {
            string canValue = "";
            string scheme = "";
            if (list == null) return;
            
            if (!saveFile.Directory.Exists)
            {
                System.IO.Directory.CreateDirectory(saveFile.DirectoryName);
            }
            
            StringBuilder sb = new StringBuilder();
            
            string csvHeader = "Id,Amount,CAN,Captured,Date,Scheme";
            
            sb.AppendLine(csvHeader);

            try
            {
                using (StreamWriter Writer = saveFile.CreateText())
                {
                    foreach (var c in list)
                    {
                        if (c.Metadata.Count > 0)
                        {
                            if (c.Metadata.TryGetValue("CAN", out canValue))
                            {
                            }
                            
                            if (c.Metadata.TryGetValue("Scheme", out scheme))
                            {
                            }
                            else
                            {
                                scheme = "none";
                            }
                        }
                        
                        try
                        {
                            string text = c.Id + "," +
                                c.Amount/100.0 + ",\t" +
                                canValue + "," +
                                c.Captured + "," +
                                c.Created.ToLocalTime() + "," +
                                scheme
                                ;
                            
                            sb.AppendLine(text);
                        }
                        catch (Exception e)
                        {
                            Logger.DailyLog(String.Format("Error: {0}, {1} - Exception caught: {2}",
                                                          Constants.__FILE__(), Constants.__LINE__(), e.Message));
                        }
                    }

                    Writer.WriteLine(sb.ToString());
                }
            }
            catch (Exception exp)
            {
                Logger.DailyLog(String.Format("Error: {0}, {1} - Exception {2}",
                                              Constants.__FILE__(), Constants.__LINE__(), exp.Message));
            }
        }
        
        public static void GenerateCSVForRefund2(List<StripeCharge> list, FileInfo saveFile)
        {
            if (list == null) return;
            
            if (!saveFile.Directory.Exists)
            {
                System.IO.Directory.CreateDirectory(saveFile.DirectoryName);
            }
            
            StringBuilder sb = new StringBuilder();
            
            string csvHeader = "Object,Amount,AmountRefunded,ApplicationId,Application,ApplicationFeeId,ApplicationFee," +
                "BalanceTransactionId,BalanceTransaction,Captured,Created,Currency,CustomerId,Customer,Description," +
                "DestinationId,Destination,DisputeId,Dispute,FailureCode,FailureMessage,InvoiceId,Invoice," +
                "LiveMode,OnBehalfOfId,OnBehalfOf,Order,OutcomeId,Outcome,Paid,ReceiptEmail,ReceiptNumber,Refunded," +
                "ReviewId,Review,Shipping,Source,SourceTransferId,SourceTransfer,StatementDescriptor,Status,TransferId," +
                "Transfer,TransferGroup,Id,StripeResponse";
            
            sb.AppendLine(csvHeader);

            try
            {
                using (StreamWriter Writer = saveFile.CreateText())
                {
                    foreach (var c in list)
                    {
                        try
                        {
                            string text = c.Object + "," +
                                c.Amount + "," +
                                c.AmountRefunded + "," +
                                c.ApplicationId + "," +
                                c.Application + "," +
                                c.ApplicationFeeId + "," +
                                c.ApplicationFee + "," +
                                c.BalanceTransactionId + "," +
                                c.BalanceTransaction + "," +
                                c.Captured + "," +
                                c.Created + "," +
                                c.Currency + "," +
                                c.CustomerId + "," +
                                c.Customer + "," +
                                c.Description + "," +
                                c.DestinationId + "," +
                                c.Destination + "," +
                                c.DisputeId + "," +
                                c.Dispute + "," +
                                c.FailureCode + "," +
                                c.FailureMessage + "," +
                                c.InvoiceId + "," +
                                c.Invoice + "," +
                                c.LiveMode + "," +
                                c.OnBehalfOfId + "," +
                                c.OnBehalfOf + "," +
                                c.Order + "," +
                                c.OutcomeId + "," +
                                c.Outcome + "," +
                                c.Paid + "," +
                                c.ReceiptEmail + "," +
                                c.ReceiptNumber + "," +
                                c.Refunded + "," +
                                c.ReviewId + "," +
                                c.Review + "," +
                                c.Shipping + "," +
                                c.Source + "," +
                                c.SourceTransferId + "," +
                                c.SourceTransfer + "," +
                                c.StatementDescriptor + "," +
                                c.Status + "," +
                                c.TransferId + "," +
                                c.Transfer + "," +
                                c.TransferGroup + "," +
                                c.Id + "," +
                                c.StripeResponse;
                            
                            sb.AppendLine(text);
                        }
                        catch (Exception e)
                        {
                            Logger.DailyLog(String.Format("Error: {0}, {1} - Exception caught: {2}",
                                                          Constants.__FILE__(), Constants.__LINE__(), e.Message));
                        }
                    }

                    Writer.WriteLine(sb.ToString());
                }
            }
            catch (Exception exp)
            {
                Logger.DailyLog(String.Format("Error: {0}, {1} - Exception {2}",
                                              Constants.__FILE__(), Constants.__LINE__(), exp.Message));
            }
        }
        

        
        // https://stackoverflow.com/questions/4994277/memory-address-of-an-object-in-c-sharp
        // ConditionalWeakTable<key, value>
        // In this case, key is reconSummary, and value is RefId..
        // e.g usage: GetRefId(reconSummary).ToString()
        //
        private static readonly ConditionalWeakTable<object, RefId> _ids = new ConditionalWeakTable<object, RefId>();

        public static Guid GetRefId<T>(this T obj) where T: class
        {
            if (obj == null)
                return default(Guid);

            // GetOrCreateValue:
            // Atomically searches for a specified key in the table and returns the corresponding value.
            // If the key does not exist in the table, the method invokes the default constructor of the
            // class that represents the table's value to create a value that is bound to the specified key.
            // In this case RefId is the value.
            return _ids.GetOrCreateValue(obj).Id;
        }

        private class RefId
        {
            // In C# 6 and later, you can initialize auto-implemented properties similarly to fields:
            // public string FirstName { get; set; } = "Jane";
            //
            public Guid Id { get; set; }
            
            // default constructor
            public RefId()
            {
                Id = Guid.NewGuid();
            }
        }
    }

}

