﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StripeOftsApp
{
    /// <summary>
    /// Class to trace exception details to trx2_dblogs table
    /// </summary>
    public class Logger
    {
        // This executes when the DailyLog() runs
        static Logger()
        {
            try
            {
                if (!Directory.Exists(Constants.ReportPath + "/Logs/"))
                {
                    Directory.CreateDirectory(Constants.ReportPath + "/Logs/");
                }
            }
            catch { }
        }        

        private static string escape(string s)
        {
            if (s == null) return "";
            return s.Replace("'", "''");
        }

        public static void DailyLog(string logText)
        {
            try
            {
                using (StreamWriter w = File.AppendText(Constants.ReportPath + "/Logs/" + "\\" + DateTime.Now.ToString("dd-MM-yyyy") + ".log"))
                {
                    w.WriteLine(DateTime.Now.ToString("dd/MM/yyyy H:mm:ss") + " - " + logText);  
                    w.Flush();
                    w.Close();
                }
            }
            catch { }
        }
    }
}
