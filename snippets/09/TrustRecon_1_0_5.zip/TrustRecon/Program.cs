﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Diagnostics;


namespace TrustRecon
{
    class Program
    {
        public static void Main(string[] args)
        {
            Logger.DailyLog(string.Format("Info : ---------------- Run starts! - version: {0} ----------------", Constants.AppVersion));
            Globals.DebugRun = false;
            
            if (args.Length >= 1)
            {
                if (args[0].Equals("--Debug"))
                {
                    Console.WriteLine("Recon in Debug Mode");
                    // Debug run, use startdate/enddate from Config file..
                    DateTime locDate = DateTime.MinValue;
                    DateTime.TryParseExact(Constants.ReconStartDate, "dd-MMM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out locDate);
                    Globals.ProcessStartDate = locDate;
                    DateTime.TryParseExact(Constants.ReconEndDate, "dd-MMM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out locDate);
                    Globals.ProcessEndDate = locDate;
                    Globals.DebugRun = true;
                }
            }
            
            if (Globals.DebugRun == false)
            {
                // Otherwise initialize to 1 day before..
                Globals.ProcessStartDate = DateTime.Now.AddDays(-1);
                Globals.ProcessEndDate = DateTime.Now;
            }
            
            Globals.ProcessStartDateString = Globals.ProcessStartDate.ToString(Constants.ProcessingDateFormat);
            Globals.ProcessEndDateString = Globals.ProcessEndDate.ToString(Constants.ProcessingDateFormat);
            

            // IMPORT input records into DB tables..
            //MainTest01(args, Globals.ProcessEndDate.AddDays(-1));
            
            MainImportProcess(Globals.ProcessStartDate);
            
            // run recon
            //MainReconProcess();
            
            Logger.DailyLog("Info : ---------------- Run ends! ----------------\n\n");
            Console.Write("Press any key to continue . . . ");
            Console.ReadKey(true);
        }
        
        
        public static void MainReconProcess()
        {
            DateTime currentProcessingDate = DateTime.MinValue;
            DateTime lastrun = OracleDAL.GetReconRunDetails();
            if (DateTime.MinValue == lastrun)
            {
                lastrun = Globals.ProcessStartDate;
            }
            else
            {
                Globals.ProcessStartDate = lastrun.AddDays(1);
            }
            
            currentProcessingDate = Globals.ProcessStartDate.Date;
            Logger.DailyLog(string.Format("Info : Runs from ({0}) to ({1})", Globals.ProcessStartDateString, Globals.ProcessEndDateString));
            
            // The initial run for "today"
            ReconMgr.RunReconOnceByDate(currentProcessingDate, true);
            // update Last Run Date
            OracleDAL.UpdateReconRunDetails(currentProcessingDate);
            
            currentProcessingDate = currentProcessingDate.AddDays(1);
            while(currentProcessingDate < Globals.ProcessEndDate.Date)
            {
                // Here are the subsequent runs..
                ReconMgr.RunReconOnceByDate(currentProcessingDate);
                
                // update Last Run Date
                OracleDAL.UpdateReconRunDetails(currentProcessingDate);
                
                // Next day
                currentProcessingDate = currentProcessingDate.AddDays(1);
            }

        }
        
        
        // Import CSV files
        public static void MainImportProcess(DateTime importDate)
        {
            string arch = Constants.CSVArchiveFolder + "\\" + DateTime.Now.Date.ToString("dd-MMM-yy");
            if (!Directory.Exists(arch))
            {
                Directory.CreateDirectory(arch);
            }
            
            if (Directory.Exists(Constants.CSVInputFolder))
            {
                string[] files = Utils.GetFileList(Constants.CSVInputFolder);
                if (files.Length == 0)
                {
                    Console.WriteLine("No files in folder " + Constants.CSVInputFolder);
                }
                else
                {
                    foreach(string i in files)
                    {
                        Console.WriteLine(i);
                        Console.WriteLine(Path.GetDirectoryName(i) + ", " +  Path.GetFileName(i));
                        Console.WriteLine("--------------------------");
                        
                        if (i.Contains("Stripe"))
                        {
                            Console.WriteLine("Stripe file");
                            
                            List<TBLTrustStripeSrc> ListStripe = CSVParser.TBLTrustStripeSrcCsvParser(i).ToList();
                            ListStripe.ForEach(x => {x.ImportedDate = importDate;});
                            OracleDAL.ImportTBLTrustStripeSrc(ListStripe.ToList());
                        }
                        else if (i.Contains("Wallet"))
                        {
                            Console.WriteLine("Wallet file");
                            
                            List<TBLTrustWalletSrc> ListWallet = CSVParser.TBLTrustWalletSrcCsvParser(i).ToList();
                            ListWallet.ForEach(x => {x.ImportedDate = importDate;});
                            OracleDAL.ImportTBLTrustWalletSrc(ListWallet.ToList());
                        }
                        
                        Utils.MoveWithReplace(i, arch + "\\" + Path.GetFileName(i));
                        Console.WriteLine();
                    }
                }
            }
        }
        
        
        //-------------------------------------------------------------------------------
        // TESTING USE
        //-------------------------------------------------------------------------------
        
        public static void MainTest04(string[] args)
        {
            Console.WriteLine("App path: " + Constants.AppPath);
            Console.WriteLine("Report path: " + Constants.ReportPath);
            
            DateTime lastrun = OracleDAL.GetReconRunDetails();
            
            Console.WriteLine("RunDetails DateTime = " + lastrun + ", MinValue :" + DateTime.MinValue);
            if (lastrun == DateTime.MinValue)
                lastrun = Globals.ProcessStartDate;
            
            lastrun = lastrun.AddDays(1);
            OracleDAL.UpdateReconRunDetails(lastrun);
            
            OracleDAL.InsertLogToReconHistory(Globals.ProcessStartDate, "ERROR", "This is a test message");
            
            Dictionary<string,string> dict = new Dictionary<string, string>();
            dict.Add("Date", lastrun.ToString("D"));
            dict.Add("Message", "Hello World");
            OracleDAL.InsertLogToReconHistory(Globals.ProcessEndDate, "INFO", Utils.DictionarySerialize(dict));
            
            Console.WriteLine(Utils.CalculateMD5(Constants.AppPath + "Encryption.dll"));
            Logger.DailyLog(string.Format("Info : {0} MD5: {1}", Constants.AppPath + "Encryption.dll", Utils.CalculateMD5(Constants.AppPath + "Encryption.dll")));
            
            
            Console.WriteLine("--------------------------");
            
            // C:\work\SharpDevelop\TestList\TestList\bin\Debug
            Console.WriteLine(Directory.GetCurrentDirectory());
            Console.WriteLine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
            Console.WriteLine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location));
            string str = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);
            Console.WriteLine(str);
            
            Console.WriteLine("--------------------------");
            
            // C:\work\SharpDevelop\TestList\TestList\bin\Debug\
            Console.WriteLine(AppDomain.CurrentDomain.BaseDirectory);
            
            Console.WriteLine("--------------------------");
            
            string[] files = Utils.GetFileList(@"c:\work");
            foreach(string i in files)
            {
                Console.WriteLine(i);
                Console.WriteLine(Path.GetDirectoryName(i) + ", " +  Path.GetFileName(i));
                Console.WriteLine("--------------------------");
                
                FileInfo fileInfo = new FileInfo(i);
                Console.WriteLine(fileInfo.FullName);
                Console.WriteLine(fileInfo.DirectoryName + ", " + fileInfo.Name  + ", " + fileInfo.Length);
                Console.WriteLine("--------------------------");
            }
        }
        
        
        // Run recon
        public static void MainTest03(string[] args)
        {
            DateTime currentProcessingDate = DateTime.MinValue;
            
            currentProcessingDate = Globals.ProcessStartDate.Date;
            
            // The initial run for "today"
            ReconMgr.RunReconOnceByDate(currentProcessingDate, true);
            // update Last Run Date
            OracleDAL.UpdateReconRunDetails(currentProcessingDate);
            
            currentProcessingDate = currentProcessingDate.AddDays(1);
            while(currentProcessingDate < Globals.ProcessEndDate.Date)
            {
                // Here are the subsequent runs..
                ReconMgr.RunReconOnceByDate(currentProcessingDate);
                
                // update Last Run Date
                OracleDAL.UpdateReconRunDetails(currentProcessingDate);
                
                // Next day
                currentProcessingDate = currentProcessingDate.AddDays(1);
            }

        }
        
        
        public static void MainTest02(string[] args)
        {
            string processingDate = DateTime.Now.ToString(Constants.ProcessingDateFormat);
            IEnumerable<TBLTrustReconStatus> TrustReconStatusRecords = OracleDAL.GetUnmatchedTBLTrustReconStatusRecords(processingDate);
            
            List<TBLTrustReconStatus> ListTrustReconStatus = TrustReconStatusRecords.ToList();
            Console.WriteLine("List count is " + ListTrustReconStatus.Count);
        }
        
        
        
        
        // Test importing of CSV files
        public static void MainTest01(string[] args, DateTime importDate)
        {
            // update ImportedDate in place #1
            //List<TBLTrustStripeSrc> ListStripe = CSVParser.TBLTrustStripeSrcCsvParser(@"StripeSample_1.csv").Select(c => {c.ImportedDate = importDate; return c;}).ToList();
            //List<TBLTrustWalletSrc> ListWallet = CSVParser.TBLTrustWalletSrcCsvParser(@"WalletSample_1.csv").Select(c => {c.ImportedDate = importDate; return c;}).ToList();
            
            List<TBLTrustStripeSrc> ListStripe = CSVParser.TBLTrustStripeSrcCsvParser(@"StripeSample_1.csv").ToList();
            List<TBLTrustWalletSrc> ListWallet = CSVParser.TBLTrustWalletSrcCsvParser(@"WalletSample_1.csv").ToList();
            
            ListStripe.ForEach(x => {x.ImportedDate = importDate;});
            ListWallet.ForEach(x => {x.ImportedDate = importDate;});
            
            Console.WriteLine("TBLTrustStripeSrc");
            //foreach(TBLTrustStripeSrc n in ListStripe)
            for(int i=0; i<ListStripe.Count; i++)
            {
                TBLTrustStripeSrc n = ListStripe[i];
                
                // Id, Description, CreatedUTC, Amount, Captured, Status, CardID, PackageID, OutletID, MGGTransactionID
                Console.WriteLine(n.Id + ", " + n.Description + ", " + n.CreatedUTC + ", " + n.Amount + ", " + n.Captured + ", " +
                                  n.Status + ", " + n.CardID + ", " + n.PackageID + ", " + n.OutletID + ", " + n.MGGTransactionID + ", " +
                                  n.ImportedDate
                                 );
                //n.ImportedDate = importDate;
            }
            
            Console.WriteLine("\n\n");
            Console.WriteLine("TBLTrustWalletSrc");
            //foreach(TBLTrustWalletSrc n in ListWallet)
            for(int i=0; i<ListWallet.Count; i++)
            {
                TBLTrustWalletSrc n = ListWallet[i];
                
                // ThirdPartyRef, Amount, ThirdPartyAppUid, TxnRef, TxnType, TxnDateTime, Status, DebitCredit, StripeTXNID, PackageID, OutletID, MGGTransactionID
                
                Console.WriteLine(n.merchantId + ", " + n.mgroup + ", " + n.brand + ", " + n.outlet + ", " + n.txnDecription + ", " +
                                  n.packageId + ", " + n.stripeTxnId + ", " +
                                  n.ImportedDate
                                 );
                //n.ImportedDate = importDate;
            }
            
            
            
            
            Console.WriteLine("Imported = " + importDate);
            Console.WriteLine("ImportedDate = " + ListStripe.FirstOrDefault().ImportedDate);
            
            // This will compute the CreatedLocal date/time before importing to DB..
            OracleDAL.ImportTBLTrustStripeSrc(ListStripe.ToList());
            OracleDAL.ImportTBLTrustWalletSrc(ListWallet.ToList());
        }
    }
}

