﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace TrustRecon
{
    public static class ReconMgr
    {
        // inputProcessDate is also the importedDate to query for..
        public static void RunReconOnceByDate(DateTime inputProcessDate, bool first=false)
        {
            string strProcessingDate = inputProcessDate.ToString(Constants.ProcessingDateFormat);
            SummaryItem item;
            
            Logger.DailyLog("Info : Recon for - " + inputProcessDate);
            
            // Read from DB TBLTrustReconStatus those UNMATCHED_TYPE != MATCHED into a List of TBLTrustReconStatus objects (ListTrustReconStatus).
            // Inital run will be empty since TBLTrustReconStatus table is unpopulated..
            // (ie, ListTrustReconStatus.Count is 0)..
            IEnumerable<TBLTrustReconStatus> records = OracleDAL.GetUnmatchedTBLTrustReconStatusRecords(strProcessingDate);
            List<TBLTrustReconStatus> ListTrustReconStatus = records.ToList();
            
            Console.WriteLine("Unmatched from TBLTrustReconStatus = " + records.Count());
            
            List<TBLTrustStripeSrc> ListStripe = DoStripeMatchingWithTBLTrustReconStatus(ListTrustReconStatus, inputProcessDate, first);
            
            List<TBLTrustWalletSrc> ListWallet = DoWalletMatchingWithTBLTrustReconStatus(ListTrustReconStatus, inputProcessDate, first);
            
            List<TBLTrustReconStatus> ListTrustReconStatusTemp = DoStripeWalletMatching(ListStripe, ListWallet, inputProcessDate);
            
            /*
            foreach(TBLTrustReconStatus k in ListTrustReconStatusTemp)
            {
                Console.WriteLine(k.stripeTxnId + "," + k.WalletMerchantRef + "," + k.UNMATCHED_TYPE);
            }*/
            
            
            // 4)
            // Block insert ListTrustReconStatus_Temp list to DB TBLTrustReconStatus.
            OracleDAL.BlockInsertToTBLTrustReconStatusTable(ListTrustReconStatusTemp);
            
            //
            // 5)
            // Check DB TBLTrustReconStatus for duplicates?
            OracleDAL.CheckForRepeatedRecords();
            OracleDAL.RemoveRepeatedRecords(strProcessingDate);
            
            // 6)
            // Generate matched, unmatched and summary reports, and recon history records..
            records = OracleDAL.GetTBLTrustReconStatusRecordsForDate(strProcessingDate);
            OutputCSV.GenerateCSV(records.ToList(), strProcessingDate);
            item = SummaryMgr.GenerateSummaryReports(records.ToList(), strProcessingDate);
            
            /*
            Console.WriteLine("Summary for " + strProcessingDate);
            Console.WriteLine("NumberOfStripeRecords = " + item.NumberOfStripeRecords);
            Console.WriteLine("NumberOfWalletRecords = " + item.NumberOfWalletRecords);
            Console.WriteLine("StripeUnmatchedCount = " + item.StripeUnmatchedCount);
            Console.WriteLine("StripeUnmatchedAmount = " + item.StripeUnmatchedAmount);
            
            Console.WriteLine("WalletUnmatchedCount = " + item.WalletUnmatchedCount);
            Console.WriteLine("WalletUnmatchedAmount = " + item.WalletUnmatchedAmount);
            Console.WriteLine("NumberOfMatched = " + item.NumberOfMatched);
            Console.WriteLine("MatchedAmount = " + item.MatchedAmount);
            Console.WriteLine("CumulativeAnoCCount = " + item.CumulativeAnoCCount);
            Console.WriteLine("CumulativeAnoCAmount = " + item.CumulativeAnoCAmount);
            Console.WriteLine("CumulativeCnoACount = " + item.CumulativeCnoACount);
            Console.WriteLine("CumulativeCnoAAmount = " + item.CumulativeCnoAAmount);
            Console.WriteLine("------------------");
            */
            
            // 7)
            // Loop again for next processing day.
            
        }
        
        
        /// <summary>
        /// 1A)
        /// Read from DB TBLTrustStripeSrc (A) those records with imported date between processing start-date and end-date as
        /// TBLTrustStripeSrc objects.
        /// Perform matching of TBLTrustStripeSrc List (A-side) with ListTrustReconStatus list (C-side),
        /// if match found, (ALSO check that the TBLTrustReconStatus object's UNMATCHED_TYPE != MATCHED, if it is => duplicate..)
        /// then update ListTrustReconStatus record with UNMATCHED_TYPE = MATCHED, and A-side info.
        /// Update DB TBLTrustReconStatus record with new status and info.
        /// Delete A-side record from TBLTrustStripeSrc List.
        /// </summary>
        /// <param name="reconList">List of unmatched TBLTrustReconStatus from DB</param>
        /// <param name="inputProcessDate"></param>
        /// <returns>Unmatched List<TBLTrustStripeSrc> with "A-no-C".</returns>
        public static List<TBLTrustStripeSrc> DoStripeMatchingWithTBLTrustReconStatus(List<TBLTrustReconStatus> reconList, DateTime inputProcessDate, bool first)
        {
            IEnumerable<TBLTrustStripeSrc> matchedRecords;
            string processingDate = inputProcessDate.ToString(Constants.ProcessingDateFormat);
            IEnumerable<TBLTrustStripeSrc> stripeObjs = OracleDAL.GetTBLTrustStripeSrcRecords(Globals.ProcessStartDateString,
                                                                                              Globals.ProcessEndDateString, processingDate, first);
            List<TBLTrustStripeSrc> ListStripe = stripeObjs.ToList();
            
            if (reconList.Count == 0)
                return ListStripe;
            
            foreach(TBLTrustReconStatus n in reconList)
            {
                if (n.UNMATCHED_TYPE == "A-no-C" || n.UNMATCHED_TYPE == "MATCHED") // no need to check A-no-C and MATCHED records..
                    continue;
                
                matchedRecords = ListStripe.Where(x => x.Id == n.stripeTxnId); // match A's Stripe Id with C's StripeTXNID
                if (matchedRecords.IsAny())
                {
                    // Match found
                    TBLTrustStripeSrc aObj = matchedRecords.FirstOrDefault();
                    
                    n.OutletID = aObj.OutletID;
                    n.MGGTransactionID = aObj.MGGTransactionID;
                    
                    // Update n with aObj's Stripe info..
                    n.StripeCreatedUTC = aObj.CreatedUTC;
                    n.StripeCreatedLocal = aObj.CreatedLocal;
                    n.StripeAmount = aObj.Amount;
                    n.StripeRefunded = aObj.AmountRefunded;
                    n.StripeFee = aObj.Fee;
                    n.StripeCaptured = aObj.Captured;
                    n.StripeStatus = aObj.Status;
                    n.StripeImportedDate = aObj.ImportedDate;
                    
                    n.MATCHED_ENTRY_DATE = inputProcessDate;
                    n.LAST_MODIFIED_DATE = DateTime.Now; //inputProcessDate;
                    n.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                    n.UNMATCHED_TYPE = "MATCHED";
                    
                    // Update stripe info to DB TBLTrustReconStatus table
                    Console.WriteLine("Updating: A-no-C to Matched - " + n.stripeTxnId);
                    OracleDAL.UpdateTBLTrustReconStatusRecords(n, true);
                    
                    // remove from ListStripe.
                    ListStripe.Remove(aObj);
                }
            }
            
            return ListStripe;
        }
        
        
        
        /// <summary>
        /// 1B)
        /// Read from DB TBLTrustWalletSrc (C) those records with imported date between processing start-date and end-date
        /// as TBLTrustWalletSrc objects.
        /// Perform matching of TBLTrustWalletSrc List (C-side) with ListTrustReconStatus list (A-side),
        /// if match found, (ALSO check that the TBLTrustReconStatus object's UNMATCHED_TYPE != MATCHED, if it is => duplicate..)
        /// then update ListTrustReconStatus record with UNMATCHED_TYPE = MATCHED, and C-side info.
        /// Update DB TBLTrustReconStatus record with new status and info.
        /// Delete C-side record from TBLTrustWalletSrc List.
        /// </summary>
        /// <param name="reconList">List of unmatched TBLTrustReconStatus from DB</param>
        /// <param name="inputProcessDate"></param>
        /// <returns>Unmatched List<TBLTrustWalletSrc> with "C-no-A".</returns>
        public static List<TBLTrustWalletSrc> DoWalletMatchingWithTBLTrustReconStatus(List<TBLTrustReconStatus> reconList, DateTime inputProcessDate, bool first)
        {
            IEnumerable<TBLTrustWalletSrc> matchedRecords;
            string processingDate = inputProcessDate.ToString(Constants.ProcessingDateFormat);
            IEnumerable<TBLTrustWalletSrc> walletObjs = OracleDAL.GetTBLTrustWalletSrcRecords(Globals.ProcessStartDateString,
                                                                                              Globals.ProcessEndDateString, processingDate, first);
            List<TBLTrustWalletSrc> ListWallet = walletObjs.ToList();
            
            if (reconList.Count == 0)
                return ListWallet;
            
            foreach(TBLTrustReconStatus n in reconList)
            {
                // no need to check C-no-A and MATCHED records.. By right there should not be any "MATCHED"
                // since the sql query specify UNMATCHED_TYPE != MATCHED..
                if (n.UNMATCHED_TYPE == "C-no-A" || n.UNMATCHED_TYPE == "MATCHED")
                    continue;
                
                matchedRecords = ListWallet.Where(x => x.stripeTxnId == n.stripeTxnId); // match C's Stripe Id with A's StripeTXNID
                if (matchedRecords.IsAny())
                {
                    // Match found
                    TBLTrustWalletSrc cObj = matchedRecords.FirstOrDefault();
                    
                    // Update n with cObj's Wallet info..
                    n.WalletId = cObj.walletId;
                    n.WalletDebitAccount = cObj.debitAccount;
                    n.WalletCreditAccount = cObj.creditAccount;
                    n.WalletMerchantId = cObj.merchantId;
                    n.WalletTerminalId = cObj.terminalId;
                    n.WalletMerchantRef = cObj.merchantRef;
                    n.WalletThirdPartyRef = cObj.thirdPartyRef;
                    n.WalletTxTimestamp = cObj.txTimestamp;
                    n.WalletAmountIsFormatted =  cObj.amountIsFormatted;
                    n.WalletAmount = cObj.amount;
                    n.WalletCreditFeeAmount = cObj.creditFeeAmount;
                    n.WalletCreditFeeCode = cObj.creditFeeCode;
                    n.WalletDebitFeeAmount = cObj.debitFeeAmount;
                    n.WalletDebitFeeCode = cObj.debitFeeCode;
                    n.WalletSof = cObj.sof;
                    n.WalletSofRef = cObj.sofRef;
                    n.WalletChannel = cObj.channel;
                    n.WalletShortDescription = cObj.shortDescription;
                    n.WalletAcqId = cObj.acqId;
                    n.WalletGroup = cObj.mgroup;
                    n.WalletBrand = cObj.brand;
                    n.WalletOutlet = cObj.outlet;
                    n.WalletTxnDecription = cObj.txnDecription;
                    n.PackageID = cObj.packageId;
                    n.WalletImportedDate = cObj.ImportedDate;
                    
                    
                    n.MATCHED_ENTRY_DATE = inputProcessDate;
                    n.LAST_MODIFIED_DATE = DateTime.Now;  // inputProcessDate;
                    n.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                    n.UNMATCHED_TYPE = "MATCHED";
                    
                    // Update wallet info to DB TBLTrustReconStatus table
                    Console.WriteLine("Updating: C-no-A to Matched - " + n.stripeTxnId);
                    OracleDAL.UpdateTBLTrustReconStatusRecords(n, false);
                    
                    // remove from ListStripe.
                    ListWallet.Remove(cObj);
                }
            }
            
            return ListWallet;
        }
        
        
        
        /// <summary>
        /// 2)
        /// At this stage, those TBLTrustStripeSrc List (A-side records) remaining and TBLTrustWalletSrc List (C-side records) remaining will
        /// be matched against each other.
        /// - Create a new TBLTrustReconStatus List (ListTrustReconStatus_Temp)
        /// ie, foreach(a in A-side)
        ///     - Create new TBLTrustReconStatus object with info from A-side and UNMATCHED_TYPE = A-no-C.
        ///     - do matching with C-side
        ///     - IF match, update object with C-side info and UNMATCHED_TYPE = MATCHED.
        ///         Remove C-side record.
        ///         Add the new MATCHED TBLTrustReconStatus object to ListTrustReconStatus_Temp.
        ///     - ELSE
        ///         Add new A-no-C TBLTrustReconStatus object to ListTrustReconStatus_Temp.
        /// 3)
        /// Now, whatever records remaining in C-side are unmatched, so
        /// - foreach(c in C-side)
        /// - Create new TBLTrustReconStatus object with info from C-side and UNMATCHED_TYPE = C-no-A.
        ///   - Add to ListTrustReconStatus_Temp list.
        /// </summary>
        /// <param name="stripeList"></param>
        /// <param name="walletList"></param>
        /// <param name="inputProcessDate"></param>
        /// <returns></returns>
        public static List<TBLTrustReconStatus> DoStripeWalletMatching(List<TBLTrustStripeSrc> stripeList, List<TBLTrustWalletSrc> walletList, DateTime inputProcessDate)
        {
            IEnumerable<TBLTrustWalletSrc> matchedWallet;
            string processingDate = inputProcessDate.ToString(Constants.ProcessingDateFormat);
            List<TBLTrustReconStatus> ListTrustReconStatus_Temp = new List<TBLTrustReconStatus>();
            
            foreach(TBLTrustStripeSrc a in stripeList)
            {
                // Instantiate new TBLTrustReconStatus object and copy stripe object's info to it.
                TBLTrustReconStatus recon = new TBLTrustReconStatus();
                
                // Wallet/Stripe meta data
                recon.stripeTxnId = a.Id;
                recon.PackageID = a.PackageID;
                recon.OutletID = a.OutletID;
                recon.MGGTransactionID = a.MGGTransactionID;
                
                // Stripe info
                recon.StripeCreatedUTC = a.CreatedUTC;
                recon.StripeCreatedLocal = a.CreatedLocal;
                recon.StripeAmount = a.Amount;
                recon.StripeRefunded = a.AmountRefunded;
                recon.StripeFee = a.Fee;
                recon.StripeCaptured = a.Captured;
                recon.StripeStatus = a.Status;
                recon.StripeImportedDate = a.ImportedDate;
                
                // Recon
                recon.UNMATCHED_TYPE = "A-no-C";
                recon.MATCHED_ENTRY_DATE = DateTime.MinValue;
                recon.LAST_MODIFIED_DATE = DateTime.Now;  // inputProcessDate;
                recon.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                
                matchedWallet = walletList.Where(x => x.stripeTxnId == recon.stripeTxnId);
                if (matchedWallet.IsAny())
                {
                    // Match found
                    TBLTrustWalletSrc cObj = matchedWallet.FirstOrDefault();
                    // Update with Wallet info..
                    recon.WalletId = cObj.walletId;
                    recon.WalletDebitAccount = cObj.debitAccount;
                    recon.WalletCreditAccount = cObj.creditAccount;
                    recon.WalletMerchantId = cObj.merchantId;
                    recon.WalletTerminalId = cObj.terminalId;
                    recon.WalletMerchantRef = cObj.merchantRef;
                    recon.WalletThirdPartyRef = cObj.thirdPartyRef;
                    recon.WalletTxTimestamp = cObj.txTimestamp;
                    recon.WalletAmountIsFormatted =  cObj.amountIsFormatted;
                    recon.WalletAmount = cObj.amount;
                    recon.WalletCreditFeeAmount = cObj.creditFeeAmount;
                    recon.WalletCreditFeeCode = cObj.creditFeeCode;
                    recon.WalletDebitFeeAmount = cObj.debitFeeAmount;
                    recon.WalletDebitFeeCode = cObj.debitFeeCode;
                    recon.WalletSof = cObj.sof;
                    recon.WalletSofRef = cObj.sofRef;
                    recon.WalletChannel = cObj.channel;
                    recon.WalletShortDescription = cObj.shortDescription;
                    recon.WalletAcqId = cObj.acqId;
                    recon.WalletGroup = cObj.mgroup;
                    recon.WalletBrand = cObj.brand;
                    recon.WalletOutlet = cObj.outlet;
                    recon.WalletTxnDecription = cObj.txnDecription;
                    recon.PackageID = cObj.packageId;
                    recon.WalletImportedDate = cObj.ImportedDate;
                    
                    recon.UNMATCHED_TYPE = "MATCHED";
                    recon.MATCHED_ENTRY_DATE = inputProcessDate;
                    recon.LAST_MODIFIED_DATE = DateTime.Now;  // inputProcessDate;
                    recon.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                    
                    walletList.Remove(cObj);
                }
                
                ListTrustReconStatus_Temp.Add(recon);
            }
            
            // Any remaining wallet objects in walletList are unmatched..
            foreach(TBLTrustWalletSrc w in walletList)
            {
                // Instantiate new TBLTrustReconStatus object and copy Wallet object's info to it.
                TBLTrustReconStatus recon = new TBLTrustReconStatus();
                
                // Wallet/Stripe meta data
                recon.stripeTxnId = w.stripeTxnId;
                recon.OutletID = ""; //w.OutletID; NOT SURE WHETHER WALLET will have this info?
                recon.MGGTransactionID = ""; //w.MGGTransactionID;
                
                // Stripe info not present
                //                recon.StripeCreatedUTC = a.CreatedUTC;
                //                recon.StripeAmount = a.Amount;
                //                recon.StripeCaptured = a.Captured;
                //                recon.StripeStatus = a.Status;
                
                // Update with Wallet info..
                recon.WalletId = w.walletId;
                recon.WalletDebitAccount = w.debitAccount;
                recon.WalletCreditAccount = w.creditAccount;
                recon.WalletMerchantId = w.merchantId;
                recon.WalletTerminalId = w.terminalId;
                recon.WalletMerchantRef = w.merchantRef;
                recon.WalletThirdPartyRef = w.thirdPartyRef;
                recon.WalletTxTimestamp = w.txTimestamp;
                recon.WalletAmountIsFormatted =  w.amountIsFormatted;
                recon.WalletAmount = w.amount;
                recon.WalletCreditFeeAmount = w.creditFeeAmount;
                recon.WalletCreditFeeCode = w.creditFeeCode;
                recon.WalletDebitFeeAmount = w.debitFeeAmount;
                recon.WalletDebitFeeCode = w.debitFeeCode;
                recon.WalletSof = w.sof;
                recon.WalletSofRef = w.sofRef;
                recon.WalletChannel = w.channel;
                recon.WalletShortDescription = w.shortDescription;
                recon.WalletAcqId = w.acqId;
                recon.WalletGroup = w.mgroup;
                recon.WalletBrand = w.brand;
                recon.WalletOutlet = w.outlet;
                recon.WalletTxnDecription = w.txnDecription;
                recon.PackageID = w.packageId;
                recon.WalletImportedDate = w.ImportedDate;
                
                // Recon
                recon.UNMATCHED_TYPE = "C-no-A";
                recon.MATCHED_ENTRY_DATE = DateTime.MinValue;
                recon.LAST_MODIFIED_DATE = DateTime.Now; // inputProcessDate;
                recon.LAST_MODIFIED_USER = Constants.CONST_RECON_USER;
                
                ListTrustReconStatus_Temp.Add(recon);
            }
            
            return ListTrustReconStatus_Temp;
        }
        
        
    } // class
}
