﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace TrustRecon
{
    // Handles importing of CSV files to DB tables
    public static class ImportMgr
    {
        
    }
}

