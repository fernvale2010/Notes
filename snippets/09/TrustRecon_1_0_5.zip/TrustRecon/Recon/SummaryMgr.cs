﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace TrustRecon
{
    // 
    public static class SummaryMgr
    {
        // strDate is in Constants.ProcessingDateFormat format..
        public static SummaryItem GenerateSummaryReports(List<TBLTrustReconStatus> list, string strDate)
        {
            SummaryItem item = new SummaryItem();
            DateTime date = DateTime.ParseExact(strDate, Constants.ProcessingDateFormat,  CultureInfo.InvariantCulture);
            
            List<TBLTrustReconStatus> filtered = list.Where(x => (x.UNMATCHED_TYPE == "MATCHED") &&
                                                            //(x.StripeCreatedLocal.Date == date.Date)).ToList();
                                                            (x.MATCHED_ENTRY_DATE.Value.Date == date.Date)).OrderByDescending(x => x.StripeCreatedLocal.Date).ToList();
            
            // In the Excel summary report:-
            // Matched Today => MATCHED_ENTRY_DATE == StripeCreatedLocal or WalletTxnDateTime == current processing date
            // Matched some other days => MATCHED_ENTRY_DATE == current processing date, but StripeCreatedLocal/WalletTxnDateTime < current processing date.
            // Need to group by StripeCreatedLocal/WalletTxnDateTime..
            
            
            // Recon date
            item.ReconRunDate = date;
            // Matched Today
            item.NumberOfMatched = filtered.Count();
            // Matched amount Today
            item.MatchedAmount = filtered.Sum(x => x.WalletAmount);
            // AnoC Today
            item.StripeUnmatchedCount = list.Count(x => (x.UNMATCHED_TYPE == "A-no-C") &&
                                                   (x.StripeCreatedLocal.Date == date.Date));
            // AnoC amount Today
            item.StripeUnmatchedAmount = list.Sum(x => ((x.UNMATCHED_TYPE == "A-no-C") &&
                                                        (x.StripeCreatedLocal.Date == date.Date)) ? x.StripeAmount : 0);
            
            filtered = list.Where(x => (x.UNMATCHED_TYPE == "C-no-A") &&
                                  (x.WalletTxTimestamp.Date == date.Date)).ToList();;
            // CnoA Today
            item.WalletUnmatchedCount = filtered.Count();
            // CnoA amount Today
            item.WalletUnmatchedAmount = filtered.Sum(x => x.WalletAmount);
            
            // matched + AnoC Today
            item.NumberOfStripeRecords = item.NumberOfMatched + item.StripeUnmatchedCount;
            item.NumberOfWalletRecords = item.NumberOfMatched + item.WalletUnmatchedCount;
            
            // Cumulated AnoC
            item.CumulativeAnoCCount = list.Count(x => (x.UNMATCHED_TYPE == "A-no-C")) - item.StripeUnmatchedCount;
            // Cumulated AnoC amount
            item.CumulativeAnoCAmount = list.Sum(x => ((x.UNMATCHED_TYPE == "A-no-C") ? x.StripeAmount : 0)) - item.StripeUnmatchedAmount;
            // Cumulated CnoA
            item.CumulativeCnoACount = list.Count(x => (x.UNMATCHED_TYPE == "C-no-A")) - item.WalletUnmatchedCount;
            // Cumulated CnoA amount
            item.CumulativeCnoAAmount = list.Sum(x => ((x.UNMATCHED_TYPE == "C-no-A") ? x.WalletAmount : 0)) - item.WalletUnmatchedAmount;
            
            return item;
        }
        
        
    }
}

