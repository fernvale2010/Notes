﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;
using Encryption;

namespace TrustRecon
{
    /// <summary>
    /// Class contains the constants used in the service.
    /// </summary>
    public static class Constants
    {
        public static string AppVersion = "1.0.0";
        
        public static string ReconStartDate = ConfigurationManager.AppSettings["StartDateKey"];
        public static string ReconEndDate = ConfigurationManager.AppSettings["EndDateKey"];
        
        public static string AppPath = AppDomain.CurrentDomain.BaseDirectory;
        
        //public static string ReportPath = AppDomain.CurrentDomain.BaseDirectory + ConfigurationManager.AppSettings["ReportsPath"];
        public static string ReportPath =  AppDomain.CurrentDomain.BaseDirectory + "Reports"; //        System.Reflection.Assembly.GetEntryAssembly().Location
        
        public static string UnmatchedReportPath = string.Concat(ReportPath, "\\{0}\\UnmatchedReport_{1}.csv");

        public static string MatchedReportPath = string.Concat(ReportPath, "\\{0}\\MatchedReport_{1}.csv");

        public static string SummaryReportPath = string.Concat(ReportPath, "\\{0}\\SummaryReport_{1}.csv");
        
        public const string CONST_RECON_USER = "TrustReconProcess";
        
        public const string ProcessingDateFormat = "dd-MM-yy";
        public const string FileNameDateFormat = "dd_MMM_yyyy";
        
        public const int LocalTimeOffset = 8; // UTC + 8 hours 
        
        
        public static string ConnectionString =
            //"Data Source=FIRSUATP;User ID=EZAC_RECON2;password=password123;";
                    DataEncryption.DecryptData(ConfigurationManager.ConnectionStrings["dbConnection"].ConnectionString, ReadKey(AppDomain.CurrentDomain.BaseDirectory + "\\Privatekey.xml"));

        
        // DB Table names
        public static readonly string TBLTrustWalletSrcName = "TBLTrustWalletSrc";
        public static readonly string TBLTrustStripeSrcName = "TBLTrustStripeSrc";
        public static readonly string TBLTrustReconStatusName = "TBLTrustReconStatus";
        
        public static readonly string TBLTrustReconHistoryName = "TBLTrustReconHistory";
        //public static readonly string TBLTrustLastReconRunName = "TBLTrustLastReconRun"; // Optional.. may not need
        
        
        public static string SummaryLegendString = string.Format("Legend -> {0}" +
                                                                 "A-no-B meaning : transaction found in Stripe report but no corresponding matching transaction in OFTS {0}" +
                                                                 "C-no-B meaning : transaction found in FIRS but no corresponding matching transaction in OFTS report {0}" +
                                                                 "B-no-AC meaning : transaction found in OFTS but no corresponding matching transaction in FIRS and Stripe reports {0}" +
                                                                 "AB-no-C meaning : transaction found in Stripe and OFTS but no corresponding matching transaction in FIRS reports {0}" +
                                                                 "BC-no-A meaning : transaction found in OFTS and FIRS but no corresponding matching transaction in Stripe reports {0}" +
                                                                 "Endpoint meaning as follows -> A : Stripe report; C : FIRS; B : OFTS report",
                                                                 Environment.NewLine);

        public const string StripeKey = "Stripe";
        
        public const string strSemiColon = ";";
        public const string strAnd = " AND ";
        
        public const string AcqId = "AC231";
        
        // For import use
        public static string CSVInputFolder = ConfigurationManager.AppSettings["CSVInputFolder"];
        public static string CSVArchiveFolder = ConfigurationManager.AppSettings["CSVArchiveFolder"];
        
        private static string ReadKey(string fileName)
        {
            StreamReader stream = new StreamReader(fileName);
            string key = stream.ReadToEnd();
            stream.Close();
            return key;
        }        
        
        #if (true)
        // set target platform for .NET Framework 4.5
        public static int __LINE__([System.Runtime.CompilerServices.CallerLineNumber] int lineNumber = 0)
        {
            return lineNumber;
        }
        public static string __FILE__([System.Runtime.CompilerServices.CallerFilePath] string fileName = "")
        {
            return Path.GetFileName(fileName);
        }
        #endif
    }

}
