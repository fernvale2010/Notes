﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrustRecon
{
    // Wallet Input source, all amount in cents
    public class TBLTrustWalletSrc
    {
        public string walletId { get; set; }
        public string debitAccount { get; set; }
        public string creditAccount { get; set; }
        public string merchantId { get; set; }
        public string terminalId { get; set; }
        public string merchantRef { get; set; }
        public string thirdPartyRef { get; set; }
        public DateTime txTimestamp { get; set; }
        public string amountIsFormatted { get; set; }
        public Int64 amount { get; set; }
        public Int64 creditFeeAmount { get; set; }
        public string creditFeeCode { get; set; }
        public Int64 debitFeeAmount { get; set; }
        public string debitFeeCode { get; set; }
        public string sof { get; set; }
        public string sofRef { get; set; }
        public string channel { get; set; }
        public string shortDescription { get; set; }
        public string acqId { get; set; }
        public string mgroup { get; set; } // merchant group
        public string brand { get; set; }
        public string outlet { get; set; }
        public string txnDecription { get; set; }
        public string packageId { get; set; }
        public string stripeTxnId { get; set; }
        public DateTime ImportedDate { get; set; } 
    }
}

/*
        debitAccount
        creditAccount
        merchantId
        terminalId
        merchantRef
        thirdPartyRef
        txTimestamp
        amountIsFormatted
        amount
        creditFeeAmount
        creditFeeCode
        debitFeeAmount
        debitFeeCode
        sof
        sofRef
        channel
        shortDescription
        acqId
        mgroup
        brand
        outlet
        txnDecription
        packageId
        stripeTxnId
        ImportedDate
*/        