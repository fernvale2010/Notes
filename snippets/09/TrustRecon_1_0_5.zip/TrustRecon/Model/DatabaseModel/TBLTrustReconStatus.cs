﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrustRecon
{
    // Wallet-Stripe Recon results (MATCHED, A-no-C, C-no-A)
    // A => Stripe, C => Wallet
    public class TBLTrustReconStatus
    {
        // Wallet/Stripe meta data
        public string stripeTxnId { get; set; }
        public string PackageID { get; set; }
        public string OutletID { get; set; }
        public string MGGTransactionID { get; set; }
        
        // Stripe info
        public DateTime StripeCreatedUTC { get; set; }
        public DateTime StripeCreatedLocal { get; set; }
        public double StripeAmount { get; set; }
        public double StripeRefunded { get; set; }
        public double StripeFee { get; set; }
        public string StripeCaptured { get; set; }
        public string StripeStatus { get; set; }
        public DateTime StripeImportedDate { get; set; }

        
        // Wallet
        public string WalletId { get; set; }
        public string WalletDebitAccount { get; set; }
        public string WalletCreditAccount { get; set; }
        public string WalletMerchantId { get; set; }
        public string WalletTerminalId { get; set; }
        public string WalletMerchantRef { get; set; } // WalletTxnRef
        public string WalletThirdPartyRef { get; set; }
        public DateTime WalletTxTimestamp { get; set; } // WalletTxnDateTime
        public string WalletAmountIsFormatted { get; set; }
        public Int64 WalletAmount { get; set; } // In cents
        public Int64 WalletCreditFeeAmount { get; set; } // In cents
        public string WalletCreditFeeCode { get; set; }
        public Int64 WalletDebitFeeAmount { get; set; } // In cents
        public string WalletDebitFeeCode { get; set; }
        public string WalletSof { get; set; }
        public string WalletSofRef { get; set; }
        public string WalletChannel { get; set; }
        public string WalletShortDescription { get; set; }
        public string WalletAcqId { get; set; }
        public string WalletGroup { get; set; }
        public string WalletBrand { get; set; }
        public string WalletOutlet { get; set; }
        public string WalletTxnDecription { get; set; }
        public DateTime WalletImportedDate { get; set; }
        
        // Recon
        public string UNMATCHED_TYPE { get; set; }          // (MATCHED, A-no-C, C-no-A)
        public DateTime? MATCHED_ENTRY_DATE { get; set;}    // Date matched
        public DateTime LAST_MODIFIED_DATE { get; set;}     // recon run date
        public string LAST_MODIFIED_USER { get; set;}       // recon process
    }
}


/*
        // Wallet/Stripe meta data
        stripeTxnId
        PackageID
        OutletID
        MGGTransactionID
        
        // Stripe info
        StripeCreatedUTC
        StripeCreatedLocal
        StripeAmount
        StripeCaptured
        StripeStatus
        StripeImportedDate

        
        // Wallet
        WalletDebitAccount
        WalletCreditAccount
        WalletMerchantId
        WalletTerminalId
        WalletMerchantRef
        WalletThirdPartyRef
        WalletTxTimestamp
        WalletAmountIsFormatted
        WalletAmount
        WalletCreditFeeAmount
        WalletCreditFeeCode
        WalletDebitFeeAmount
        WalletDebitFeeCode
        WalletSof
        WalletSofRef
        WalletChannel
        WalletShortDescription
        WalletAcqId
        WalletGroup
        WalletBrand
        WalletOutlet
        WalletTxnDecription
        WalletImportedDate
        
        // Recon
        UNMATCHED_TYPE
        MATCHED_ENTRY_DATE
        LAST_MODIFIED_DATE
        LAST_MODIFIED_USER
 */









