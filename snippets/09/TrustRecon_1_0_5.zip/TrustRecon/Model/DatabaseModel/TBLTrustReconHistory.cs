﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrustRecon
{
    // Wallet Input source, all amount in cents
    public class TBLTrustReconHistory
    {
        public DateTime ReconRunDate { get; set; }
        public string   Status { get; set; } // "SUCCESS", "ERROR", "LASTRUN" => ReconRunDate is date of previous recon run.
        public string   StatusDescription { get; set; } // String - provide description of run status, or errors encountered.  
    }
}
