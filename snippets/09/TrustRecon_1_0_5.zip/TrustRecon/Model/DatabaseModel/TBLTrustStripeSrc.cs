﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrustRecon
{
    // Stripe Input source
    public class TBLTrustStripeSrc
    {
        public string Id { get; set; }              // stripe ID
        public string Description { get; set; }
        public DateTime CreatedUTC { get; set; }
        public double Amount { get; set; }
        public double AmountRefunded { get; set; }
        public double Fee { get; set; }
        public string Captured { get; set; }
        public string Status { get; set; }
        public string CardID { get; set; }
        
        // meta data from wallet
        public string PackageID { get; set; }
        public string OutletID { get; set; }
        public string MGGTransactionID { get; set; }
        
        public DateTime CreatedLocal { get; set; }  // Local time for CreatedUTC.. maybe not needed.
        public DateTime ImportedDate { get; set; }  // date record is imported to DB
    }
}
