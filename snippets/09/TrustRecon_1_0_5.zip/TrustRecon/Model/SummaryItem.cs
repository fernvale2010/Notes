﻿using System;

namespace TrustRecon
{
    // All statistics are per ReconRunDate
    public class SummaryItem
    {
        public DateTime ReconRunDate { get; set; }
        
        public Int32 NumberOfStripeRecords { get; set; } // matched + AnoC Today
        public Int32 NumberOfWalletRecords { get; set; } // matched + CnoA Today
        public Int32 StripeUnmatchedCount { get; set; }  // AnoC Today
        public double StripeUnmatchedAmount { get; set; }// AnoC amount Today
        public Int32 WalletUnmatchedCount { get; set; }  // CnoA Today
        public double WalletUnmatchedAmount { get; set; }// CnoA amount Today
        public Int32 NumberOfMatched { get; set; }       // Matched Today
        public double MatchedAmount { get; set; }        // Matched amount Today
        
        public Int32 CumulativeAnoCCount { get; set; }   // Cumulated AnoC
        public double CumulativeAnoCAmount { get; set; } // Cumulated AnoC amount
        public Int32 CumulativeCnoACount { get; set; }   // Cumulated CnoA
        public double CumulativeCnoAAmount { get; set; } // Cumulated CnoA amount
    }
}
