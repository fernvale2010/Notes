﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using Microsoft.VisualBasic.FileIO;

// NOTE: Ensure the fields indices followed the columns defined in CSV files..

namespace TrustRecon
{
    // https://coding.abel.nu/2012/06/built-in-net-csv-parser/
    public class CSVParser
    {
        // TBLTrustStripeSrc - For STRIPE CSV file
        public static IEnumerable<TBLTrustStripeSrc> TBLTrustStripeSrcCsvParser(string path, bool skipheader=true)
        {
            // TextFieldParser is in the Microsoft.VisualBasic.FileIO namespace.
            using (TextFieldParser parser = new TextFieldParser(path))
            {
                parser.CommentTokens = new string[] { "#" };
                parser.SetDelimiters(new string[] { "," });
                parser.HasFieldsEnclosedInQuotes = true;
                
                // Skip over header line.
                if (skipheader)
                {
                    parser.ReadLine();
                }
                
                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    //Int64 locInt64;
                    //int locInt;
                    double locDouble;
                    DateTime locDateTime;
                    
                    TBLTrustStripeSrc obj = new TBLTrustStripeSrc();
                    
                    // fields[x] needs to follow the CSV file..
                    obj.Id = fields[0];
                    obj.Description = fields[1];
                    DateTime.TryParseExact(fields[2], @"yyyy-MM-dd HH:mm:ss",  // 2017-12-12 16:42:24
                                           new CultureInfo(""), // CultureInfo.InvariantCulture
                                           DateTimeStyles.None,
                                           out locDateTime);  obj.CreatedUTC = locDateTime;
                    // by default C# assume datatime is UTC, so to convert to local time, use: locDateTime.ToLocalTime()..
                    
                    double.TryParse(fields[3], out locDouble); obj.Amount = locDouble;
                    double.TryParse(fields[4], out locDouble); obj.AmountRefunded = locDouble;
                    double.TryParse(fields[8], out locDouble); obj.Fee = locDouble;

                    obj.Status = fields[12];
                    obj.Captured = fields[17];
                    obj.CardID = fields[18];
                    
                    // wallet meta data
                    obj.PackageID = fields[47];
                    obj.OutletID = fields[48];
                    obj.MGGTransactionID = fields[49];
                    
                    yield return obj;
                }
            }
        }

        
        // TBLTrustWalletSrc - For Wallet CSV file
        public static IEnumerable<TBLTrustWalletSrc> TBLTrustWalletSrcCsvParser(string path, bool skipheader=true)
        {
            // TextFieldParser is in the Microsoft.VisualBasic.FileIO namespace.
            using (TextFieldParser parser = new TextFieldParser(path))
            {
                parser.CommentTokens = new string[] { "#" };
                parser.SetDelimiters(new string[] { "," });
                parser.HasFieldsEnclosedInQuotes = true;
                
                // Skip over header line.
                if (skipheader)
                {
                    parser.ReadLine();
                }
                
                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    Int64 locInt64 = 0;
                    //int locInt;
                    //double locDouble;
                    DateTime locDateTime = DateTime.MinValue;
                    
                    TBLTrustWalletSrc obj = new TBLTrustWalletSrc();
                    
                    // fields[x] needs to follow the CSV file..
                    obj.walletId = fields[0];
                    obj.debitAccount = fields[1];
                    obj.creditAccount = fields[2];
                    obj.merchantId = fields[3];
                    obj.terminalId = fields[4];
                    obj.merchantRef = fields[5];
                    obj.thirdPartyRef = fields[6];
                    DateTime.TryParseExact(fields[7], @"yyyyMMddHHmmss",  // 20171219164224
                                           new CultureInfo(""), // CultureInfo.InvariantCulture
                                           DateTimeStyles.None,
                                           out locDateTime); obj.txTimestamp = locDateTime;
                    obj.amountIsFormatted = fields[8];
                    Int64.TryParse(fields[9], out locInt64); obj.amount = locInt64;
                    Int64.TryParse(fields[10], out locInt64); obj.creditFeeAmount = locInt64;
                    obj.creditFeeCode = fields[11];
                    Int64.TryParse(fields[12], out locInt64); obj.debitFeeAmount = locInt64;
                    obj.debitFeeCode = fields[13];
                    obj.sof = fields[14];
                    obj.sofRef = fields[15];
                    obj.channel = fields[16];
                    obj.shortDescription = fields[17];
                    obj.acqId = fields[18];
                    obj.mgroup = fields[19];
                    obj.brand = fields[20];
                    obj.outlet = fields[21];
                    obj.txnDecription = fields[22];
                    obj.packageId = fields[23];
                    obj.stripeTxnId = fields[24];
                    
                    //Console.WriteLine("mgroup: " + fields[18] + "," + fields[19] + "," + fields[20] + "," + fields[21] + "," + fields[22] + "," + fields[23]);

                    yield return obj;
                }
            }
        }

        
        // Testing use only - For TBLTrustReconStatus CSV file
        public static IEnumerable<TBLTrustReconStatus> TBLTrustReconStatusCsvParser(string path, bool skipheader=true)
        {
            // TextFieldParser is in the Microsoft.VisualBasic.FileIO namespace.
            using (TextFieldParser parser = new TextFieldParser(path))
            {
                parser.CommentTokens = new string[] { "#" };
                parser.SetDelimiters(new string[] { "," });
                parser.HasFieldsEnclosedInQuotes = true;
                
                // Skip over header line.
                if (skipheader)
                {
                    parser.ReadLine();
                }
                
                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    //Int64 locInt64;
                    //int locInt;
                    //double locDouble;
                    DateTime locDateTime;
                    bool res;
                    
                    TBLTrustReconStatus obj = new TBLTrustReconStatus();
                    
                    // fields[x] needs to follow the CSV file..
                    // NOTE: NEED TO SPECIFY DATETIME FORMAT EXACTLY, OTHERWISE WILL BECOME DATETIME.MinValue..
                    // 2017-12-01 01:01:24
                    string[] formats= { "dd/MM/yyyy HH:mm:ss", "yyyy-MM-dd hh:mm:ss" };
                    res = DateTime.TryParseExact(fields[0], formats,  // 12/12/2017 16:42:24
                                                 new CultureInfo(""), // CultureInfo.InvariantCulture
                                                 DateTimeStyles.None,
                                                 out locDateTime);
                    
                    res = DateTime.TryParseExact(fields[13], formats,  // 12/12/2017 16:42:24
                                                 new CultureInfo(""), // CultureInfo.InvariantCulture
                                                 DateTimeStyles.None,
                                                 out locDateTime);
                    if (res == true)
                    {
                        obj.MATCHED_ENTRY_DATE = locDateTime;
                    }
                    else
                    {
                        obj.MATCHED_ENTRY_DATE = null;
                    }
                    
                    
                    yield return obj;
                }
            }
        }
        
        
    }  // class CVSParser
}
