﻿
using System;


namespace TrustRecon
{
    public static class Globals
    {
        public static bool DebugRun { get; set; }
        
        //public static DateTime ProcessingDate { get; set; }
        public static DateTime ProcessStartDate { get; set; }
        public static DateTime ProcessEndDate { get; set; }
        
        public static string ProcessStartDateString { get; set; }
        public static string ProcessEndDateString { get; set; }
        //public static string ProcessingDateString { get; set; }
    }
}
