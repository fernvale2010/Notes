﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using Oracle.DataAccess.Client;
using Dapper;
using System.Text.RegularExpressions;

/*
" AND (PROCESSING_DATE BETWEEN to_date(('{1} 00:00:00'),'dd-MM-yy HH24:mi:SS')" +
" AND to_date(('{1} 23:59:59'),'dd-MM-yy HH24:mi:SS'))",
 */


namespace TrustRecon
{
    public static class OracleDAL
    {
        
        // Read Unmatched records from DB TBLTrustReconStatus.
        // processingDate is string of Constants.ProcessingDateFormat ("dd-MM-yy") format.
        public static IEnumerable<TBLTrustReconStatus> GetUnmatchedTBLTrustReconStatusRecords(string processingDate)
        {
            var sqlQuery = "None";
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();

                    sqlQuery = string.Format("SELECT * FROM {0} WHERE" +
                                             " (UNMATCHED_TYPE != 'MATCHED')",
                                             Constants.TBLTrustReconStatusName);
                    return connection.Query<TBLTrustReconStatus>(sqlQuery);
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + sqlQuery);
                Logger.DailyLog("Error : " + exception);
            }
            return null;
        }
        
        
        // Read all records from DB TBLTrustReconStatus on transaction date.
        // processingDate is string of Constants.ProcessingDateFormat ("dd-MM-yy") format.
        // Use for summary reporting
        public static IEnumerable<TBLTrustReconStatus> GetTBLTrustReconStatusRecordsForDate(string processingDate)
        {
            var sqlQuery = "None";
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();
                    
                    // We want to fetch all unmatched records upto current processing date, and all records matched for this current processing date.
                    // For matched records,
                    // grouping by transaction date, so in excel file, 1 row per transaction date
                    // For unmatched records,
                    // grouping also by transaction date.. Those that falls in current processing date will be lumped in same row as the matched for current processing date.
                    // The rest are the cumulated A-no-C and C-no-A..
                    sqlQuery = string.Format("SELECT * FROM {0} WHERE" +
                                             " (TRUNC(WalletTxTimestamp) <= TRUNC(to_date(('{1} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) OR" +
                                             " (TRUNC(StripeCreatedLocal) <= TRUNC(to_date(('{1} 00:00:00'),'dd-MM-yy HH24:mi:SS'))) OR" +
                                             " (TRUNC(MATCHED_ENTRY_DATE) = TRUNC(to_date(('{1} 00:00:00'),'dd-MM-yy HH24:mi:SS')))"
                                             , Constants.TBLTrustReconStatusName, processingDate);
                    Logger.DailyLog("Info : GetTBLTrustReconStatusRecordsForDate - " + sqlQuery);
                    return connection.Query<TBLTrustReconStatus>(sqlQuery);
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + sqlQuery);
                Logger.DailyLog("Error : " + exception);
            }
            return null;
        }
        
        
        
        // Read Stripe records from DB TBLTrustReconStatus. Get all that are imported "today"..
        // date strings are strings in Constants.ProcessingDateFormat ("dd-MM-yy") format.
        // startDateString should be the date of (Last processed date + 1)
        // endDateString should be date of (Now - 1).
        // currentProcessingDateString is from startDate to endDate..
        public static IEnumerable<TBLTrustStripeSrc> GetTBLTrustStripeSrcRecords(string startDateString,
                                                                                 string endDateString, string currentProcessingDateString, bool first)
        {
            var sqlQuery = "None";
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();
                    
                    // Get all stripe records that are imported from startDate to endDate and with CreatedLocal dates that are <=
                    // current processing date.
                    // This will cover cases where records are imported late.. ie, not processed in previous recon runs because they are not imported yet.
                    sqlQuery = string.Format("SELECT * FROM {0} WHERE" +
                                             " (ImportedDate BETWEEN to_date(('{1} 00:00:00'),'dd-MM-yy HH24:mi:SS')" +
                                             " AND to_date(('{2} 23:59:59'),'dd-MM-yy HH24:mi:SS')) AND" +
                                             " (TRUNC(CreatedLocal) {4}= to_date(('{3} 00:00:00'),'dd-MM-yy HH24:mi:SS'))"
                                             , Constants.TBLTrustStripeSrcName, startDateString, endDateString, currentProcessingDateString, first ? "<" : "");
                    
                    Logger.DailyLog("Info : " + sqlQuery);
                    return connection.Query<TBLTrustStripeSrc>(sqlQuery);
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + sqlQuery);
                Logger.DailyLog("Error : " + exception);
            }
            return null;
        }
        
        
        // Read Wallet records from DB TBLTrustWalletSrc. Get all that are imported "today"..
        // date Strings are strings in Constants.ProcessingDateFormat ("dd-MM-yy") format.
        public static IEnumerable<TBLTrustWalletSrc> GetTBLTrustWalletSrcRecords(string startDateString,
                                                                                 string endDateString, string currentProcessingDateString, bool first)
        {
            var sqlQuery = "None";
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();

                    sqlQuery = string.Format("SELECT * FROM {0} WHERE" +
                                             " (ImportedDate BETWEEN to_date(('{1} 00:00:00'),'dd-MM-yy HH24:mi:SS')" +
                                             " AND to_date(('{2} 23:59:59'),'dd-MM-yy HH24:mi:SS')) AND" +
                                             " (TRUNC(txTimestamp) {4}= to_date(('{3} 00:00:00'),'dd-MM-yy HH24:mi:SS'))"
                                             , Constants.TBLTrustWalletSrcName, startDateString, endDateString, currentProcessingDateString, first ? "<" : "");
                    
                    Logger.DailyLog("Info : " + sqlQuery);
                    return connection.Query<TBLTrustWalletSrc>(sqlQuery);
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + sqlQuery);
                Logger.DailyLog("Error : " + exception);
            }
            return null;
        }
        
        
        /// <summary>
        /// Update to DB TBLTrustReconStatus.
        /// </summary>
        /// <param name="updateRecord">Record to update</param>
        /// <param name="aside">true to update A-side values to DB record</param>
        public static void UpdateTBLTrustReconStatusRecords(TBLTrustReconStatus updateRecord, bool aside)
        {
            OracleTransaction transaction = null;
            var sqlUpdate = "";
            int res = 0;
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    
                    sqlUpdate = string.Format("UPDATE {0} SET ", Constants.TBLTrustReconStatusName);

                    if (aside == true)
                    {
                        // Means Wallet info are there, so update with Stripe info only.
                        
                        // Stripe info, Take note to add single quotes to strings
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "StripeCreatedUTC", updateRecord.StripeCreatedUTC.ToString("dd-MM-yy HH:mm:ss"));
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "StripeCreatedLocal", updateRecord.StripeCreatedLocal.ToString("dd-MM-yy HH:mm:ss"));
                        sqlUpdate += string.Format("StripeAmount = {0}, ", updateRecord.StripeAmount);
                        sqlUpdate += string.Format("StripeRefunded = {0}, ", updateRecord.StripeRefunded);
                        sqlUpdate += string.Format("StripeFee = {0}, ", updateRecord.StripeFee);
                        sqlUpdate += string.Format("StripeCaptured = '{0}', ", updateRecord.StripeCaptured);
                        sqlUpdate += string.Format("StripeStatus = '{0}', ", updateRecord.StripeStatus);
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "StripeImportedDate", updateRecord.StripeImportedDate.ToString("dd-MM-yy HH:mm:ss"));
                        
                        sqlUpdate += string.Format("UNMATCHED_TYPE = '{0}', ", updateRecord.UNMATCHED_TYPE);
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "MATCHED_ENTRY_DATE", updateRecord.MATCHED_ENTRY_DATE.Value.ToString("dd-MM-yy HH:mm:ss"));
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "LAST_MODIFIED_DATE", updateRecord.LAST_MODIFIED_DATE.ToString("dd-MM-yy HH:mm:ss"));
                        sqlUpdate += string.Format("LAST_MODIFIED_USER = '{0}'  ", updateRecord.LAST_MODIFIED_USER);
                        
                        // Both Wallet and Stripe should contain the stripe ID info.
                        sqlUpdate += string.Format("WHERE stripeTxnId = '{0}'", updateRecord.stripeTxnId);
                    }
                    else
                    {
                        // means Stripe info are there, so update with Wallet info only
                        
                        // Wallet : Take note to add single quotes to strings
                        sqlUpdate += string.Format("WalletId = '{0}', ", updateRecord.WalletId);
                        sqlUpdate += string.Format("WalletDebitAccount = '{0}', ", updateRecord.WalletDebitAccount);
                        sqlUpdate += string.Format("WalletCreditAccount = '{0}', ", updateRecord.WalletCreditAccount);
                        sqlUpdate += string.Format("WalletMerchantId = '{0}', ", updateRecord.WalletMerchantId);
                        sqlUpdate += string.Format("WalletTerminalId = '{0}', ", updateRecord.WalletTerminalId);
                        sqlUpdate += string.Format("WalletMerchantRef = '{0}', ", updateRecord.WalletMerchantRef);
                        sqlUpdate += string.Format("WalletThirdPartyRef = '{0}', ", updateRecord.WalletThirdPartyRef);
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "WalletTxTimestamp", updateRecord.WalletTxTimestamp.ToString("dd-MM-yy HH:mm:ss"));
                        sqlUpdate += string.Format("WalletAmountIsFormatted = '{0}', ", updateRecord.WalletAmountIsFormatted);
                        
                        sqlUpdate += string.Format("WalletAmount = {0}, ", updateRecord.WalletAmount);
                        sqlUpdate += string.Format("WalletCreditFeeAmount = {0}, ", updateRecord.WalletCreditFeeAmount);
                        sqlUpdate += string.Format("WalletCreditFeeCode = '{0}', ", updateRecord.WalletCreditFeeCode);
                        sqlUpdate += string.Format("WalletDebitFeeAmount = {0}, ", updateRecord.WalletDebitFeeAmount);
                        sqlUpdate += string.Format("WalletDebitFeeCode = '{0}', ", updateRecord.WalletDebitFeeCode);
                        sqlUpdate += string.Format("WalletSof = '{0}', ", updateRecord.WalletSof);
                        sqlUpdate += string.Format("WalletSofRef = '{0}', ", updateRecord.WalletSofRef);
                        sqlUpdate += string.Format("WalletChannel = '{0}', ", updateRecord.WalletChannel);
                        sqlUpdate += string.Format("WalletShortDescription = '{0}', ", updateRecord.WalletShortDescription);
                        
                        sqlUpdate += string.Format("WalletAcqId = '{0}', ", updateRecord.WalletAcqId);
                        sqlUpdate += string.Format("WalletGroup = '{0}', ", updateRecord.WalletGroup);
                        sqlUpdate += string.Format("WalletBrand = '{0}', ", updateRecord.WalletBrand);
                        sqlUpdate += string.Format("WalletOutlet = '{0}', ", updateRecord.WalletOutlet);
                        sqlUpdate += string.Format("WalletTxnDecription = '{0}', ", updateRecord.WalletTxnDecription);
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "WalletImportedDate", updateRecord.WalletImportedDate.ToString("dd-MM-yy HH:mm:ss"));
                        
                        sqlUpdate += string.Format("UNMATCHED_TYPE = '{0}', ", updateRecord.UNMATCHED_TYPE);
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "MATCHED_ENTRY_DATE", updateRecord.MATCHED_ENTRY_DATE.Value.ToString("dd-MM-yy HH:mm:ss"));
                        sqlUpdate += string.Format("{0}=to_date('{1}','dd-MM-yy HH24:mi:SS'), ",
                                                   "LAST_MODIFIED_DATE", updateRecord.LAST_MODIFIED_DATE.ToString("dd-MM-yy HH:mm:ss"));
                        sqlUpdate += string.Format("LAST_MODIFIED_USER = '{0}' ", updateRecord.LAST_MODIFIED_USER);
                        
                        // Both Wallet and Stripe should contain the stripe ID info.
                        sqlUpdate += string.Format("WHERE stripeTxnId = '{0}'", updateRecord.stripeTxnId);
                    }

                    
                    try
                    {
                        res = connection.Execute(sqlUpdate);
                        transaction.Commit();
                        Logger.DailyLog("Info : Update - count = " + res + ", " + sqlUpdate);
                        Console.WriteLine("UpdateTBLTrustReconStatusRecords: " + res + " records updated");
                    }
                    catch(Exception e)
                    {
                        transaction.Rollback();
                        Logger.DailyLog("Error : ********************* Exception *******************************");
                        Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                        Logger.DailyLog("Error : " + e);
                        Logger.DailyLog("Error : " + sqlUpdate);
                    }

                }
            }
            catch (Exception exception)
            {
                //transaction.Rollback();
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + exception);
            }
        }

        
        // Block insert of TBLTrustReconStatus records to DB TBLTrustReconStatus..
        public static void BlockInsertToTBLTrustReconStatusTable(List<TBLTrustReconStatus> records)
        {
            OracleTransaction transaction = null;
            int result = 0;
            try
            {
                if (records.Count > 0)
                {
                    using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                    {
                        connection.Open();
                        transaction = connection.BeginTransaction();
                        string sqlInsertQuery = string.Format("INSERT INTO {0} ", Constants.TBLTrustReconStatusName);
                        sqlInsertQuery += "(stripeTxnId,PackageID,OutletID,MGGTransactionID," +
                            "StripeCreatedUTC,StripeCreatedLocal,StripeAmount,StripeRefunded,StripeFee,StripeCaptured,StripeStatus,StripeImportedDate," +
                            //"WalletAmount,WalletTxnRef,WalletTxnType,WalletTxnDateTime,WalletStatus,WalletDebitCredit," +
                            "WalletId," +
                            "WalletDebitAccount, WalletCreditAccount, WalletMerchantId, WalletTerminalId, WalletMerchantRef," +
                            "WalletThirdPartyRef, WalletTxTimestamp, WalletAmountIsFormatted, WalletAmount, WalletCreditFeeAmount," +
                            "WalletCreditFeeCode, WalletDebitFeeAmount, WalletDebitFeeCode, WalletSof, WalletSofRef, WalletChannel," +
                            "WalletShortDescription, WalletAcqId, WalletGroup, WalletBrand, WalletOutlet, WalletTxnDecription,WalletImportedDate," +
                            "UNMATCHED_TYPE,MATCHED_ENTRY_DATE,LAST_MODIFIED_DATE,LAST_MODIFIED_USER) " +
                            "VALUES (" +
                            ":stripeTxnId,:PackageID,:OutletID,:MGGTransactionID," +
                            ":StripeCreatedUTC,:StripeCreatedLocal,:StripeAmount,:StripeRefunded,:StripeFee,:StripeCaptured,:StripeStatus,:StripeImportedDate," +
                            ":WalletId," +
                            ":WalletDebitAccount, :WalletCreditAccount, :WalletMerchantId, :WalletTerminalId, :WalletMerchantRef," +
                            ":WalletThirdPartyRef, :WalletTxTimestamp, :WalletAmountIsFormatted, :WalletAmount, :WalletCreditFeeAmount," +
                            ":WalletCreditFeeCode, :WalletDebitFeeAmount, :WalletDebitFeeCode, :WalletSof, :WalletSofRef, :WalletChannel," +
                            ":WalletShortDescription, :WalletAcqId, :WalletGroup, :WalletBrand, :WalletOutlet, :WalletTxnDecription,:WalletImportedDate," +
                            ":UNMATCHED_TYPE,:MATCHED_ENTRY_DATE,:LAST_MODIFIED_DATE,:LAST_MODIFIED_USER)";
                        
                        try
                        {
                            using (var command = connection.CreateCommand())
                            {
                                command.CommandText = sqlInsertQuery;
                                command.CommandType = CommandType.Text;
                                command.BindByName = true;
                                command.ArrayBindCount = records.Count;
                                command.Parameters.Add(":stripeTxnId", OracleDbType.Varchar2, records.Select(c => c.stripeTxnId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":PackageID", OracleDbType.Varchar2, records.Select(c => c.PackageID).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":OutletID", OracleDbType.Varchar2, records.Select(c => c.OutletID).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":MGGTransactionID", OracleDbType.Varchar2, records.Select(c => c.MGGTransactionID).ToArray(), ParameterDirection.Input);
                                
                                command.Parameters.Add(":StripeCreatedUTC", OracleDbType.Date, records.Select(c => c.StripeCreatedUTC).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":StripeCreatedLocal", OracleDbType.Date, records.Select(c => c.StripeCreatedLocal).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":StripeAmount", OracleDbType.Double, records.Select(c => c.StripeAmount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":StripeRefunded", OracleDbType.Double, records.Select(c => c.StripeRefunded).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":StripeFee", OracleDbType.Double, records.Select(c => c.StripeFee).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":StripeCaptured", OracleDbType.Varchar2, records.Select(c => c.StripeCaptured).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":StripeStatus", OracleDbType.Varchar2, records.Select(c => c.StripeStatus).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":StripeImportedDate", OracleDbType.Date, records.Select(c => c.StripeImportedDate).ToArray(), ParameterDirection.Input);
                                
                                command.Parameters.Add(":WalletId", OracleDbType.Varchar2, records.Select(c => c.WalletId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletDebitAccount", OracleDbType.Varchar2, records.Select(c => c.WalletDebitAccount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletCreditAccount", OracleDbType.Varchar2, records.Select(c => c.WalletCreditAccount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletMerchantId", OracleDbType.Varchar2, records.Select(c => c.WalletMerchantId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletTerminalId", OracleDbType.Varchar2, records.Select(c => c.WalletTerminalId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletMerchantRef", OracleDbType.Varchar2, records.Select(c => c.WalletMerchantRef).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletThirdPartyRef", OracleDbType.Varchar2, records.Select(c => c.WalletThirdPartyRef).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletTxTimestamp", OracleDbType.Date, records.Select(c => c.WalletTxTimestamp).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletAmountIsFormatted", OracleDbType.Varchar2, records.Select(c => c.WalletAmountIsFormatted).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletAmount", OracleDbType.Int64, records.Select(c => c.WalletAmount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletCreditFeeAmount", OracleDbType.Int64, records.Select(c => c.WalletCreditFeeAmount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletCreditFeeCode", OracleDbType.Varchar2, records.Select(c => c.WalletCreditFeeCode).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletDebitFeeAmount", OracleDbType.Int64, records.Select(c => c.WalletDebitFeeAmount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletDebitFeeCode", OracleDbType.Varchar2, records.Select(c => c.WalletDebitFeeCode).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletSof", OracleDbType.Varchar2, records.Select(c => c.WalletSof).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletSofRef", OracleDbType.Varchar2, records.Select(c => c.WalletSofRef).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletChannel", OracleDbType.Varchar2, records.Select(c => c.WalletChannel).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletShortDescription", OracleDbType.Varchar2, records.Select(c => c.WalletShortDescription).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletAcqId", OracleDbType.Varchar2, records.Select(c => c.WalletAcqId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletGroup", OracleDbType.Varchar2, records.Select(c => c.WalletGroup).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletBrand", OracleDbType.Varchar2, records.Select(c => c.WalletBrand).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletOutlet", OracleDbType.Varchar2, records.Select(c => c.WalletOutlet).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletTxnDecription", OracleDbType.Varchar2, records.Select(c => c.WalletTxnDecription).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":WalletImportedDate", OracleDbType.Date, records.Select(c => c.WalletImportedDate).ToArray(), ParameterDirection.Input);
                                
                                command.Parameters.Add(":UNMATCHED_TYPE", OracleDbType.Varchar2, records.Select(c => c.UNMATCHED_TYPE).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":MATCHED_ENTRY_DATE", OracleDbType.Date, records.Select(c => c.MATCHED_ENTRY_DATE).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":LAST_MODIFIED_DATE", OracleDbType.Date, records.Select(c => c.LAST_MODIFIED_DATE).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":LAST_MODIFIED_USER", OracleDbType.Varchar2, records.Select(c => c.LAST_MODIFIED_USER).ToArray(), ParameterDirection.Input);

                                result = command.ExecuteNonQuery();
                                if (result != records.Count)
                                {
                                    Logger.DailyLog("Info : BlockInsertToTBLTrustReconStatusTable - " + result + " Of " + records.Count + " inserted");
                                }
                            }

                            transaction.Commit();
                        }
                        catch(Exception e)
                        {
                            transaction.Rollback();
                            Logger.DailyLog("Error : ********************* Exception *******************************");
                            Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                            Logger.DailyLog("Error : " + e);
                        }

                    }
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + exception);
            }
        }
        
        
        
        
        public static int RemoveRepeatedRecords(string processingDate)
        {
            int res = 0;
            OracleTransaction transaction = null;
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    var sqlUpdate = "";
                    try
                    {
                        sqlUpdate = string.Format("DELETE FROM {0} n WHERE", Constants.TBLTrustReconStatusName);
                        sqlUpdate += " n.ROWID >";
                        sqlUpdate += string.Format(" (SELECT min(m.ROWID) FROM {0} m WHERE", Constants.TBLTrustReconStatusName);
                        sqlUpdate += " m.stripeTxnId = n.stripeTxnId";
                        sqlUpdate += " GROUP BY stripeTxnId, UNMATCHED_TYPE) ";
                        res = connection.Execute(sqlUpdate);
                        Logger.DailyLog("Info : RemoveRepeatedRecords = " + res);
                        Logger.DailyLog("Info : RemoveRepeatedRecords SQL = " + sqlUpdate);
                        transaction.Commit();
                    }
                    catch(Exception e)
                    {
                        transaction.Rollback();
                        Logger.DailyLog("Error : ********************* Exception *******************************");
                        Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                        Logger.DailyLog("Error : RemoveRepeatedRecords " + e);
                        Logger.DailyLog("Error : " + sqlUpdate);
                    }

                }
            }
            catch (Exception exception)
            {
                //transaction.Rollback();
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : RemoveRepeatedRecords " + exception);
            }
            
            return res;
        }
        
        
        public static int CheckForRepeatedRecords()
        {
            int res = 0;
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();
                    var sqlUpdate = "";
                    OracleCommand cmd = new OracleCommand();
                    try
                    {
                        sqlUpdate = string.Format("SELECT count(*) FROM {0} n WHERE", Constants.TBLTrustReconStatusName);
                        sqlUpdate += " ROWID NOT IN";
                        sqlUpdate += string.Format(" (SELECT MIN(ROWID) FROM {0} m ", Constants.TBLTrustReconStatusName);
                        sqlUpdate += " GROUP BY m.stripeTxnId, m.UNMATCHED_TYPE)";
                        cmd.CommandText = sqlUpdate;
                        cmd.Connection = connection;
                        Object obj = cmd.ExecuteScalar();
                        if (obj != null)
                        {
                            res = Convert.ToInt32(obj);
                        }
                        Logger.DailyLog("Info : Duplicates = " + res);
                        Logger.DailyLog("Info : Duplicates SQL = " + sqlUpdate);
                    }
                    catch(Exception e)
                    {
                        Logger.DailyLog("Error : ********************* Exception *******************************");
                        Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                        Logger.DailyLog("Error : CheckForRepeatedRecords " + e);
                        Logger.DailyLog("Error : " + sqlUpdate);
                    }

                }
            }
            catch (Exception exception)
            {
                //transaction.Rollback();
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : CheckForRepeatedRecords " + exception);
            }
            
            return res;
        }
        
        
        // Get the last run date
        public static DateTime GetReconRunDetails()
        {
            DateTime lastReconDate = DateTime.MinValue;
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();
                    var sqlQuery = string.Format("SELECT ReconRunDate FROM {0} WHERE STATUS = 'LASTRUN'",
                                                 Constants.TBLTrustReconHistoryName);
                    dynamic retVal = connection.QueryFirstOrDefault(sqlQuery);
                    if (retVal != null)
                    {
                        foreach (dynamic d in retVal)
                        {
                            if (d.Value != null)
                            {
                                lastReconDate = (DateTime)d.Value;
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Exception in GetReconRunDetails method " + exception.Message);
            }
            return lastReconDate;
        }
        
        
        public static void UpdateReconRunDetails(DateTime processingDate)
        {
            OracleTransaction transaction = null;
            try
            {
                DateTime existingReconDate = GetReconRunDetails();
                if (processingDate > existingReconDate)
                {
                    using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                    {
                        connection.Open();
                        transaction = connection.BeginTransaction();
                        var sqlUpdate = string.Format("begin UPDATE {0} SET ReconRunDate=to_date('{1}','dd-MM-yy HH24:mi:SS') WHERE status = 'LASTRUN'; " +
                                                      "IF sql%rowcount = 0 THEN INSERT INTO {0} (ReconRunDate, status) VALUES " +
                                                      "(to_date('{1}','dd-MM-yy HH24:mi:SS'), 'LASTRUN'); END IF; end;",
                                                      Constants.TBLTrustReconHistoryName, processingDate.ToString("dd-MM-yy HH:mm:ss"));
                        
                        try
                        {
                            connection.Execute(sqlUpdate);
                            transaction.Commit();
                        }
                        catch(Exception e)
                        {
                            transaction.Rollback();
                            Logger.DailyLog("Error : ********************* Exception *******************************");
                            Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                            Logger.DailyLog("Error : UpdateReconRunDetails " + e);
                            Logger.DailyLog("Error : " + sqlUpdate);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                //transaction.Rollback();
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : UpdateReconRunDetails " + exception.Message);
            }
        }



        public static void InsertLogToReconHistory(DateTime processingDate, string status, string descriptions)
        {
            OracleTransaction transaction = null;
            try
            {
                using (OracleConnection connection = new OracleConnection(Constants.ConnectionString))
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();
                    var sqlUpdate = string.Format("INSERT INTO {0} (ReconRunDate, Status, StatusDescription) ", Constants.TBLTrustReconHistoryName);
                    sqlUpdate += string.Format("VALUES (to_date('{0}','dd-MM-yy HH24:mi:SS'), '{1}', '{2}')", 
                                               processingDate.ToString("dd-MM-yy HH:mm:ss"), status, descriptions);
                    try
                    {
                        connection.Execute(sqlUpdate);
                        transaction.Commit();
                    }
                    catch(Exception e)
                    {
                        transaction.Rollback();
                        Logger.DailyLog("Error : ********************* Exception *******************************");
                        Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                        Logger.DailyLog("Error : InsertLogToReconHistory " + e);
                        Logger.DailyLog("Error : " + sqlUpdate);
                    }
                }
                
            }
            catch (Exception exception)
            {
                //transaction.Rollback();
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : InsertLogToReconHistory " + exception.Message);
            }
        }
        
        
        //---------------------------------------------------------------------------------------------------
        
        // Insert TBLTrustStripeSrc (Stripe) objects into DB table.
        public static void ImportTBLTrustStripeSrc(List<TBLTrustStripeSrc> cObjects)
        {
            OracleTransaction transaction = null;
            string connString = Constants.ConnectionString;
            try
            {
                if (cObjects.Count > 0)
                {
                    using (OracleConnection connection = new OracleConnection(connString))
                    {
                        connection.Open();
                        transaction = connection.BeginTransaction();
                        string sqlInsertQuery =
                            String.Format("INSERT INTO {0} (Id, Description, CreatedUTC, Amount, AmountRefunded, Fee," +
                                          "Captured, Status, " +
                                          "CardID, PackageID, OutletID, MGGTransactionID, CreatedLocal, ImportedDate) " +
                                          "VALUES (:Id,:Description,:CreatedUTC,:Amount,:AmountRefunded,:Fee," +
                                          ":Captured,:Status," +
                                          ":CardID,:PackageID,:OutletID,:MGGTransactionID,:CreatedLocal,:ImportedDate)", Constants.TBLTrustStripeSrcName);
                        
                        try
                        {
                            using (var command = connection.CreateCommand())
                            {
                                // parameterized queries
                                command.CommandText = sqlInsertQuery;
                                command.CommandType = CommandType.Text;
                                command.BindByName = true;
                                command.ArrayBindCount = cObjects.Count;
                                command.Parameters.Add(":Id", OracleDbType.Varchar2, cObjects.Select(c => c.Id).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":Description", OracleDbType.Varchar2, cObjects.Select(c => c.Description).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":CreatedUTC", OracleDbType.Date, cObjects.Select(c => c.CreatedUTC).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":Amount", OracleDbType.Double, cObjects.Select(c => c.Amount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":AmountRefunded", OracleDbType.Double, cObjects.Select(c => c.AmountRefunded).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":Fee", OracleDbType.Double, cObjects.Select(c => c.Fee).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":Captured", OracleDbType.Varchar2, cObjects.Select(c => c.Captured).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":Status", OracleDbType.Varchar2, cObjects.Select(c => c.Status).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":CardID", OracleDbType.Varchar2, cObjects.Select(c => c.CardID).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":PackageID", OracleDbType.Varchar2, cObjects.Select(c => c.PackageID).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":OutletID", OracleDbType.Varchar2, cObjects.Select(c => c.OutletID).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":MGGTransactionID", OracleDbType.Varchar2, cObjects.Select(c => c.MGGTransactionID).ToArray(), ParameterDirection.Input);
                                
                                command.Parameters.Add(":CreatedLocal", OracleDbType.Date,
                                                       cObjects.Select(c => c.CreatedLocal = c.CreatedUTC.AddHours(Constants.LocalTimeOffset)).ToArray(), ParameterDirection.Input);
                                //command.Parameters.Add(":ImportedDate", OracleDbType.Date, cObjects.Select(c => c.ImportedDate = Globals.ProcessingDate).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":ImportedDate", OracleDbType.Date, cObjects.Select(c => c.ImportedDate).ToArray(), ParameterDirection.Input);
                                
                                int result = command.ExecuteNonQuery();
                            }

                            transaction.Commit();
                        }
                        catch(Exception e)
                        {
                            transaction.Rollback();
                            Logger.DailyLog("Error : ********************* Exception *******************************");
                            Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                            Logger.DailyLog("Error : " + e);
                            //Logger.DailyLog("Error : " + sqlUpdate);
                        }

                    }
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + connString);
                Logger.DailyLog("Error : " + exception);
            }
        }

        // Insert TBLTrustWalletSrc (wallet) records into DB table.
        public static void ImportTBLTrustWalletSrc(List<TBLTrustWalletSrc> cObjects)
        {
            OracleTransaction transaction = null;
            string connString = Constants.ConnectionString;
            try
            {
                if (cObjects.Count > 0)
                {
                    using (OracleConnection connection = new OracleConnection(connString))
                    {
                        connection.Open();
                        transaction = connection.BeginTransaction();
                        string sqlInsertQuery =
                            String.Format("INSERT INTO {0} " +
                                          "(walletId, debitAccount, creditAccount, merchantId, terminalId, merchantRef, thirdPartyRef, " +
                                          "txTimestamp, amountIsFormatted, amount, creditFeeAmount, creditFeeCode, debitFeeAmount, " +
                                          "debitFeeCode, sof, sofRef, channel, shortDescription, acqId, mgroup, brand, outlet, txnDecription, " +
                                          "packageId, stripeTxnId, ImportedDate) " +
                                          "VALUES (:walletId, :debitAccount, :creditAccount, :merchantId, :terminalId, :merchantRef, :thirdPartyRef, " +
                                          ":txTimestamp, :amountIsFormatted, :amount, :creditFeeAmount, :creditFeeCode, :debitFeeAmount, " +
                                          ":debitFeeCode, :sof, :sofRef, :channel, :shortDescription, :acqId, :mgroup, :brand, :outlet, :txnDecription, " +
                                          ":packageId, :stripeTxnId, :ImportedDate) ", Constants.TBLTrustWalletSrcName);
                        
                        try
                        {
                            using (var command = connection.CreateCommand())
                            {
                                // parameterized queries
                                command.CommandText = sqlInsertQuery;
                                command.CommandType = CommandType.Text;
                                command.BindByName = true;
                                command.ArrayBindCount = cObjects.Count;
                                
                                command.Parameters.Add(":walletId", OracleDbType.Varchar2, cObjects.Select(c => c.walletId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":debitAccount", OracleDbType.Varchar2, cObjects.Select(c => c.debitAccount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":creditAccount", OracleDbType.Varchar2, cObjects.Select(c => c.creditAccount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":merchantId", OracleDbType.Varchar2, cObjects.Select(c => c.merchantId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":terminalId", OracleDbType.Varchar2, cObjects.Select(c => c.terminalId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":merchantRef", OracleDbType.Varchar2, cObjects.Select(c => c.merchantRef).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":thirdPartyRef", OracleDbType.Varchar2, cObjects.Select(c => c.thirdPartyRef).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":txTimestamp", OracleDbType.Date, cObjects.Select(c => c.txTimestamp).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":amountIsFormatted", OracleDbType.Varchar2, cObjects.Select(c => c.amountIsFormatted).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":amount", OracleDbType.Int64, cObjects.Select(c => c.amount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":creditFeeAmount", OracleDbType.Int64, cObjects.Select(c => c.creditFeeAmount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":creditFeeCode", OracleDbType.Varchar2, cObjects.Select(c => c.creditFeeCode).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":debitFeeAmount", OracleDbType.Int64, cObjects.Select(c => c.debitFeeAmount).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":debitFeeCode", OracleDbType.Varchar2, cObjects.Select(c => c.debitFeeCode).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":sof", OracleDbType.Varchar2, cObjects.Select(c => c.sof).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":sofRef", OracleDbType.Varchar2, cObjects.Select(c => c.sofRef).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":channel", OracleDbType.Varchar2, cObjects.Select(c => c.channel).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":shortDescription", OracleDbType.Varchar2, cObjects.Select(c => c.shortDescription).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":acqId", OracleDbType.Varchar2, cObjects.Select(c => c.acqId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":mgroup", OracleDbType.Varchar2, cObjects.Select(c => c.mgroup).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":brand", OracleDbType.Varchar2, cObjects.Select(c => c.brand).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":outlet", OracleDbType.Varchar2, cObjects.Select(c => c.outlet).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":txnDecription", OracleDbType.Varchar2, cObjects.Select(c => c.txnDecription).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":packageId", OracleDbType.Varchar2, cObjects.Select(c => c.packageId).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":stripeTxnId", OracleDbType.Varchar2, cObjects.Select(c => c.stripeTxnId).ToArray(), ParameterDirection.Input);
                                
                                //command.Parameters.Add(":ImportedDate", OracleDbType.Date, cObjects.Select(c => c.ImportedDate = Globals.ProcessingDate).ToArray(), ParameterDirection.Input);
                                command.Parameters.Add(":ImportedDate", OracleDbType.Date, cObjects.Select(c => c.ImportedDate).ToArray(), ParameterDirection.Input);
                                
                                int result = command.ExecuteNonQuery();
                            }

                            transaction.Commit();
                        }
                        catch(Exception e)
                        {
                            transaction.Rollback();
                            Logger.DailyLog("Error : ********************* Exception *******************************");
                            Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                            Logger.DailyLog("Error : " + e);
                            //Logger.DailyLog("Error : " + sqlUpdate);
                        }

                    }
                }
            }
            catch (Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : " + connString);
                Logger.DailyLog("Error : " + exception);
            }
        }
        
    }
}


