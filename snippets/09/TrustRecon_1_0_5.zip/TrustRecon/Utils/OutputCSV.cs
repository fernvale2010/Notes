﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;
using System.Globalization;

namespace TrustRecon
{
    static class OutputCSV
    {
        const string csvMatchedHeader =
            "stripeTxnId,PackageID,OutletID,MGGTransactionID,StripeCreatedUTC,StripeCreatedLocal,StripeAmount,StripeRefunded,StripeFee,StripeCaptured,StripeStatus,StripeImportedDate," +
            "WalletId,WalletDebitAccount,WalletCreditAccount,WalletMerchantId,WalletTerminalId,WalletMerchantRef,WalletThirdPartyRef,WalletTxTimestamp,WalletAmountIsFormatted," +
            "WalletAmount,WalletCreditFeeAmount,WalletCreditFeeCode,WalletDebitFeeAmount,WalletDebitFeeCode,WalletSof,WalletSofRef,WalletChannel,WalletShortDescription," +
            "WalletAcqId,WalletGroup,WalletBrand,WalletOutlet,WalletTxnDecription,WalletImportedDate," +
            "UNMATCHED_TYPE,MATCHED_ENTRY_DATE,LAST_MODIFIED_DATE,LAST_MODIFIED_USER";
        
        const string csvUnMatchedHeader = csvMatchedHeader;

        // strDate is in Constants.ProcessingDateFormat format..
        public static void GenerateCSV(List<TBLTrustReconStatus> list, string strDate)
        {
            GenerateCSVForMatched(list, strDate);
            GenerateCSVForTrustMatched(list, strDate);
            GenerateCSVForUnMatched(list, strDate);
        }
        
        private static void GenerateCSVForMatched(List<TBLTrustReconStatus> list, string strDate)
        {
            string Filename = String.Format(Constants.MatchedReportPath, strDate, strDate);
            DateTime date = DateTime.ParseExact(strDate, Constants.ProcessingDateFormat,  CultureInfo.InvariantCulture);
            
            FileInfo fileInfo = new FileInfo(Filename);
            if (!fileInfo.Directory.Exists)
            {
                System.IO.Directory.CreateDirectory(fileInfo.DirectoryName);
            }
            
            StringBuilder sb = new StringBuilder();
            
            sb.AppendLine(csvMatchedHeader);

            try
            {
                // MATCHED_ENTRY_DATE is "today", transaction date can be any days
                List<TBLTrustReconStatus> matched = list.Where(x => (x.UNMATCHED_TYPE == "MATCHED") &&
                                                               (x.MATCHED_ENTRY_DATE.Value.Date == date.Date)).OrderByDescending(x => x.StripeCreatedLocal).ToList();
                using (StreamWriter Writer = new StreamWriter(Filename, false, new UTF8Encoding(false)))
                {
                    foreach (var c in matched)
                    {
                        try
                        {
                            string text = c.stripeTxnId + "," +
                                c.PackageID + "," +
                                c.OutletID + "," +
                                c.MGGTransactionID + "," +
                                c.StripeCreatedUTC + "," +
                                c.StripeCreatedLocal + "," +
                                c.StripeAmount + "," +
                                c.StripeRefunded + "," +
                                c.StripeFee + "," +
                                c.StripeCaptured + "," +
                                c.StripeStatus + "," +
                                c.StripeImportedDate + "," +
                                c.WalletId + "," +
                                c.WalletDebitAccount + "," +
                                c.WalletCreditAccount + "," +
                                c.WalletMerchantId + "," +
                                c.WalletTerminalId + "," +
                                c.WalletMerchantRef + "," +
                                c.WalletThirdPartyRef + "," +
                                c.WalletTxTimestamp + "," +
                                c.WalletAmountIsFormatted + "," +
                                c.WalletAmount + "," +
                                c.WalletCreditFeeAmount + "," +
                                c.WalletCreditFeeCode + "," +
                                c.WalletDebitFeeAmount + "," +
                                c.WalletDebitFeeCode + "," +
                                c.WalletSof + "," +
                                c.WalletSofRef + "," +
                                c.WalletChannel + "," +
                                c.WalletShortDescription + "," +
                                c.WalletAcqId + "," +
                                c.WalletGroup + "," +
                                c.WalletBrand + "," +
                                c.WalletOutlet + "," +
                                c.WalletTxnDecription + "," +
                                c.WalletImportedDate + "," +
                                c.UNMATCHED_TYPE + "," +
                                c.MATCHED_ENTRY_DATE + "," +
                                c.LAST_MODIFIED_DATE + "," +
                                c.LAST_MODIFIED_USER;
                            
                            sb.AppendLine(text);
                        }
                        catch (Exception e)
                        {
                            Logger.DailyLog(String.Format("Error: {0}, {1} - Exception caught: {2}",
                                                          Constants.__FILE__(), Constants.__LINE__(), e.Message));
                        }
                    }

                    Writer.WriteLine(sb.ToString());
                }
            }
            catch (Exception exp)
            {
                Logger.DailyLog(String.Format("Error: {0}, {1} - Exception {2}",
                                              Constants.__FILE__(), Constants.__LINE__(), exp.Message));
            }
        }
        
        
        private static void GenerateCSVForUnMatched(List<TBLTrustReconStatus> list, string strDate)
        {
            string Filename = String.Format(Constants.UnmatchedReportPath, strDate, strDate);
            DateTime date = DateTime.ParseExact(strDate, Constants.ProcessingDateFormat,  CultureInfo.InvariantCulture);
            StringBuilder sb = new StringBuilder();
            
            sb.AppendLine(csvUnMatchedHeader);

            try
            {
                List<TBLTrustReconStatus> unmatched = list.Where(x => x.UNMATCHED_TYPE == "A-no-C").OrderByDescending(x => x.StripeCreatedLocal).ToList();
                unmatched.AddRange(list.Where(x => x.UNMATCHED_TYPE == "C-no-A").OrderByDescending(x => x.WalletTxTimestamp).ToList());
                using (StreamWriter Writer = new StreamWriter(Filename, false, new UTF8Encoding(false)))
                {
                    foreach (var c in unmatched)
                    {
                        try
                        {
                            string text = c.stripeTxnId + "," +
                                c.PackageID + "," +
                                c.OutletID + "," +
                                c.MGGTransactionID + "," +
                                c.StripeCreatedUTC + "," +
                                c.StripeCreatedLocal + "," +
                                c.StripeAmount + "," +
                                c.StripeRefunded + "," +
                                c.StripeFee + "," +
                                c.StripeCaptured + "," +
                                c.StripeStatus + "," +
                                c.StripeImportedDate + "," +
                                c.WalletId + "," +
                                c.WalletDebitAccount + "," +
                                c.WalletCreditAccount + "," +
                                c.WalletMerchantId + "," +
                                c.WalletTerminalId + "," +
                                c.WalletMerchantRef + "," +
                                c.WalletThirdPartyRef + "," +
                                c.WalletTxTimestamp + "," +
                                c.WalletAmountIsFormatted + "," +
                                c.WalletAmount + "," +
                                c.WalletCreditFeeAmount + "," +
                                c.WalletCreditFeeCode + "," +
                                c.WalletDebitFeeAmount + "," +
                                c.WalletDebitFeeCode + "," +
                                c.WalletSof + "," +
                                c.WalletSofRef + "," +
                                c.WalletChannel + "," +
                                c.WalletShortDescription + "," +
                                c.WalletAcqId + "," +
                                c.WalletGroup + "," +
                                c.WalletBrand + "," +
                                c.WalletOutlet + "," +
                                c.WalletTxnDecription + "," +
                                c.WalletImportedDate + "," +
                                c.UNMATCHED_TYPE + "," +
                                c.MATCHED_ENTRY_DATE + "," +
                                c.LAST_MODIFIED_DATE + "," +
                                c.LAST_MODIFIED_USER;
                            
                            sb.AppendLine(text);
                        }
                        catch (Exception e)
                        {
                            Logger.DailyLog(String.Format("Error: {0}, {1} - Exception caught: {2}",
                                                          Constants.__FILE__(), Constants.__LINE__(), e.Message));
                        }
                    }

                    Writer.WriteLine(sb.ToString());
                }
            }
            catch (Exception exp)
            {
                Logger.DailyLog(String.Format("Error: {0}, {1} - Exception {2}",
                                              Constants.__FILE__(), Constants.__LINE__(), exp.Message));
            }
        }
        
        private static void GenerateCSVForTrustMatched(List<TBLTrustReconStatus> list, string strDate)
        {
            string trustname = String.Format("Trust_{0}", strDate);
            string Filename = String.Format(Constants.MatchedReportPath, strDate, trustname);
            DateTime date = DateTime.ParseExact(strDate, Constants.ProcessingDateFormat,  CultureInfo.InvariantCulture);
            
            FileInfo fileInfo = new FileInfo(Filename);
            if (!fileInfo.Directory.Exists)
            {
                System.IO.Directory.CreateDirectory(fileInfo.DirectoryName);
            }
            
            StringBuilder sb = new StringBuilder();
            
            string csvHeader =
                "Package Creation Date,Merchant Code,Merchant,MID NO.,Wallet ID,Package Amount,Stripe Fee,Stripe Credit Date (UTC),Stripe Credit Date (Local),Stripe Credit Amount,Stripe Id,MerchantRef";
            
            sb.AppendLine(csvHeader);

            try
            {
                // MATCHED_ENTRY_DATE is "today", transaction date can be any days
                List<TBLTrustReconStatus> matched = list.Where(x => (x.UNMATCHED_TYPE == "MATCHED") &&
                                                               (x.MATCHED_ENTRY_DATE.Value.Date == date.Date)).OrderByDescending(x => x.StripeCreatedLocal).ToList();
                using (StreamWriter Writer = new StreamWriter(Filename, false, new UTF8Encoding(false)))
                {
                    foreach (var c in matched)
                    {
                        try
                        {
                            string text = c.WalletTxTimestamp.ToString("dd/MM/yyyy") + "," +
                                c.WalletBrand + "," +
                                c.WalletGroup + "," +
                                c.WalletMerchantId + "," +
                                c.WalletId + "," + // Need MGG to provide
                                (c.WalletAmount/100.0) + "," +  // in cents
                                c.StripeFee + "," +
                                c.StripeCreatedUTC + "," +
                                c.StripeCreatedLocal + "," +
                                (c.StripeAmount - c.StripeFee) + "," +
                                c.stripeTxnId + "," +
                                c.WalletMerchantRef;
                            
                                //c.MATCHED_ENTRY_DATE + "," +
                            
                            sb.AppendLine(text);
                        }
                        catch (Exception e)
                        {
                            Logger.DailyLog(String.Format("Error: {0}, {1} - Exception caught: {2}",
                                                          Constants.__FILE__(), Constants.__LINE__(), e.Message));
                        }
                    }

                    Writer.WriteLine(sb.ToString());
                }
            }
            catch (Exception exp)
            {
                Logger.DailyLog(String.Format("Error: {0}, {1} - Exception {2}",
                                              Constants.__FILE__(), Constants.__LINE__(), exp.Message));
            }
        }
        
    } // class
} // namespace

