﻿

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Web.Script.Serialization;  // add reference: System.Web.Extensions


namespace TrustRecon
{
    // https://stackoverflow.com/questions/5047349/how-to-check-if-ienumerable-is-null-or-empty
    public static class Utils
    {
        public static bool IsAny<T>(this IEnumerable<T> data)
        {
            return data != null && data.Any();
        }
        
        
        public static void LogReconQuery(SimpleLogger logger, string fname, string sql)
        {
            logger.Info("******************* " + fname + " - Query *******************");
            logger.Info(sql + "\r\n\r\n");
        }
        
        
        // https://stackoverflow.com/questions/10520048/calculate-md5-checksum-for-a-file
        public static string CalculateMD5(string filename)
        {
            using (var md5 = MD5.Create())
            {
                using (var stream = File.OpenRead(filename))
                {
                    var hash = md5.ComputeHash(stream);
                    return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                }
            }
        }
        
        public static string[] GetFileList(string dir, bool subdir = false)
        {
            string[] files = new string[] {};
            
            try
            {
                SearchOption opt = SearchOption.TopDirectoryOnly; // SearchOption.TopDirectoryOnly OR SearchOption.AllDirectories
                if (subdir == true)
                {
                    opt = SearchOption.AllDirectories;
                }
                
                files = Directory.GetFiles(dir, "*", opt);
            }
            catch(Exception exception)
            {
                Logger.DailyLog("Error : ********************* Exception *******************************");
                Logger.DailyLog("Error : " + Constants.__FILE__() + "-" + Constants.__LINE__());
                Logger.DailyLog("Error : GetFileList - " + exception);
            }
            
            return files;
        }
        
        // https://dzone.com/articles/move-replace-c-method
        public static void MoveWithReplace(string sourceFileName, string destFileName)
        {
            //first, delete target file if exists, as File.Move() does not support overwrite
            if (File.Exists(destFileName))
            {
                File.Delete(destFileName);
            }

            File.Move(sourceFileName, destFileName);
        }
        
        
        public static Dictionary<string,string> DictionaryDeserialize(string inStr)
        {
            //eg. string jsonText = "{ \"ID\": 108, \"StartDate\": \"2011-04-13T15:34:09Z\", \"Name\": \"SN1234\" }";
            var jss = new JavaScriptSerializer();
            var dict = jss.Deserialize<Dictionary<string,string>>(inStr);
            
            // Console.WriteLine(dict["ID"]);
            return dict;
        }
        
        public static string DictionarySerialize(Dictionary<string,string> dict)
        {
            var jss = new JavaScriptSerializer();
            
            var json = jss.Serialize(dict);
            return json;
        }
        
        #if (true)
        // https://stackoverflow.com/questions/4994277/memory-address-of-an-object-in-c-sharp
        // ConditionalWeakTable<key, value>
        // In this case, key is reconSummary, and value is RefId..
        private static readonly ConditionalWeakTable<object, RefId> _ids = new ConditionalWeakTable<object, RefId>();

        public static Guid GetRefId<T>(this T obj) where T: class
        {
            if (obj == null)
                return default(Guid);

            // GetOrCreateValue:
            // Atomically searches for a specified key in the table and returns the corresponding value.
            // If the key does not exist in the table, the method invokes the default constructor of the
            // class that represents the table's value to create a value that is bound to the specified key.
            // In this case RefId is the value.
            return _ids.GetOrCreateValue(obj).Id;
        }

        private class RefId
        {
            // In C# 6 and later, you can initialize auto-implemented properties similarly to fields:
            // public string FirstName { get; set; } = "Jane";
            //
            public Guid Id { get; set; }
            
            // default constructor
            public RefId()
            {
                Id = Guid.NewGuid();
            }
        }

        #endif
    }
}


